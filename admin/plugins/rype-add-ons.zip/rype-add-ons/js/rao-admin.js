jQuery(document).ready(function($){

	/********************************************/
	/* SINGLE MEDIA UPLOAD */
	/********************************************/
	var mediaUploader;

	$('.admin-module').on('click', '.rao_upload_image_button', function(e) {
	    e.preventDefault();
	    formfield = jQuery(this).prev('input');

	    // If the uploader object has already been created, reopen the dialog
	    if (mediaUploader) {
	      mediaUploader.open();
	      return;
	    }
	    // Extend the wp.media object
	    mediaUploader = wp.media.frames.file_frame = wp.media({
	      title: 'Choose Image',
	      button: {
	      text: 'Choose Image'
	    }, multiple: false });

	    // When a file is selected, grab the URL and set it as the text field's value
	    mediaUploader.on('select', function() {
	      attachment = mediaUploader.state().get('selection').first().toJSON();
	      $(formfield).val(attachment.url);
	    });
	    // Open the uploader dialog
	    mediaUploader.open();
	});

	/********************************************/
	/* SINGLE MEDIA REMOVE */
	/********************************************/
	$('.admin-module').on('click', '.remove', function() {
		$(this).parent().find('input[type="text"]').removeAttr('value');
		$(this).parent().find('.option-preview').hide();
	});

    /********************************************/
    /* GALLERY MULTIPLE UPLOAD */
    /********************************************/
     var gallery_media_upload;

    $('.add-gallery-media').click(function(e) {

        e.preventDefault();

        // If the uploader object has already been created, reopen the dialog
        if( gallery_media_upload ) {
            gallery_media_upload.open();
            return;
        }

        // Extend the wp.media object
        gallery_media_upload = wp.media.frames.file_frame = wp.media({
            title: 'Choose Images',
            button: { text: 'Choose Images' },
            multiple: true
        });

        // When multiple images are selected, get the multiple attachment objects and convert them into a usable array of attachments
        gallery_media_upload.on( 'select', function(){

            var attachments = gallery_media_upload.state().get('selection').map(function(attachment) {
                attachment.toJSON();
                return attachment;
            });

            //loop through the array and do things with each attachment
           var i;
           for (i = 0; i < attachments.length; ++i) {
                $('.gallery-container').prepend(
                    '<div class="gallery-img-preview"><img src="' + attachments[i].attributes.sizes.thumbnail.url + '" ><input type="hidden" name="rypecore_additional_img[]" value="'+ attachments[i].attributes.url +'" /><span class="action delete-additional-img" title="'+ rao_local_script.delete_text +'"><i class="fa fa-trash"></i></span><a href="'+rao_local_script.admin_url+'upload.php?item='+attachments[i].attributes.id+'" class="action edit-additional-img" target="_blank" title="'+rao_local_script.edit_text+'"><i class="fa fa-pencil"></i></a></div>'
                );
            }

        });

        gallery_media_upload.open();
    });

    /********************************************/
    /* GALLERY SORT */
    /********************************************/
    $('.gallery-container').sortable({
        curosr: 'move'
    });

    /********************************************/
    /* GALLERY DELETE */
    /********************************************/
    $('.gallery-container').on("click", ".gallery-img-preview .delete-additional-img", function() {
        $(this).parent().remove();
    });
	
	/********************************************/
	/* ACCORDIONS */
	/********************************************/
	$(function() {
		$( "#accordion" ).removeClass('hide');
		$( ".accordion" ).accordion({
			collapsible: true,
			active: false,
			autoHeight: true,
			heightStyle: "content"
		});
		$('.accordion-tab').click(function() {
			var icon = $(this).find('.icon');
			if (icon.hasClass('fa-chevron-right')) {
				$(this).find('.icon').removeClass('fa-chevron-right');
				$(this).find('.icon').addClass('fa-chevron-down');
			} else {
				$(this).find('.icon').removeClass('fa-chevron-down');
				$(this).find('.icon').addClass('fa-chevron-right');
			}
		});
	});

	/********************************************/
	/* TABS */
	/********************************************/
	$(function() {
		$( "#tabs" ).tabs();
		$(".tab-loader").hide();
	});

    /********************************************/
    /* DATEPICKER */
    /********************************************/
    var dateToday = new Date(); 
    $(".datepicker").datepicker({
        minDate: dateToday,
    });

    /********************************************/
    /* SETTINGS */
    /********************************************/
    $('.add-on-details-toggle').on('click', function(e) {
        e.preventDefault();
        $(this).closest('.admin-module').find('.add-on-details').fadeIn();
    }); 

    $('.add-on-details .fa-times').on('click', function(e) {
        e.preventDefault();
        $(this).closest('.add-on-details').fadeOut();
    });

    /********************************************/
    /* SELECTABLE ITEMS */
    /********************************************/
    $('.selectable-item').click(function() {
        $( ".selectable-item" ).each(function( index ) {
          $(this).removeClass('active');
        });
        $(this).addClass('active');

        var input  = $(this).find('input').val();
        input = 'selectable-item-options-' + input;
        
        $(".selectable-item-settings").each(function( index ) {
            if($(this).attr('id') == input) {
                $(".selectable-item-settings").hide();
                $(this).show();
            } else if($(this).attr('id') != input) {
                $(this).hide();
            }
        });
    });

    /********************************************/
    /* TOGGLE SWITCH */
    /********************************************/
    $('.toggle-switch-label').on('click', function() {
        if($(this).parent().find('.toggle-switch-checkbox').is(':checked')) {
            $(this).parent().find('.rao-active-input').val('');
            $(this).parent().attr('title', 'Disabled');
            $(this).closest('.admin-module').removeClass('active-add-on');
        } else {
            var label = $(this).attr('for');
            $(this).parent().find('.rao-active-input').val(label);
            $(this).parent().attr('title', 'Active');
            $(this).closest('.admin-module').addClass('active-add-on');
        }
    }); 

    /********************************************/
    /* TESTIMONIALS WIDGET */
    /********************************************/
    $('#widgets-right, .elementor-panel').on("click", ".testimonials-widget-container .testimonial-header", function() {
        $(this).parent().find('.testimonial-content').slideToggle('fast');
    });

    $('#widgets-right, .elementor-panel').on("click", ".button-add-testimonial", function() {
        var testimonialFieldName = $(this).closest('.testimonials-widget-container').find('.testimonial-field-name').html();
        var count = $(this).closest('.testimonials-widget-container').find('.testimonial-item').length;
        var testimonial = '\
            <div class="testimonial-item"> \
                <div class="testimonial-header"> \
                    <i class="icon fa fa-cog"></i> <strong>'+rypecore_local_script.new_testimonial+'</strong> \
                    <span class="right testimonial-delete"><i class="icon fa fa-close"></i> '+rypecore_local_script.remove_text+'</span> \
                </div> \
                <div class="testimonial-content"> \
                    <table> \
                        <tr> \
                            <td valign="top"><label>'+rypecore_local_script.name_text+':</label></td> \
                            <td valign="top"><input class="widefat" type="text" name="'+testimonialFieldName+'['+count+'][name]" value="" /></td> \
                        </tr> \
                        <tr> \
                            <td valign="top"><label>'+rypecore_local_script.position+':</label></td> \
                            <td valign="top"><input class="widefat" type="text" name="'+testimonialFieldName+'['+count+'][position]" value="" /></td> \
                        </tr> \
                        <tr> \
                            <td valign="top"><label>'+rypecore_local_script.image_url+':</td> \
                            <td valign="top"><input class="widefat" type="text" name="'+testimonialFieldName+'['+count+'][image]" value="" /></td> \
                        </tr> \
                        <tr> \
                            <td valign="top"><label>'+rypecore_local_script.testimonial+':</label></td> \
                            <td valign="top"><textarea class="widefat" name="'+testimonialFieldName+'['+count+'][text]"></textarea></td> \
                        </tr> \
                    </table> \
                </div> \
            </div> \
        ';
        $(this).closest('.testimonials-widget-container').prepend(testimonial);
    });

    $('#widgets-right, .elementor-panel').on("click", ".testimonials-widget-container .testimonial-header .testimonial-delete", function() {
        $(this).closest('.widget-inside').find('.widget-control-save').prop("disabled", false);
        $(this).closest('.testimonial-item').remove();
    });

});