<?php
/**
* Plugin Name: Rype Add-ons
* Plugin URI: http://rypecreative.com/
* Description: Custom post types, shortcodes, widgets and more, to enhance themes made by Rype Creative.
* Version: 1.0
* Author: Rype Creative
* Author URI: http://rypecreative.com/
* Text Domain: rype-add-ons
**/

/*-----------------------------------------------------------------------------------*/
/*  Load Text Domain
/*-----------------------------------------------------------------------------------*/
load_plugin_textdomain( 'rype-add-ons', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

/*-----------------------------------------------------------------------------------*/
/*	Include Plugin Stylesheets
/*-----------------------------------------------------------------------------------*/
function rao_load_stylesheets() {
	if (is_admin()) {

		//custom scripts
        wp_enqueue_script('rao-admin-js', plugins_url('/js/rao-admin.js', __FILE__), array('jquery','media-upload','thickbox'), '', true);
		wp_enqueue_style('rao-admin-css',  plugins_url('rao-style.css',  __FILE__), array(), '1.0', 'all');
        wp_enqueue_style('font-awesome',  plugins_url('/css/font-awesome/css/font-awesome.min.css', __FILE__), array(), '', 'all');

        //wordpress pre-loaded scripts
        if(function_exists( 'wp_enqueue_media' )) { wp_enqueue_media(); } else { wp_enqueue_script('media-upload'); }
        wp_enqueue_script('thickbox');
        wp_enqueue_style('thickbox');
        wp_enqueue_script('jquery-ui-core');
        wp_enqueue_script('jquery-ui-accordion');
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_script( 'jquery-ui-datepicker' );

        /* localize scripts */
        $translation_array = array(
            'admin_url' => esc_url(get_admin_url()),
            'delete_text' => __( 'Delete', 'rype-add-ons' ),
            'remove_text' => __( 'Remove', 'rype-add-ons' ),
            'edit_text' => __( 'Edit', 'rype-add-ons' ),
            'upload_img' => __( 'Upload Image', 'rype-add-ons' ),
        );
        wp_localize_script( 'rao-admin-js', 'rao_local_script', $translation_array );

	}
}
add_action('admin_enqueue_scripts', 'rao_load_stylesheets');

/*-----------------------------------------------------------------------------------*/
/*  GLOBAL FUNCTIONS
/*-----------------------------------------------------------------------------------*/
/* set add-ons data */
function rao_get_add_ons() {
    $default_add_ons = array(
        1 => array(
            'name' => 'Post Sharing',
            'slug' => 'rao_post_share',
            'icon' => 'share-alt',
            'note' => 'Add ability to share blog posts on social media',
            'group' => 'basic',
            'required_themes' => '',
            'link' => 'http://rypecreative.com/',
            'active' => 'true',
        ),
        2 => array(
            'name' => 'Post Likes',
            'slug' => 'rao_post_likes',
            'icon' => 'thumbs-up',
            'note' => 'Allow users to "like" posts',
            'group' => 'basic',
            'required_themes' => '',
            'link' => 'http://rypecreative.com/',
            'active' => 'true',
        ),
        3 => array(
            'name' => 'Page Settings',
            'slug' => 'rao_page_settings',
            'icon' => 'sticky-note-o',
            'note' => 'Add flexible options to pages & posts',
            'group' => 'basic',
            'required_themes' => '',
            'active' => 'true',
        ),
        4 => array(
            'name' => 'Slides',
            'slug' => 'rao_slides',
            'icon' => 'clone',
            'note' => 'Add slides custom post type',
            'group' => 'basic',
            'required_themes' => '',
            'active' => 'true',
        ),
        5 => array(
            'name' => 'Basic Shortcodes',
            'slug' => 'rao_shortcodes',
            'icon' => 'code',
            'note' => 'Add some helpful shortcodes',
            'group' => 'basic',
            'required_themes' => '',
            'active' => 'true',
        ),
        6 => array(
            'name' => 'Basic Widgets',
            'slug' => 'rao_widgets',
            'icon' => 'th-large',
            'note' => 'Add some helpful widgets',
            'group' => 'basic',
            'required_themes' => '',
            'active' => 'true',
        ),
        7 => array(
            'name' => 'Job Board',
            'slug' => 'rao_job_board',
            'icon' => 'briefcase',
            'note' => 'Add a job listing management system',
            'group' => 'advanced',
            'required_themes' => 'Sprout',
            'active' => 'false',
        ),
        8 => array(
            'name' => 'Real Estate',
            'slug' => 'rao_real_estate',
            'icon' => 'home',
            'note' => 'Add a real estate listing system',
            'group' => 'advanced',
            'required_themes' => 'HomePress',
            'active' => 'false',
        ),
    );
    $add_ons = get_option('rao_add_ons', $default_add_ons);
    return $add_ons;
}

/* check if add-on is active */
function rao_is_active($add_on_slug) {
    $add_ons = rao_get_add_ons();
    $is_active = false;
    foreach($add_ons as $add_on) {
        if($add_on_slug == $add_on['slug'] && (isset($add_on['active']) && $add_on['active'] == 'true')) {  
            $is_active = true;
        }
    }
    return $is_active;
}

//update incompatible add-ons on theme switch
function rao_update_incompatible_add_ons() {
    $add_ons = rao_get_add_ons();
    $current_theme = wp_get_theme();
    $theme_check_count = 1;
    foreach($add_ons as $add_on) {
        if(!empty($add_on['required_themes']) && $add_on['required_themes'] != $current_theme->name) {
            $add_ons[$theme_check_count]['active'] = 'false';
            update_option( 'rao_add_ons', $add_ons);
        }
        $theme_check_count++;
    }
}
add_action('switch_theme', 'rao_update_incompatible_add_ons');

/*-----------------------------------------------------------------------------------*/
/*  ADD SETTINGS PAGE
/*-----------------------------------------------------------------------------------*/
add_action('admin_menu', 'rao_plugin_menu');

function rao_plugin_menu() {
    add_menu_page('Rype Add-Ons', 'Rype Add-Ons', 'administrator', 'rao-plugin-settings', 'rao_plugin_settings_page', 'dashicons-admin-generic');
    add_action( 'admin_init', 'rao_register_options' );
}

function rao_register_options() {
    register_setting( 'rao-settings-group', 'rao_add_ons', 'rao_update_active_add_ons' );
}

function rao_update_active_add_ons($add_ons_new) {
    $count = 1;
    $add_ons = rao_get_add_ons();
    foreach($add_ons as $add_on) {
        if(!isset($add_ons_new[$count]['active'])) {
            $add_ons[$count]['active'] = 'false';
        } else {
            $add_ons[$count]['active'] = $add_ons_new[$count]['active'];
        }
        $count++;
    }
    return $add_ons;
}

function rao_plugin_settings_page() { ?>

    <?php
    //get add-ons
    $add_ons = rao_get_add_ons();
    $current_theme = wp_get_theme();
    ?>

    <div class="wrap">
        <h2><?php esc_html_e('Rype Add-Ons', 'rype-add-ons'); ?></h2>

        <form method="post" action="options.php">
            <?php settings_fields( 'rao-settings-group' ); ?>
            <?php do_settings_sections( 'rao-settings-group' ); ?>

            <div class="rao-settings-header">
                <?php
                $plugin_data = get_plugin_data( __FILE__ );
                $plugin_version = $plugin_data['Version']; 
                ?>
                <h3 class="left"><?php esc_html_e('Select add-ons to activate/deactivate below:', 'rype-add-ons'); ?></h3>
                <div class="right"><?php esc_html_e('Version', 'rype-add-ons'); ?> <?php echo $plugin_version; ?> | <?php esc_html_e('Made by', 'rype-add-ons'); ?> <a href="http://rypecreative.com/" target="_blank">Rype Creative</a> | <a href="http://rypecreative.com/contact/#theme-support" target="_blank"><?php esc_html_e('Get Support', 'rype-add-ons'); ?></a></div>
                <div class="clear"></div>
            </div>

            <div class="rao-modules">
                <?php $count = 1;
                foreach($add_ons as $add_on) { ?> 
                    <?php if(isset($add_on['active']) && $add_on['active'] == 'true') { $active = 'true'; } else { $active = 'false'; } ?>
                    <div class="admin-module <?php if($active == 'true') { echo 'active-add-on'; } ?>">
                        <?php if(!empty($add_on['icon'])) { ?><i class="fa fa-<?php echo $add_on['icon']; ?>"></i><?php } ?>    
                        <?php if(!empty($add_on['required_themes']) && $add_on['required_themes'] != $current_theme->name) { ?>    
                            <div class="theme-message">
                                <span><?php esc_html_e('Please activate a compatible theme.', 'rype-add-ons'); ?></span>
                                <a href="http://rypecreative.com/project-types/themes/" class="button" target="_blank"><?php esc_html_e('View Themes', 'rype-add-ons'); ?></a>
                            </div>
                        <?php } else { ?>
                            <div class="toggle-switch" title="<?php if($active == 'true') { esc_html_e('Active', 'rype-add-ons'); } else { esc_html_e('Disabled', 'rype-add-ons'); } ?>">
                                <input type="checkbox" id="<?php echo $add_on['slug']; ?>" name="rao_add_ons[<?php echo $count; ?>][active]" value="true" class="toggle-switch-checkbox" <?php checked('true', $active, true) ?> />
                                <label class="toggle-switch-label" for="<?php echo $add_on['slug']; ?>"></label>
                            </div>
                        <?php } ?>

                        <?php if(!empty($add_on['name'])) { ?><h4><?php echo $add_on['name']; ?></h4><?php } ?>
                        <?php if(!empty($add_on['note'])) { ?><span class="admin-module-note"><?php echo $add_on['note']; ?></span><?php } ?>
                        <?php if(!empty($add_on['link'])) { ?><a href="<?php echo $add_on['link']; ?>" target="_blank" class="button view-details"><?php esc_html_e('View Details', 'rype-add-ons'); ?></a><?php } ?>
                    </div>
                    <?php $count++; ?>
                <?php } ?>
                <div class="clear"></div>
            </div>

            <?php submit_button(); ?>

        </form>
    </div><!-- end wrap -->
<?php }

/*-----------------------------------------------------------------------------------*/
/*  ADD META TAGS TO HEAD
/*-----------------------------------------------------------------------------------*/
function rao_add_meta_tags() { 
    $output = '';
    if(is_single()) {
        global $post;
        setup_postdata( $post );
        $excerpt = wp_trim_words(get_the_excerpt(), 20);
        $output .= '<meta name="description" content="'.get_the_title().' - '.$excerpt.'">';
    } else {
        $output .= '<meta name="description" content="'.get_bloginfo('name').' - '.get_bloginfo('description').'">';
    } 
    echo $output;
}
add_action('wp_head', 'rao_add_meta_tags');

/*-----------------------------------------------------------------------------------*/
/*  Login Form Failed
/*-----------------------------------------------------------------------------------*/
add_action( 'wp_login_failed', 'rao_login_fail' );  // hook failed login
function rao_login_fail( $username ) {
   $referrer = $_SERVER['HTTP_REFERER'];
   if ( !empty($referrer) && !strstr($referrer,'wp-login') && !strstr($referrer,'wp-admin') ) {
      wp_redirect( add_query_arg('login', 'failed', $referrer) );
      exit;
   }
}

/*-----------------------------------------------------------------------------------*/
/*  Generate Icon
/*-----------------------------------------------------------------------------------*/
if( !function_exists('rypecore_get_icon') ){
    function rypecore_get_icon($type, $fa_name, $line_name = null, $dripicon_name = null, $class = null) {
        if($type == 'line') {
            if(empty($line_name)) { $line_name = $fa_name; }
            return '<i class="fa icon-'.$line_name.' icon icon-line '.$class.'"></i>';
        } else if($type == 'dripicon') {
            if(empty($dripicon_name)) { $dripicon_name = $fa_name; }
            return '<i class="fa dripicons-'.$dripicon_name.' icon icon-dripicon'.$class.'"></i>';
        } else {
            return '<i class="fa fa-'.$fa_name.' icon '.$class.'"></i>';
        }
    }
}

/*-----------------------------------------------------------------------------------*/
/*  Social Share
/*-----------------------------------------------------------------------------------*/
if(rao_is_active('rao_post_share')) {
    function rao_get_social_share($class = null, $toggle_text = null) {
        global $post;
        $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));

        ob_start(); ?>
        <div class="post-share rc-tooltip <?php echo $class; ?>">

            <?php if($toggle_text === true) { ?>
                <span class="post-share-toggle"><?php echo rypecore_get_icon($icon_set, 'share-alt', 'share2', 'forward'); ?><?php esc_html_e('Share', 'rype-add-ons'); ?></span>
            <?php } else { ?>
                <?php echo rypecore_get_icon($icon_set, 'share-alt', 'share2', 'forward', 'post-share-toggle'); ?>
            <?php } ?>

            <div class="post-share-content rc-tooltip-content">
                <div class="rc-tooltip-content-inner">
                    <ul class="clean-list">
                        <li><a href="http://www.facebook.com/sharer/sharer.php?u=<?php the_permalink();?>&t=<?php echo rawurlencode(get_the_title()); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/share?url=<?php the_permalink();?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="https://plus.google.com/share?url=<?php the_permalink();?>" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink();?>&title=<?php echo rawurlencode(get_the_title()); ?>&summary=&source=" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="https://pinterest.com/pin/create/button/?url=&media=<?php the_permalink();?>&description=" target="_blank"><i class="fa fa-pinterest"></i></a></li>
                        <li>
                            <?php 
                            $subject = get_the_title().' on '.get_bloginfo('name');
                            $body = '';
                            $body .= get_the_permalink();
                            $body .= '%0D%0A %0D%0A'.strip_tags(get_the_excerpt()).'%0D%0A %0D%0A';
                            ?>
                            <a href="mailto:?subject=<?php echo $subject; ?>&body=<?php echo $body; ?>"><?php echo rypecore_get_icon($icon_set, 'envelope', '', 'mail'); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <?php 
        $output = ob_get_clean();
        return $output;
    }

    function rao_add_post_share() { ?> 
        <li><?php echo rao_get_social_share('blog-share', true); ?></li>
    <?php }
    add_action( 'rao_after_post_meta', 'rao_add_post_share' );

    function rao_add_job_post_share() { ?> 
        <li class="share meta-icon"><?php echo rao_get_social_share('', false); ?></li>
    <?php }
    add_action( 'rao_job_board_after_post_meta', 'rao_add_job_post_share' );
}

/*-----------------------------------------------------------------------------------*/
/*  Post Likes
/*-----------------------------------------------------------------------------------*/
if(rao_is_active('rao_post_likes')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/post-likes/post-likes.php'); }

/*-----------------------------------------------------------------------------------*/
/*  Advanced Page Settings
/*-----------------------------------------------------------------------------------*/
if(rao_is_active('rao_page_settings')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/advanced-page-settings.php'); }

/*-----------------------------------------------------------------------------------*/
/*  Slides
/*-----------------------------------------------------------------------------------*/
if(rao_is_active('rao_slides')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/slides.php'); }

/*-----------------------------------------------------------------------------------*/
/*  Basic Shortcodes
/*-----------------------------------------------------------------------------------*/
if(rao_is_active('rao_shortcodes')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/basic-shortcodes/shortcodes.php'); }

/*-----------------------------------------------------------------------------------*/
/*  Basic Widgets
/*-----------------------------------------------------------------------------------*/
if(rao_is_active('rao_widgets')) {
    include('add-ons/basic-widgets/contact_info_widget.php');
    include('add-ons/basic-widgets/social_links_widget.php');
    include('add-ons/basic-widgets/list_posts_widget.php');
    include('add-ons/basic-widgets/testimonials_widget.php');
}

/*-----------------------------------------------------------------------------------*/
/*  Job Board
/*-----------------------------------------------------------------------------------*/
if(rao_is_active('rao_job_board')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/job-board/job-board.php'); }

/*  Output Notice if Job Board is not active */
function rao_add_job_board_notice() {
    if(!rao_is_active('rao_job_board') && current_theme_supports('rao-job-board')) {
        $class = 'notice notice-error is-dismissible';
        $message = wp_kses_post(__( 'Rype Job Board add-on is <strong>de-activated!</strong> Please activate the job board add-on <a href="'.get_admin_url().'admin.php?page=rao-plugin-settings">here.</a>', 'rype-add-ons' ));
        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), $message ); 
    }
}
add_action( 'admin_notices', 'rao_add_job_board_notice' );

/*-----------------------------------------------------------------------------------*/
/*  Real Estate
/*-----------------------------------------------------------------------------------*/
if(rao_is_active('rao_real_estate')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/real-estate/real-estate.php'); }

/*  Output Notice if Real Estate is not active */
function rao_add_real_estate_notice() {
    if(!rao_is_active('rao_real_estate') && current_theme_supports('rao-real-estate')) {
        $class = 'notice notice-error is-dismissible';
        $message = wp_kses_post(__( 'Rype Real Estate add-on is <strong>de-activated!</strong> Please activate the real estate add-on <a href="'.get_admin_url().'admin.php?page=rao-plugin-settings">here.</a>', 'rype-add-ons' ));
        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), $message ); 
    }
}
add_action( 'admin_notices', 'rao_add_real_estate_notice' );

/*-----------------------------------------------------------------------------------*/
/*  Main Contact Form
/*-----------------------------------------------------------------------------------*/
function rao_main_contact_form() {

    $default_email = get_option('admin_email');
    $contact_form_email = esc_attr(get_option('rypecore_email', $default_email));
    
    $nameError = '';
    $emailError= '';
    $commentError = '';
    $emailSent = null;

    //If the form is submitted
    if(isset($_POST['submitted'])) {
      
      // require a name from user
      if(trim($_POST['contact-name']) === '') {
        $nameError =  esc_html__('Forgot your name!', 'rype-add-ons'); 
        $hasError = true;
      } else {
        $contact_name = trim($_POST['contact-name']);
      }
      
      // need valid email
      if(trim($_POST['contact-email']) === '')  {
        $emailError = esc_html__('Forgot to enter in your e-mail address.', 'rype-add-ons');
        $hasError = true;
      } else if (!preg_match("/^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$/i", trim($_POST['contact-email']))) {
        $emailError = esc_html__('You entered an invalid email address.', 'rype-add-ons');
        $hasError = true;
      } else {
        $contact_email = trim($_POST['contact-email']);
      }

      // get phone
      if(trim($_POST['contact-phone']) === '') {
        // do nothing
      } else {
        $contact_phone = trim($_POST['contact-phone']);
      }

      // get subject
      if(trim($_POST['contact-subject']) === '') {
        // do nothing
      } else {
        $contact_subject = trim($_POST['contact-subject']);
      }
        
      // we need at least some content
      if(trim($_POST['contact-message']) === '') {
        $commentError = esc_html__('You forgot to enter a message!', 'rype-add-ons');
        $hasError = true;
      } else {
        if(function_exists('stripslashes')) {
          $contact_message = stripslashes(trim($_POST['contact-message']));
        } else {
          $contact_message = trim($_POST['contact-message']);
        }
      }
        
      // upon no failure errors let's email now!
      if(!isset($hasError)) {

        /*---------------------------------------------------------*/
        /* SET EMAIL ADDRESS HERE                                  */
        /*---------------------------------------------------------*/
        $emailTo = $contact_form_email;
        $subject = 'Submitted message from '.$contact_name;
        $sendCopy = trim($_POST['sendCopy']);
        $body = "Subject:$contact_subject \n\nName: $contact_name \n\nEmail: $contact_email \n\nPhone: $contact_phone \n\nMessage: $contact_message";
        $headers = 'From: ' .' <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $contact_email;

        mail($emailTo, $subject, $body, $headers);
            
        // set our boolean completion value to TRUE
        $emailSent = true;
      }
    }

    ?>

    <form method="post" class="contact-form">

        <?php if($emailSent) { echo '<div class="alert-box success">'. esc_html__('Your message was submitted!', 'rype-add-ons') .'</div>'; } ?>

        <div class="contact-form-fields">
            <div class="form-block">
                <?php if($nameError != '') { echo '<div class="alert-box error">'.$nameError.'</div>'; } ?>
                <label><?php esc_html_e( 'Name', 'rype-add-ons' ); ?>*</label>
                <input type="text" name="contact-name" placeholder="<?php esc_html_e( 'Your Name', 'rype-add-ons' ); ?>" class="requiredField" value="<?php if(isset($contact_name)) { echo $contact_name; } ?>" />
            </div>

            <div class="form-block">
                <?php if($emailError != '') { echo '<div class="alert-box error">'.$emailError.'</div>'; } ?>
                <label><?php esc_html_e( 'Email', 'rype-add-ons' ); ?>*</label>
                <input type="email" name="contact-email" placeholder="<?php esc_html_e( 'Your Email', 'rype-add-ons' ); ?>" class="requiredField email" value="<?php if(isset($contact_email)) { echo $contact_email; } ?>" />
            </div>

            <div class="form-block">
                <label><?php esc_html_e( 'Phone', 'rype-add-ons' ); ?></label>
                <input type="text" name="contact-phone" placeholder="<?php esc_html_e( 'Your Phone', 'rype-add-ons' ); ?>" value="<?php if(isset($_POST['contact-phone'])) { echo $_POST['contact-phone']; } ?>" />
            </div>

            <div class="form-block">
                <label><?php esc_html_e( 'Subject', 'rype-add-ons' ); ?></label>
                <input type="text" name="contact-subject" placeholder="<?php esc_html_e( 'Subject', 'rype-add-ons' ); ?>" value="<?php if(isset($_POST['contact-subject'])) { echo $_POST['contact-subject']; } ?>" />
            </div>

            <div class="form-block">
                <?php if($commentError != '') { echo '<div class="alert-box error">'.$commentError.'</div>'; } ?>
                <label><?php esc_html_e( 'Message', 'rype-add-ons' ); ?>*</label>
                <textarea name="contact-message" placeholder="<?php esc_html_e( 'Your Message', 'rype-add-ons' ); ?>" class="requiredField"><?php if(isset($contact_message)) { echo $contact_message; } ?></textarea>
            </div>

            <div class="form-block">
                <input type="hidden" name="submitted" id="submitted" value="true" />
                <input type="submit" value="<?php esc_html_e( 'Submit', 'rype-add-ons' ); ?>" />
                <div class="form-loader"><img src="<?php echo esc_url(home_url('/')); ?>wp-admin/images/spinner.gif" alt="" /> <?php esc_html_e( 'Loading...', 'rype-add-ons' ); ?></div>
            </div>
        </div>

    </form>

<?php }