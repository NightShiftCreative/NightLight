<?php
/**
* Plugin Name: Rype Add-ons
* Plugin URI: http://rypecreative.com/
* Description: Custom post types, shortcodes, widgets and more, to enhance themes made by Rype Creative.
* Version: 1.0
* Author: Rype Creative
* Author URI: http://rypecreative.com/
* Text Domain: rype-add-ons
**/

/*-----------------------------------------------------------------------------------*/
/*  Load Text Domain
/*-----------------------------------------------------------------------------------*/
load_plugin_textdomain( 'rype-add-ons', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

/*-----------------------------------------------------------------------------------*/
/*  Automatic Update Checker
/*-----------------------------------------------------------------------------------*/
require 'plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'http://rypecreative.com/rype-add-ons/rype-add-ons.json',
    __FILE__, //Full path to the main plugin file or functions.php.
    'rype-add-ons'
);

/*-----------------------------------------------------------------------------------*/
/*	Include Plugin Scripts and Stylesheets
/*-----------------------------------------------------------------------------------*/
function rao_load_stylesheets() {
	if (is_admin()) {

		//custom scripts
        wp_enqueue_script('rao-admin-js', plugins_url('/js/rao-admin.js', __FILE__), array('jquery','media-upload','thickbox', 'wp-color-picker'), '', true);
		wp_enqueue_style('rao-admin-css',  plugins_url('rao-style.css',  __FILE__), array(), '1.0', 'all');
        wp_enqueue_style('font-awesome',  plugins_url('/css/font-awesome/css/font-awesome.min.css', __FILE__), array(), '', 'all');

        //wordpress pre-loaded scripts
        if(function_exists( 'wp_enqueue_media' )) { wp_enqueue_media(); } else { wp_enqueue_script('media-upload'); }
        wp_enqueue_script('thickbox');
        wp_enqueue_style('thickbox');
        wp_enqueue_script('jquery-ui-core');
        wp_enqueue_script('jquery-ui-accordion');
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_script( 'jquery-ui-datepicker' );
        wp_enqueue_style( 'wp-color-picker' );

        /* localize scripts */
        $translation_array = array(
            'admin_url' => esc_url(get_admin_url()),
            'delete_text' => __( 'Delete', 'rype-add-ons' ),
            'remove_text' => __( 'Remove', 'rype-add-ons' ),
            'edit_text' => __( 'Edit', 'rype-add-ons' ),
            'upload_img' => __( 'Upload Image', 'rype-add-ons' ),
            'new_testimonial' => __( 'New Testimonial', 'rype-add-ons' ),
            'testimonial' => __( 'Testimonial', 'rype-add-ons' ),
            'position' => __( 'Position', 'rype-add-ons' ),
            'image_url' => __( 'Image URL', 'rype-add-ons' ),
            'name_text' => __( 'Name', 'rype-add-ons' ),
        );
        wp_localize_script( 'rao-admin-js', 'rao_local_script', $translation_array );

	}
}
add_action('admin_enqueue_scripts', 'rao_load_stylesheets');

/*-----------------------------------------------------------------------------------*/
/*  GLOBAL FUNCTIONS
/*-----------------------------------------------------------------------------------*/
/* set add-ons data */
function rao_get_add_ons() {
    $default_add_ons = array(
        1 => array(
            'name' => 'Post Sharing',
            'slug' => 'rao_post_share',
            'icon' => plugins_url('/rype-add-ons/images/icon-post-sharing.gif'),
            'note' => esc_html__('Add ability to share blog posts on social media', 'rype-add-ons'),
            'group' => 'basic',
            'required_themes' => '',
            'link' => 'http://rypecreative.com/',
            'active' => 'true',
        ),
        2 => array(
            'name' => 'Post Likes',
            'slug' => 'rao_post_likes',
            'icon' => 'thumbs-up',
            'note' => esc_html__('Allow users to "like" posts', 'rype-add-ons'),
            'group' => 'basic',
            'required_themes' => '',
            'link' => 'http://rypecreative.com/',
            'active' => 'true',
        ),
        3 => array(
            'name' => 'Page Settings',
            'slug' => 'rao_page_settings',
            'icon' => 'sticky-note-o',
            'note' => esc_html__('Add flexible options to pages & posts', 'rype-add-ons'),
            'group' => 'basic',
            'required_themes' => '',
            'active' => 'true',
        ),
        4 => array(
            'name' => 'Slides',
            'slug' => 'rao_slides',
            'icon' => 'clone',
            'note' => esc_html__('Add slides custom post type', 'rype-add-ons'),
            'group' => 'basic',
            'required_themes' => '',
            'active' => 'true',
        ),
        5 => array(
            'name' => 'Basic Shortcodes',
            'slug' => 'rao_shortcodes',
            'icon' => 'code',
            'note' => esc_html__('Add some helpful shortcodes', 'rype-add-ons'),
            'group' => 'basic',
            'required_themes' => '',
            'active' => 'true',
        ),
        6 => array(
            'name' => 'Basic Widgets',
            'slug' => 'rao_widgets',
            'icon' => 'th-large',
            'note' => esc_html__('Add some helpful widgets', 'rype-add-ons'),
            'group' => 'basic',
            'required_themes' => '',
            'active' => 'true',
        ),
        7 => array(
            'name' => 'Job Board',
            'slug' => 'rao_job_board',
            'icon' => 'briefcase',
            'note' => esc_html__('Add a job listing management system', 'rype-add-ons'),
            'group' => 'job_board',
            'required_themes' => 'Sprout',
            'active' => 'false',
        ),
        8 => array(
            'name' => 'Real Estate',
            'slug' => 'rao_real_estate',
            'icon' => 'home',
            'note' => esc_html__('Add a real estate listing system', 'rype-add-ons'),
            'group' => 'real_estate',
            'required_themes' => 'PadPress',
            'active' => 'false',
        ),
    );
    $add_ons = get_option('rao_add_ons', $default_add_ons);
    return $add_ons;
}

/** loop through add-ons **/
function rao_display_add_ons() {
    $add_ons = rao_get_add_ons();
    $current_theme = wp_get_theme();
    $output = '';
    ob_start(); 

    $count = 1;
    foreach($add_ons as $add_on) { 
        if(isset($add_on['active']) && $add_on['active'] == 'true') { $active = 'true'; } else { $active = 'false'; } ?>
        <div class="admin-module <?php if($active == 'true') { echo 'active-add-on'; } ?>">
            
            <div class="rao-module-header">
                <?php if(!empty($add_on['icon'])) { ?><div class="rao-module-icon"><img src="<?php echo $add_on['icon']; ?>" alt="" /></div><?php } ?>
                <?php if(!empty($add_on['name'])) { ?><h4><?php echo $add_on['name']; ?></h4><?php } ?>
                <?php if(!empty($add_on['required_themes']) && $add_on['required_themes'] != $current_theme->name) { ?>    
                    <div class="theme-message">
                        <span><?php esc_html_e('Please activate a compatible theme.', 'rype-add-ons'); ?></span>
                        <a href="http://rypecreative.com/project-types/themes/" class="button" target="_blank"><?php esc_html_e('View Themes', 'rype-add-ons'); ?></a>
                    </div>
                <?php } else { ?>
                    <div class="toggle-switch" title="<?php if($active == 'true') { esc_html_e('Active', 'rype-add-ons'); } else { esc_html_e('Disabled', 'rype-add-ons'); } ?>">
                        <input type="checkbox" id="<?php echo $add_on['slug']; ?>" name="rao_add_ons[<?php echo $count; ?>][active]" value="true" class="toggle-switch-checkbox" <?php checked('true', $active, true) ?> />
                        <label class="toggle-switch-label" for="<?php echo $add_on['slug']; ?>"><?php if($active == 'true') { echo '<span class="on">'.esc_html__('On', 'rype-add-ons').'</span>'; } else { echo '<span>'.esc_html__('Off', 'rype-add-ons').'</span>'; } ?></label>
                    </div>
                <?php } ?>
            </div>    

            <div class="rao-module-content">
                <?php if(!empty($add_on['note'])) { ?><span class="admin-module-note"><?php echo $add_on['note']; ?></span><?php } ?>
                <?php if(!empty($add_on['link'])) { ?><a href="<?php echo $add_on['link']; ?>" target="_blank" class="button view-details"><?php esc_html_e('View Details', 'rype-add-ons'); ?></a><?php } ?>
            </div>
        </div>
        <?php $count++; 
    } ?>
    <div class="clear"></div>

    <?php $output = ob_get_clean();
    return $output;
}

/* check if add-on is active */
function rao_is_active($add_on_slug) {
    $add_ons = rao_get_add_ons();
    $is_active = false;
    foreach($add_ons as $add_on) {
        if($add_on_slug == $add_on['slug'] && (isset($add_on['active']) && $add_on['active'] == 'true')) {  
            $is_active = true;
        }
    }
    return $is_active;
}

//update incompatible add-ons on theme switch
function rao_update_incompatible_add_ons() {
    $add_ons = rao_get_add_ons();
    $current_theme = wp_get_theme();
    $theme_check_count = 1;
    foreach($add_ons as $add_on) {
        if(!empty($add_on['required_themes']) && $add_on['required_themes'] != $current_theme->name) {
            $add_ons[$theme_check_count]['active'] = 'false';
            update_option( 'rao_add_ons', $add_ons);
        }
        $theme_check_count++;
    }
}
add_action('switch_theme', 'rao_update_incompatible_add_ons');

//  Check if key/value is in array
function rao_is_in_array($array, $key, $key_value){
    $within_array = false;
    foreach( $array as $k=>$v ){
        if( is_array($v) ){
            $within_array = rao_is_in_array($v, $key, $key_value);
            if( $within_array == true ){
                break;
            }
        } else {
            if( $v == $key_value && $k == $key ){
                $within_array = true;
                break;
            }
        }
    }
    return $within_array;
}

/*-----------------------------------------------------------------------------------*/
/*  ADD SETTINGS PAGE
/*-----------------------------------------------------------------------------------*/
add_action('admin_menu', 'rao_plugin_menu');
function rao_plugin_menu() {
    add_menu_page('Rype Add-Ons', 'Rype Add-Ons', 'administrator', 'rao-plugin-settings', 'rao_plugin_settings_page', 'dashicons-admin-generic');
    add_action( 'admin_init', 'rao_register_options' );
}

function rao_register_options() {
    register_setting( 'rao-settings-group', 'rao_add_ons', 'rao_update_active_add_ons' );
}

function rao_update_active_add_ons($add_ons_new) {
    $count = 1;
    $add_ons = rao_get_add_ons();
    foreach($add_ons as $add_on) {
        if(!isset($add_ons_new[$count]['active'])) {
            $add_ons[$count]['active'] = 'false';
        } else {
            $add_ons[$count]['active'] = $add_ons_new[$count]['active'];
        }
        $count++;
    }
    return $add_ons;
}

//Reset to default options
if(isset($_GET['rao-reset']) && $_GET['rao-reset'] == 'true') {
    delete_option('rao_add_ons'); 
}

//Output settings form
function rao_plugin_settings_page() { ?>

    <div id="tabs" class="wrap ui-tabs">

        <h1><?php esc_html_e('Rype Add-Ons', 'rype-add-ons'); ?></h1>

        <form method="post" action="options.php" class="rao-modules-form">
            <?php settings_fields( 'rao-settings-group' ); ?>
            <?php do_settings_sections( 'rao-settings-group' ); ?>

            <div class="rao-settings-header admin-module no-padding-bottom no-padding-top">
                <div class="ui-tabs-nav rao-nav">
                    <ul>
                        <li><a href="#rao-modules"><?php esc_html_e('Add-Ons', 'rype-add-ons'); ?></a></li>
                        <li><a href="#rao-license"><?php esc_html_e('License', 'rype-add-ons'); ?></a></li>
                        <li><a href="#rao-help"><?php esc_html_e('Help', 'rype-add-ons'); ?></a></li>
                    </ul>
                </div>
                <div class="rao-actions">
                    <?php
                    $plugin_data = get_plugin_data( __FILE__ );
                    $plugin_version = $plugin_data['Version']; 
                    ?>
                    <div class="right">
                        <a href="<?php echo admin_url(); ?>admin.php?page=rao-plugin-settings&rao-reset=true" class="button button-secondary rao-reset"><?php esc_html_e('Reset to Default', 'rype-add-ons'); ?></a>
                        <?php submit_button(esc_html__('Save Changes', 'rype-add-ons'), 'admin-button', 'submit', false); ?> 
                    </div> 
                </div>
                <div class="clear"></div>
            </div>

            <div id="rao-modules" class="rao-settings-content rao-modules">
                <div class="rao-module-group rao-module-group-basic">
                    <?php echo rao_display_add_ons(); ?>   
                </div>
            </div>

            <div id="rao-license" class="rao-settings-content rao-license">
                <table class="admin-module no-border">
                    <tr>
                        <td class="admin-module-label">
                            <label><?php echo esc_html_e('License Key', 'rype-add-ons'); ?></label>
                            <div class="admin-module-note"><?php echo esc_html_e('Enter your license key here.', 'rype-add-ons'); ?></div>
                        </td>
                        <td class="admin-module-field">
                            <input type="text" id="license_key" name="rao_license_key" value="<?php echo esc_attr( get_option('rypecore_license_key') ); ?>" />
                        </td>
                    </tr>
                </table>
            </div>

            <div id="rao-help" class="rao-settings-content rao-help">
                This is the help page
            </div>

            <div class="rao-settings-footer admin-module no-padding-top no-padding-bottom">
                <div class="rao-version left"><?php esc_html_e('Version', 'rype-add-ons'); ?> <?php echo $plugin_version; ?> | <?php esc_html_e('Made by', 'rype-add-ons'); ?> <a href="http://rypecreative.com/" target="_blank">Rype Creative</a> | <a href="http://rypecreative.com/contact/#theme-support" target="_blank"><?php esc_html_e('Get Support', 'rype-add-ons'); ?></a></div>
                <div class="right">
                    <a href="<?php echo admin_url(); ?>admin.php?page=rao-plugin-settings&rao-reset=true" class="button button-secondary rao-reset"><?php esc_html_e('Reset to Default', 'rype-add-ons'); ?></a>
                    <?php submit_button(esc_html__('Save Changes', 'rype-add-ons'), 'admin-button', 'submit', false); ?>
                </div>
                <div class="clear"></div>
            </div>

        </form>
    </div><!-- end wrap -->
<?php }


/*-----------------------------------------------------------------------------------*/
/*  INCLUDE ADD-ONS
/*-----------------------------------------------------------------------------------*/

/*************************************/
/*  Misc/helper Functions */
/*************************************/
include( plugin_dir_path( __FILE__ ) . 'add-ons/misc.php');

/*************************************/
/*  Social Share */
/*************************************/
if(rao_is_active('rao_post_share')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/social-share.php'); }

/*************************************/
/*  Post Likes */
/*************************************/
if(rao_is_active('rao_post_likes')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/post-likes/post-likes.php'); }

/*************************************/
/*  Advanced Page Settings */
/*************************************/
if(rao_is_active('rao_page_settings')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/advanced-page-settings.php'); }

/*************************************/
/*  Slides */
/*************************************/
if(rao_is_active('rao_slides')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/slides.php'); }

/*************************************/
/*  Basic Shortcodes */
/*************************************/
if(rao_is_active('rao_shortcodes')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/basic-shortcodes/shortcodes.php'); }

/*************************************/
/*  Basic Widgets */
/*************************************/
if(rao_is_active('rao_widgets')) {
    include('add-ons/basic-widgets/contact_info_widget.php');
    include('add-ons/basic-widgets/social_links_widget.php');
    include('add-ons/basic-widgets/list_posts_widget.php');
    include('add-ons/basic-widgets/testimonials_widget.php');
}

/*************************************/
/*  Job Board */
/*************************************/
if(rao_is_active('rao_job_board')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/job-board/job-board.php'); }

function rao_add_job_board_notice() {
    if(!rao_is_active('rao_job_board') && current_theme_supports('rao-job-board')) {
        $class = 'notice notice-error is-dismissible';
        $message = wp_kses_post(__( 'Rype Job Board add-on is <strong>de-activated!</strong> Please activate the job board add-on <a href="'.get_admin_url().'admin.php?page=rao-plugin-settings">here.</a>', 'rype-add-ons' ));
        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), $message ); 
    }
}
add_action( 'admin_notices', 'rao_add_job_board_notice' );

/*************************************/
/*  Real Estate */
/*************************************/
if(rao_is_active('rao_real_estate')) { include( plugin_dir_path( __FILE__ ) . 'add-ons/real-estate/real-estate.php'); }

function rao_add_real_estate_notice() {
    if(!rao_is_active('rao_real_estate') && current_theme_supports('rao-real-estate')) {
        $class = 'notice notice-error is-dismissible';
        $message = wp_kses_post(__( 'Rype Real Estate add-on is <strong>de-activated!</strong> Please activate the real estate add-on <a href="'.get_admin_url().'admin.php?page=rao-plugin-settings">here.</a>', 'rype-add-ons' ));
        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), $message ); 
    }
}
add_action( 'admin_notices', 'rao_add_real_estate_notice' );

/*************************************/
/*  Members */
/*************************************/
include( plugin_dir_path( __FILE__ ) . 'add-ons/members/members.php');