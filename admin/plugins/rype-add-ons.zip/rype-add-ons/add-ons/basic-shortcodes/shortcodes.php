<?php 
add_action( 'media_buttons', function($editor_id) { ?>
    <div id="shortcode-selector" style="display:none;">
        <div>
            <div class="shortcode-selector-list">
                <p><?php esc_html_e('Choose a shortcode to insert from the list below:', 'rype-add-ons'); ?></p>
                <a href="#basic-row" class="button"><i class="fa fa-align-justify"></i><?php esc_html_e('Row', 'rype-add-ons'); ?></a>
                <a href="#basic-col" class="button has-options"><i class="fa fa-columns"></i><?php esc_html_e('Column', 'rype-add-ons'); ?></a>
                <a href="#basic-module" class="button has-options"><i class="fa fa-expand"></i><?php esc_html_e('Module', 'rype-add-ons'); ?></a>
                <a href="#basic-module-header" class="button has-options"><i class="fa fa-font"></i><?php esc_html_e('Module Header', 'rype-add-ons'); ?></a>
                <a href="#basic-button" class="button has-options"><i class="fa fa-link"></i><?php esc_html_e('Button', 'rype-add-ons'); ?></a>
                <a href="#basic-video" class="button has-options"><i class="fa fa-play"></i><?php esc_html_e('Video', 'rype-add-ons'); ?></a>
                <a href="#basic-alert" class="button has-options"><i class="fa fa-bell"></i><?php esc_html_e('Alert Box', 'rype-add-ons'); ?></a>
                <a href="#basic-service" class="button has-options"><i class="fa fa-check"></i><?php esc_html_e('Service', 'rype-add-ons'); ?></a>
                <a href="#basic-team-member" class="button has-options"><i class="fa fa-user"></i><?php esc_html_e('Team Member', 'rype-add-ons'); ?></a>
                <a href="#basic-tabs" class="button has-options"><i class="fa fa-list"></i><?php esc_html_e('Tabs', 'rype-add-ons'); ?></a>
                <a href="#basic-accordion" class="button has-options"><i class="fa fa-list"></i><?php esc_html_e('Accordion', 'rype-add-ons'); ?></a>
                <a href="#basic-testimonials" class="button has-options"><i class="fa fa-comments"></i><?php esc_html_e('Testimonials', 'rype-add-ons'); ?></a>
            </div>
            <div class="shortcode-selector-options">
                <div class="button cancel-shortcode"><i class="fa fa-reply"></i> <?php esc_html_e('Go Back', 'rype-add-ons'); ?></div>

                <div id="basic-col" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Column', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block">
                        <label><?php esc_html_e('Width', 'rype-add-ons'); ?></label>
                        <select class="basic-col-width">
                            <option value="2"><?php esc_html_e('Sixth', 'rype-add-ons'); ?></option>
                            <option value="3"><?php esc_html_e('Quarter', 'rype-add-ons'); ?></option>
                            <option value="4"><?php esc_html_e('Third', 'rype-add-ons'); ?></option>
                            <option value="6" selected><?php esc_html_e('Half', 'rype-add-ons'); ?></option>
                            <option value="12"><?php esc_html_e('Full', 'rype-add-ons'); ?></option>
                        </select>
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-module" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Module', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block" style="margin:15px 0px;">
                        <input type="checkbox" class="basic-module-container" value="true" checked />
                        <label style="display:inline;"><?php esc_html_e('Container', 'rype-add-ons'); ?></label>
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('CSS Class Name', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-module-class" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Padding Top', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-module-padding-top" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Padding Bottom', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-module-padding-bottom" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Margin Top', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-module-margin-top" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Margin Bottom', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-module-margin-bottom" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Background Color', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-module-bg-color color-field" data-default-color="#ffffff" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Background Image', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-module-bg-img" value="" />
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-module-header" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Module Header', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block">
                        <label><?php esc_html_e('Title', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-module-header-title" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Text', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-module-header-text" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Position', 'rype-add-ons'); ?></label>
                        <select class="basic-module-header-position">
                            <option value="left"><?php esc_html_e('Left', 'rype-add-ons'); ?></option>
                            <option value="center"><?php esc_html_e('Center', 'rype-add-ons'); ?></option>
                            <option value="right"><?php esc_html_e('Right', 'rype-add-ons'); ?></option>
                        </select>
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-alert" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Service', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block">
                        <label><?php esc_html_e('Title', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-alert-title" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Type', 'rype-add-ons'); ?></label>
                        <select class="basic-alert-type">
                            <option value="success"><?php esc_html_e('Success', 'rype-add-ons'); ?></option>
                            <option value="error"><?php esc_html_e('Error', 'rype-add-ons'); ?></option>
                            <option value="warning"><?php esc_html_e('Warning', 'rype-add-ons'); ?></option>
                            <option value="info"><?php esc_html_e('Info', 'rype-add-ons'); ?></option>
                        </select>
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-service" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Alert Box', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block">
                        <label><?php esc_html_e('Icon', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-service-icon-fa" placeholder="Font Awesome" value="" />
                        <input type="text" class="basic-service-icon-line" placeholder="Line Icon" value="" />
                        <input type="text" class="basic-service-icon-dripicon" placeholder="Dripicon" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Title', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-service-title" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Text', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-service-text" value="" />
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-team-member" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Team Member', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block">
                        <label><?php esc_html_e('Image', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-img" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Name', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-name" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Title/Position', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-title" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Bio', 'rype-add-ons'); ?></label>
                        <textarea class="basic-team-member-bio"></textarea>
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Facebook', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-fb" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Twitter', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-twitter" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Google Plus', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-google" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Instagram', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-instagram" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Linkedin', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-linkedin" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Youtube', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-youtube" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Vimeo', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-vimeo" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Flickr', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-flickr" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Dribbble', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-team-member-dribbble" value="" />
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-button" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Button', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block">
                        <label><?php esc_html_e('Button Text', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-button-text" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Button URL', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-button-url" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Button Type', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-button-type" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Button Position', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-button-position" value="" />
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-video" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Button', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block">
                        <label><?php esc_html_e('Title', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-video-title" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Video URL', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-video-url" value="" />
                    </div>
                    <div class="form-block">
                        <label><?php esc_html_e('Cover Image', 'rype-add-ons'); ?></label>
                        <input type="text" class="basic-video-cover" value="" />
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-tabs" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Tabs', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block form-block-tabs">
                        <a href="#" class="button create-tab"><i class="fa fa-plus"></i> <?php esc_html_e('Create Tab', 'rype-add-ons'); ?></a>
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-accordion" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Accordion', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block form-block-accordion">
                        <a href="#" class="button create-accordion"><i class="fa fa-plus"></i> <?php esc_html_e('Create Accordion', 'rype-add-ons'); ?></a>
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

                <div id="basic-testimonials" class="admin-module">
                    <h3><strong><?php esc_html_e('Insert Testimonials', 'rype-add-ons'); ?></strong></h3>
                    <div class="form-block form-block-testimonials">
                        <a href="#" class="button create-testimonial"><i class="fa fa-plus"></i> <?php esc_html_e('Create Testimonial', 'rype-add-ons'); ?></a>
                    </div>
                    <a href="#" class="button button-primary insert-shortcode"><?php esc_html_e('Insert', 'rype-add-ons'); ?></a>
                </div>

            </div>
        </div>
    </div>
    <a href="#TB_inline?width=600&height=450&inlineId=shortcode-selector" class="button thickbox add-shortcode" title="Add Shortcode"><span class="wp-media-buttons-icon add-shortcode-icon"></span><?php esc_html_e('Add Shortcode', 'rype-add-ons'); ?></a>
<?php } ); 


//REMOVE <p> AND <br/> TAGS FROM SHORTCODE CONTENT
function rao_content_filter($content) {
    $block = join("|",array('rao_module', 'rao_module_header', 'rao_row', 'rao_col', 'rao_button', 'rao_button_alt', 'rao_quote', 'rao_alert_box', 'rao_service', 'rao_team_member', 'rao_testimonials', 'rao_testimonial', 'rao_tabs', 'rao_tab', 'rao_accordions', 'rao_accordion'));
    $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
    $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
return $rep;
}
add_filter("the_content", "rao_content_filter");

/****************************************************************************/
/* GLOBAL */
/****************************************************************************/

/* MODULE */
add_shortcode('rao_module', 'rao_module');
function rao_module($atts, $content=null) {
    $atts = shortcode_atts(
        array (
        'class' => '',
        'container' => 'true',
        'padding_top' => '',
        'padding_bottom' => '',
        'margin_top' => '',
        'margin_bottom' => '',
        'bg_color' => '',
        'bg_img' => '',
        'bg_fixed' => '',
        'text_color' => '',
    ), $atts);

    if(!empty($atts['padding_top'])) { $padding_top = 'padding-top:'.$atts['padding_top'].';'; } else { $padding_top = ''; }
    if(!empty($atts['padding_bottom'])) { $padding_bottom = 'padding-bottom:'.$atts['padding_bottom'].';'; } else { $padding_bottom = ''; }
    if(!empty($atts['margin_top'])) { $margin_top = 'margin-top:'.$atts['margin_top'].';'; } else { $margin_top = ''; }
    if(!empty($atts['margin_bottom'])) { $margin_bottom = 'margin-bottom:'.$atts['margin_bottom'].';'; } else { $margin_bottom = ''; }
    if(!empty($atts['bg_color'])) { $bg_color = 'background:'.$atts['bg_color'].';'; } else { $bg_color = ''; }
    if(!empty($atts['bg_fixed'])) { $bg_fixed = 'background-attachment:fixed;'; } else { $bg_fixed=''; }
    if(!empty($atts['bg_img'])) { $bg_img = 'background:'.$atts['bg_color'].' url('.$atts['bg_img'].') no-repeat center; background-size:cover;'.$bg_fixed; } else { $bg_img = ''; }

    if ($atts['container'] == 'false') {
        return '<section class="module ' . $atts['text_color'] .' '. $atts['class'] .'" style="'.$padding_top . $padding_bottom . $margin_top . $margin_bottom . $bg_color . $bg_img .'" >'. do_shortcode($content) .'</section>';
    } else {
        return '<section class="module ' . $atts['text_color'] .' '. $atts['class'] .'" style="'.$padding_top . $padding_bottom . $margin_top . $margin_bottom . $bg_color . $bg_img .'" ><div class="container">'. do_shortcode($content) .'</div></section>';
    }
}

/** MODULE HEADER **/
add_shortcode('rao_module_header', 'rao_module_header');
function rao_module_header($atts, $content=null) {

    $atts = shortcode_atts(
        array (
        'title' => '',
        'text' => '',
        'position' => '',
    ), $atts);

    if(!empty($atts['title'])) { $title = '<h2>'.$atts['title'].'</h2>'; } else { $title = ''; }
    if(!empty($atts['text'])) { $text = '<p>'.$atts['text'].'</p>'; } else { $text = ''; }
    
    if($atts['position'] == 'left') { 
        $position = 'module-header-left';
        $widget_divider = '<table class="widget-divider"><tr><td><div class="rhex"></div></td><td><div class="bar"></div></td></tr></table>'; 
    } else if($atts['position'] == 'right') { 
        $position = 'module-header-right'; 
        $widget_divider = '<table class="widget-divider"><tr><td><div class="bar"></div></td><td><div class="rhex"></div></td></tr></table>';
    } else { 
        $position = ''; 
        $widget_divider = '<table class="widget-divider"><tr><td><div class="bar"></div></td><td><div class="rhex"></div></td><td><div class="bar"></div></td></tr></table>';
    } 

    return '<div class="module-header '.$position.'">'.$title . $widget_divider . $text.'</div>';
}

/* ROW */
add_shortcode('rao_row', 'rao_row');
function rao_row($atts, $content=null) {
	return '<div class="row">'. do_shortcode($content) .'</div>';
}

/* COLUMN */
add_shortcode('rao_col', 'rao_col');
function rao_col($atts, $content=null) {
	$atts = shortcode_atts(
		array (
		'span' => '4'
	), $atts);

	return '<div class="col-lg-'. $atts['span'] .' col-md-'. $atts['span'] .'">'. do_shortcode($content) .'</div>';
}

/* BUTTON (DEFAULT) */
add_shortcode('rao_button', 'rao_button');
function rao_button($atts, $content = null) {
	$atts = shortcode_atts(
		array (
			'url' => '#',
			'type' => '',
			'position' => '',
		), $atts);

	if ($atts['position'] == 'center') {
		return '<div style="width:100%; text-align:center;"><a href="'. $atts['url'] .'" class="button '. $atts['type'] .'">'. ucwords($content) .'</a></div>';
	} else {
		return '<a href="'. $atts['url'] .'" class="button '. $atts['type'] .' '. $atts['position'] .'">'. ucwords($content) .'</a>';
	}
}

/* BUTTON ALTERNATIVE */
add_shortcode('rao_button_alt', 'rao_button_alt');
function rao_button_alt($atts, $content = null) {
	$atts = shortcode_atts(
		array (
			'url' => '#',
			'type' => '',
			'position' => '',
		), $atts);

	if ($atts['position'] == 'center') {
		return '<div style="width:100%; text-align:center;"><a href="'. $atts['url'] .'" class="button alt '. $atts['type'] .'">'. ucwords($content) .'</a></div>';
	} else {
		return '<a href="'. $atts['url'] .'" class="button alt '. $atts['type'] .' '. $atts['position'] .'">'. ucwords($content) .'</a>';
	}
}

/* QUOTE */
add_shortcode('rao_quote', 'rao_quote');
function rao_quote($atts, $content = null) {
	return '<blockquote>'. wp_kses_post($content) .'</blockquote>';
}

/* ALERT BOXES */
add_shortcode('rao_alert_box', 'rao_alert_box');
function rao_alert_box($atts, $content = null) {
	$atts = shortcode_atts(
		array (
			'title' => '',
			'type' => 'success'
		), $atts);

	return '
	<div class="alert-box '. $atts['type'] .'">
        <h4>'. wp_kses_post($content) .'</h4>
    </div>
	';
}

/** SERVICES **/
add_shortcode('rao_service', 'rao_service');
function rao_service($atts, $content = null) {
    $icon_set = get_option('rypecore_icon_set', 'fa');

    $atts = shortcode_atts(
        array (
            'icon' => '',
            'icon_line' => '',
            'dripicon' => '',
            'title' => '',
            'text' => ''
        ), $atts);

    if(!empty($atts['icon'])) { $icon =  rypecore_get_icon($icon_set, $atts['icon'], $atts['icon_line'], $atts['dripicon']); } else { $icon = ''; }
    if(!empty($atts['title'])) { $title =  '<h4>'. $atts['title'] .'</h4>'; } else { $title = ''; }

    return '
        <div class="service-item shadow-hover">
            '. $icon .'
            '. $title .'
            <p>'. $atts['text'] .'</p>
        </div>
    ';
}

/** TEAM MEMBER **/
add_shortcode('rao_team_member', 'rao_team_member');
function rao_team_member($atts, $content = null) {
    $atts = shortcode_atts(
        array (
            'img' => '',
            'name' => '',
            'title' => '',
            'bio' => '',
            'facebook' => '',
            'twitter' => '',
            'google' => '',
            'instagram' => '',
            'linkedin' => '',
            'youtube' => '',
            'vimeo' => '',
            'flickr' => '',
            'dribbble' => ''
        ), $atts);

    $output = '';
    $output .= '<div class="team-member shadow-hover">';
    if(!empty($atts['img'])) { 
        $output .= '<div class="team-member-img"><p>'.$atts['bio'].'</p><div class="img-overlay"></div><div class="img-fade"></div><img src="'.$atts['img'].'" alt="" /></div>'; 
    } else {
        $output .= '<div class="team-member-img"><p>'.$atts['bio'].'</p><div class="img-overlay"></div><div class="img-fade"></div><img src="'.get_template_directory_uri().'/images/agent-img-default.gif" alt="" /></div>'; 
    }
    $output .= '<div class="team-member-content"><img class="hex" src="'.get_template_directory_uri() .'/images/hexagon.png" alt="" /><h4>'.$atts['name'].'</h4><p>'.$atts['title'].'</p>';
    $output .= '<ul class="social-icons circle">';
    if(!empty($atts['facebook'])) { $output .= '<li><a target="_blank" href="'.$atts['facebook'].'"><i class="fa fa-facebook"></i></a></li>'; }
    if(!empty($atts['twitter'])) { $output .= '<li><a target="_blank" href="'.$atts['twitter'].'"><i class="fa fa-twitter"></i></a></li>'; }
    if(!empty($atts['google'])) { $output .= '<li><a target="_blank" href="'.$atts['google'].'"><i class="fa fa-google-plus"></i></a></li>'; }
    if(!empty($atts['instagram'])) { $output .= '<li><a target="_blank" href="'.$atts['instagram'].'"><i class="fa fa-instagram"></i></a></li>'; }
    if(!empty($atts['linkedin'])) { $output .= '<li><a target="_blank" href="'.$atts['linkedin'].'"><i class="fa fa-linkedin"></i></a></li>'; }
    if(!empty($atts['youtube'])) { $output .= '<li><a target="_blank" href="'.$atts['youtube'].'"><i class="fa fa-youtube"></i></a></li>'; }
    if(!empty($atts['vimeo'])) { $output .= '<li><a target="_blank" href="'.$atts['vimeo'].'"><i class="fa fa-vimeo"></i></a></li>'; }
    if(!empty($atts['flickr'])) { $output .= '<li><a target="_blank" href="'.$atts['flickr'].'"><i class="fa fa-flickr"></i></a></li>'; }
    if(!empty($atts['dribbble'])) { $output .= '<li><a target="_blank" href="'.$atts['dribbble'].'"><i class="fa fa-dribbble"></i></a></li>'; }
    $output .= '</ul>';
    $output .= '</div>';
    $output .= '</div>';

    return $output;
}

/** VIDEO **/
add_shortcode('rao_video', 'rao_video');
function rao_video($atts, $content = null) {
    $atts = shortcode_atts(
        array (
            'title' => '',
            'url' => '',
            'cover_img' => ''
        ), $atts);

    $output = '';
    $output .= '<a data-fancybox class="video-cover" href="'.$atts['url'].'" title="'.$atts['title'].'">';
    $output .= '<div class="video-cover-content"><i class="fa fa-play icon"></i><p>'.$atts['title'].'</p></div>';
    if(!empty($atts['cover_img'])) { $output .= '<img src="'. $atts['cover_img'] .'" alt="'. $atts['title'] .'" />'; }
    $output .= '</a>';

    return $output;
}

/** TABS **/
$tabs_divs = '';

add_shortcode('rao_tabs', 'rao_tabs');
function rao_tabs($atts, $content=null) {
    global $tabs_divs;
    $tabs_divs = '';

    return '<div class="tabs"><ul class="clean-list">'. do_shortcode(wp_kses_post($content)) .'</ul><div class="panel-container">'. $tabs_divs .'</div></div>';
}

add_shortcode('rao_tab', 'rao_tab');
function rao_tab($atts, $content=null) {
    global $tabs_divs;
    $icon_set = get_option('rypecore_icon_set', 'fa');

    $atts = shortcode_atts(
        array (
            'id' => '',
            'title' => '',
            'icon' => '',
            'icon_line' => '',
            'dripicon' => '',
        ), $atts);

    if(!empty($atts['icon'])) { $icon = rypecore_get_icon($icon_set, $atts['icon'], $atts['icon_line'], $atts['dripicon']); } else { $icon = ''; }

    $tabs_divs.= '<div id="tab'. $atts['id'] .'">'.$content.'</div>';

    return '<li><a href="#tab'. $atts['id'] .'">'. $icon . $atts['title'] .'</a></li>';
}

/** ACCORDION **/
add_shortcode('rao_accordions', 'rao_accordions');
function rao_accordions($atts, $content=null) {
    return '<div id="accordion" class="content">'. do_shortcode(wp_kses_post($content)) .'</div>';
}

add_shortcode('rao_accordion', 'rao_accordion');
function rao_accordion($atts, $content=null) {
    $atts = shortcode_atts(
        array (
            'title' => '',
        ), $atts);

    return '
        <h3>'. $atts['title'] .'</h3>
        <div>'. wp_kses_post($content) .'</div>
    ';
}


/****************************************************************************/
/* MISC */
/****************************************************************************/

/** TESTIMONIALS **/
add_shortcode('rao_testimonials', 'rao_testimonials');
function rao_testimonials($atts, $content=null) {

	$output = '';
    $output .= '<div class="slider-wrap slider-wrap-testimonials">';
    $output .= '<div class="slider-nav slider-nav-testimonials">';
    $output .= '<span class="slider-prev slick-arrow"><i class="fa fa-angle-left"></i></span>';
    $output .= '<span class="slider-next slick-arrow"><i class="fa fa-angle-right"></i></span>';
    $output .= '</div>';
    $output .= '<div class="slider slider-testimonials">'. do_shortcode($content) .'</div>';
    $output .= '</div>';

    return $output;
}

add_shortcode('rao_testimonial', 'rao_testimonial');
function rao_testimonial($atts, $content=null) {
    $atts = shortcode_atts(
        array (
        'img' => '',
        'name' => '',
        'title' => '',
    ), $atts);

	$output = '';
    $output .= '<div class="testimonial slide">';
    $output .= '<h3>'. do_shortcode($content) .'</h3>';
    $output .= '<div class="testimonial-details">';
    if(!empty($atts['img']))  { $output .= '<img class="testimonial-img" src="'. $atts['img'] .'" alt="" />'; }
    if(!empty($atts['name']))  { $output .= '<span class="testimonial-name"><strong>'. $atts['name'] .'</strong></span>'; }
    if(!empty($atts['title']))  { $output .= '<span class="testiomnial-title"><em>'. $atts['title'] .'</em></span>'; }
    $output .= '</div>';
    $output .= '</div>';

    return $output;
}

?>