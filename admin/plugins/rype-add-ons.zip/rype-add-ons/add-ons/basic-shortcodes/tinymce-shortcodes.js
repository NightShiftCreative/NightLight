/********************************************/
/* BUTTON */
/********************************************/
(function() {
       tinymce.create('tinymce.plugins.rc_button', {
          init : function(ed, url) {
             ed.addButton('rc_button', {
                title : 'Button',
                text: 'Button',
                classes: 'rc_mce_btn',
                image : url+'/icons/button-icon.png',
                onclick : function() {
                   ed.windowManager.open({
                        title: 'Insert Button',
                        body: [{
                            type: 'textbox',
                            name: 'buttonURL',
                            label: 'Button URL',
                            value: ''
                        }, {
                            type: 'listbox',
                            name: 'buttonType',
                            label: 'Button Size',
                            values: [{
                                text: 'Medium',
                                value: ''
                            }, {
                                text: 'Small',
                                value: 'small'
                            }, {
                                text: 'Large',
                                value: 'large'
                            }]
                        }, {
                            type: 'listbox',
                            name: 'buttonPos',
                            label: 'Button Position',
                            values: [{
                                text: 'Left',
                                value: 'left'
                            }, {
                                text: 'Right',
                                value: 'right'
                            }, {
                                text: 'Center',
                                value: 'center'
                            }]
                        }, ],
                        onsubmit: function(e) {
                            ed.insertContent('[rao_button type="' +e.data.buttonType +'" url="' +e.data.buttonURL +'" position="' +e.data.buttonPos +'"][/rao_button]');
                        }
                    });
                }
             });
          },
          createControl : function(n, cm) { return null; },
          getInfo : function() {
             return {
                longname : "Button",
                author : 'Rype Creative',
                authorurl : 'http://www.rypecreative.com',
                infourl : '',
                version : "1.0"
             };
          }
    });
    tinymce.PluginManager.add('rc_button', tinymce.plugins.rc_button);
})();

/********************************************/
/* ALERT BOX */
/********************************************/
(function() {
       tinymce.create('tinymce.plugins.alert', {
          init : function(ed, url) {
             ed.addButton('alert', {
                title : 'Alert Box',
                text: 'Alert Box',
                classes: 'rc_mce_btn',
                image : url+'/icons/alert-icon.png',
                onclick : function() {
                   ed.windowManager.open({
                        title: 'Insert Alert Box',
                        body: [{
                            type: 'listbox',
                            name: 'alertType',
                            label: 'Alert Type',
                            values: [{
                                text: 'Success',
                                value: 'success'
                            }, {
                                text: 'Warning',
                                value: 'warning'
                            }, {
                                text: 'Error',
                                value: 'error'
                            }, {
                                text: 'Info',
                                value: 'info'
                            }]
                        }, ],
                        onsubmit: function(e) {
                            ed.insertContent('[rao_alert_box type="' +e.data.alertType +'"][/rao_alert_box]');
                        }
                    });
                }
             });
          },
          createControl : function(n, cm) { return null; },
          getInfo : function() {
             return {
                longname : "Alert Box",
                author : 'Rype Creative',
                authorurl : 'http://www.rypecreative.com',
                infourl : '',
                version : "1.0"
             };
          }
    });
    tinymce.PluginManager.add('alert', tinymce.plugins.alert);
})();

/********************************************/
/* SERVICE */
/********************************************/
(function() {
       tinymce.create('tinymce.plugins.service', {
          init : function(ed, url) {
             ed.addButton('service', {
                title : 'Service',
                text: 'Service',
                classes: 'rc_mce_btn',
                image : url+'/icons/service-icon.png',
                onclick : function() {
                   ed.windowManager.open({
                        title: 'Insert Service',
                        body: [{
                            type: 'textbox',
                            name: 'serviceIcon',
                            label: 'Service Icon',
                            value: ''
                        }, {
                            type: 'textbox',
                            name: 'serviceTitle',
                            label: 'Service Title',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'serviceText',
                            label: 'Service Text',
                            values: ''
                        }, ],
                        onsubmit: function(e) {
                            ed.insertContent('[rao_service title="' +e.data.serviceTitle +'" icon="' +e.data.serviceIcon +'" text="' +e.data.serviceText +'"][/rao_service]');
                        }
                    });
                }
             });
          },
          createControl : function(n, cm) { return null; },
          getInfo : function() {
             return {
                longname : "Service",
                author : 'Rype Creative',
                authorurl : 'http://www.rypecreative.com',
                infourl : '',
                version : "1.0"
             };
          }
    });
    tinymce.PluginManager.add('service', tinymce.plugins.service);
})();

/********************************************/
/* TEAM MEMBER */
/********************************************/
(function() {
       tinymce.create('tinymce.plugins.team', {
          init : function(ed, url) {
             ed.addButton('team', {
                title : 'Team Member',
                text: 'Team Member',
                classes: 'rc_mce_btn',
                image : url+'/icons/team-icon.png',
                onclick : function() {
                   ed.windowManager.open({
                        title: 'Insert Team Member',
                        body: [{
                            type: 'textbox',
                            name: 'teamImg',
                            label: 'Image',
                            value: ''
                        }, {
                            type: 'textbox',
                            name: 'teamName',
                            label: 'Name',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamTitle',
                            label: 'Title/Position',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamBio',
                            label: 'Bio',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamFb',
                            label: 'Facebook URL',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamTwitter',
                            label: 'Twitter URL',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamGoogle',
                            label: 'Google URL',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamInsta',
                            label: 'Instagram URL',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamLinkedin',
                            label: 'Linkedin URL',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamYoutube',
                            label: 'Youtube URL',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamVimeo',
                            label: 'Vimeo URL',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamFlickr',
                            label: 'Flickr URL',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'teamDribbble',
                            label: 'Dribbble URL',
                            values: ''
                        } ],
                        onsubmit: function(e) {
                            ed.insertContent('[rao_team_member img="' +e.data.teamImg +'" name="' +e.data.teamName +'" bio="' +e.data.teamBio +'" title="' +e.data.teamTitle +'" facebook="' +e.data.teamFb +'" twitter="' +e.data.teamTwitter +'" google="' +e.data.teamGoogle +'" instagram="' +e.data.teamInsta +'" linkedin="' +e.data.teamLinkedin +'" youtube="' +e.data.teamYoutube +'" vimeo="' +e.data.teamVimeo +'" flickr="' +e.data.teamFlickr +'" dribbble="' +e.data.teamDribbble +'"][/rao_team_member]');
                        }
                    });
                }
             });
          },
          createControl : function(n, cm) { return null; },
          getInfo : function() {
             return {
                longname : "Team Member",
                author : 'Rype Creative',
                authorurl : 'http://www.rypecreative.com',
                infourl : '',
                version : "1.0"
             };
          }
    });
    tinymce.PluginManager.add('team', tinymce.plugins.team);
})();

/********************************************/
/* VIDEO  */
/********************************************/
(function() {
       tinymce.create('tinymce.plugins.video', {
          init : function(ed, url) {
             ed.addButton('video', {
                title : 'Video',
                text: 'Video',
                classes: 'rc_mce_btn',
                image : url+'/icons/video-icon.png',
                onclick : function() {
                   ed.windowManager.open({
                        title: 'Insert Video',
                        body: [{
                            type: 'textbox',
                            name: 'videoTitle',
                            label: 'Video Title',
                            value: ''
                        }, {
                            type: 'textbox',
                            name: 'videoURL',
                            label: 'Video URL',
                            values: ''
                        }, {
                            type: 'textbox',
                            name: 'videoCover',
                            label: 'Video Cover Image URL',
                            values: ''
                        }, ],
                        onsubmit: function(e) {
                            ed.insertContent('[rao_video title="' +e.data.videoTitle +'" url="' +e.data.videoURL +'" cover_img="' +e.data.videoCover +'"][/rao_video]');
                        }
                    });
                }
             });
          },
          createControl : function(n, cm) { return null; },
          getInfo : function() {
             return {
                longname : "Video",
                author : 'Rype Creative',
                authorurl : 'http://www.rypecreative.com',
                infourl : '',
                version : "1.0"
             };
          }
    });
    tinymce.PluginManager.add('video', tinymce.plugins.video);
})();