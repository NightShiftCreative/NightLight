<?php

/*-----------------------------------------------------------------------------------*/
/*  Include Job Board Admin Scripts and Styles
/*-----------------------------------------------------------------------------------*/
function rao_load_job_board_admin_scripts() {
    
    if (is_admin()) {
        //custom scripts
        wp_enqueue_script('rao-admin-job-board-js', plugins_url('/js/admin-job-board.js', __FILE__), array('jquery','media-upload','thickbox'), '', true);
        wp_enqueue_style('rao-admin-job-board-css', plugins_url('/css/admin-job-board.css',  __FILE__), array(), '1.0', 'all');

        /* localize scripts */
        $translation_array = array(
            'admin_url' => esc_url(get_admin_url()),
            'delete_text' => __( 'Delete', 'rype-add-ons' ),
            'remove_text' => __( 'Remove', 'rype-add-ons' ),
            'edit_text' => __( 'Edit', 'rype-add-ons' ),
            'upload_img' => __( 'Upload Image', 'rype-add-ons' ),
            'new_item' => __( 'New Item', 'rype-add-ons' ),
            'education_title' => __( 'Organization:', 'rype-add-ons' ),
            'education_diploma' => __( 'Diploma:', 'rype-add-ons' ),
            'start_year' => __( 'Start Year:', 'rype-add-ons' ),
            'end_year' => __( 'End Year:', 'rype-add-ons' ),
            'description_text' => __( 'Description:', 'rype-add-ons' ),
            'experience_organization' => __( 'Organization:', 'rype-add-ons' ),
            'experience_title' => __( 'Professional Title:', 'rype-add-ons' ),
        );
        wp_localize_script( 'rao-admin-job-board-js', 'rao_local_script', $translation_array );
    }

}
add_action('admin_enqueue_scripts', 'rao_load_job_board_admin_scripts');

/*-----------------------------------------------------------------------------------*/
/*  Include Job Board Front-End Scripts and Styles
/*-----------------------------------------------------------------------------------*/
function rao_load_job_board_front_end_scripts() {
    if (!is_admin()) {
        wp_enqueue_script('rao-job-board-js', plugins_url('/js/job-board.js', __FILE__), array('jquery','media-upload','thickbox'), '', true);
    }
}
add_action('wp_enqueue_scripts', 'rao_load_job_board_front_end_scripts');

/*-----------------------------------------------------------------------------------*/
/*  Include Job Board Shortcodes
/*-----------------------------------------------------------------------------------*/
include( plugin_dir_path( __FILE__ ) . '/includes/job-board-shortcodes.php');

/*-----------------------------------------------------------------------------------*/
/*  Include Job Board Widgets
/*-----------------------------------------------------------------------------------*/
include( plugin_dir_path( __FILE__ ) . '/includes/widgets/job-filter-widget.php');

/*-----------------------------------------------------------------------------------*/
/*  Includes Job Board Theme Options
/*-----------------------------------------------------------------------------------*/
include( plugin_dir_path( __FILE__ ) . '/includes/job-board-theme-options.php');

/*-----------------------------------------------------------------------------------*/
/*  Includes Job Related Functions
/*-----------------------------------------------------------------------------------*/
include( plugin_dir_path( __FILE__ ) . '/includes/job-functions.php');

/*-----------------------------------------------------------------------------------*/
/*  Includes Company Related Functions
/*-----------------------------------------------------------------------------------*/
include( plugin_dir_path( __FILE__ ) . '/includes/company-functions.php');


?>