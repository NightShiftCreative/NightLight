/************************************************************/
/* RYPE ADD-ONS */
/* JOB BOARD - FRONT-END SCRIPTS */
/************************************************************/

jQuery(document).ready(function($) {

"use strict";

});