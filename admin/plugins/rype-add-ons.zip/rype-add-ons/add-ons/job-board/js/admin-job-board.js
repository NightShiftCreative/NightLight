/************************************************************/
/* RYPE ADD-ONS */
/* JOB BOARD - ADMIN SCRIPTS */
/************************************************************/

jQuery(document).ready(function($) {

"use strict";

});