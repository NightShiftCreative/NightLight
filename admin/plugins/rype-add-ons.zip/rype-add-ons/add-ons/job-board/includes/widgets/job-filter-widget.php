<?php
/**
 * Job Filter Widget Class
 */
class rao_job_filter_widget extends WP_Widget {

    /** constructor */
    function __construct() {

        $widget_options = array(
          'classname'=>'job-filter',
          'description'=> esc_html__('Displays a job filter form.', 'rype-add-ons'),
          'panels_groups' => array('rype-add-ons')
        );
		parent::__construct('rao_job_filter_widget', esc_html__('(Rype) Job Filter', 'rype-add-ons'), $widget_options);
    }

    /** @see WP_Widget::widget */
    function widget($args, $instance) {
        extract( $args );
		global $wpdb;

        $icon_set = get_option('rypecore_icon_set', 'fa');

        $title = apply_filters('widget_title', $instance['title']);
		$fields = $instance['fields'];

        ?>
              <?php echo wp_kses_post($before_widget); ?>
                  <?php if ( $title )
                        echo wp_kses_post($before_title . $title . $after_title); ?>

                        <?php 
                        echo rao_job_filter_form($fields, null, 'job-filter-widget-form'); 
                        ?>

              <?php echo wp_kses_post($after_widget); ?>
        <?php
    }

    /** @see WP_Widget::update */
    function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		
        $instance['fields'] = array();
        if ( isset ( $new_instance['fields'] ) ) {
            foreach ( $new_instance['fields'] as $value ) {
                if ( '' !== trim( $value ) )
                    $instance['fields'][] = $value;
            }
        }

        return $instance;
    }

    /** @see WP_Widget::form */
    function form($instance) {	

        $instance = wp_parse_args( (array) $instance, array( 'title' => '', 'fields' => null) );
        $title = esc_attr($instance['title']);
		$fields = isset ( $instance['fields'] ) ? $instance['fields'] : array('keywords', 'region', 'category');

        ?>

        <p>
	       <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'rype-add-ons'); ?></label>
	       <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
	    </p>

        <p>
            <input name="<?php echo esc_attr($this->get_field_name('fields')); ?>[]" type="checkbox" value="keywords" <?php if(in_array('keywords', $fields)) { echo 'checked'; } ?> />
            <label><?php esc_html_e('Keywords', 'rype-add-ons'); ?></label>
        </p>

        <p>
            <input name="<?php echo esc_attr($this->get_field_name('fields')); ?>[]" type="checkbox" value="region" <?php if(in_array('region', $fields)) { echo 'checked'; } ?> />
            <label><?php esc_html_e('Job Region', 'rype-add-ons'); ?></label>
        </p>

        <p>
            <input name="<?php echo esc_attr($this->get_field_name('fields')); ?>[]" type="checkbox" value="category" <?php if(in_array('category', $fields)) { echo 'checked'; } ?> />
            <label><?php esc_html_e('Job Category', 'rype-add-ons'); ?></label>
        </p>

        <p>
            <input name="<?php echo esc_attr($this->get_field_name('fields')); ?>[]" type="checkbox" value="type" <?php if(in_array('type', $fields)) { echo 'checked'; } ?> />
            <label><?php esc_html_e('Job Type', 'rype-add-ons'); ?></label>
        </p>

        <p>
            <input name="<?php echo esc_attr($this->get_field_name('fields')); ?>[]" type="checkbox" value="salary" <?php if(in_array('salary', $fields)) { echo 'checked'; } ?> />
            <label><?php esc_html_e('Salary', 'rype-add-ons'); ?></label>
        </p>

        <?php
    }

} // class utopian_recent_posts
add_action('widgets_init', create_function('', 'return register_widget("rao_job_filter_widget");'));

?>