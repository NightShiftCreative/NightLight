<?php

/*-----------------------------------------------------------------------------------*/
/*  Register Theme Options Settings
/*-----------------------------------------------------------------------------------*/
function rao_job_board_register_settings() { 
    //register home page settings
    register_setting( 'rypecore-settings-group', 'rypecore_home_search_banner_keywords_placeholder' );
    register_setting( 'rypecore-settings-group', 'rypecore_home_search_banner_location_placeholder' );
    register_setting( 'rypecore-settings-group', 'rypecore_home_search_banner_submit_text' );

    //register job settings
    register_setting( 'rypecore-settings-group', 'rypecore_job_listing_default_layout' );
    register_setting( 'rypecore-settings-group', 'rypecore_job_detail_default_layout' );
    register_setting( 'rypecore-settings-group', 'rypecore_job_detail_items' );

    //register company settings
    register_setting( 'rypecore-settings-group', 'rypecore_company_detail_items' );
}
add_action( 'rao_theme_option_register_settings', 'rao_job_board_register_settings' );

/*-----------------------------------------------------------------------------------*/
/*  Add Job Board Theme Option Menu Items
/*-----------------------------------------------------------------------------------*/
function rao_add_job_board_theme_options_menu_items() { ?>
    <li class="add-on-tab"><a href="#jobs"><i class="fa fa-briefcase"></i> <span class="ui-tab-text"><?php echo esc_html_e('Jobs', 'rype-add-ons'); ?></span></a></li>
    <li class="add-on-tab"><a href="#companies"><i class="fa fa-building"></i> <span class="ui-tab-text"><?php echo esc_html_e('Companies', 'rype-add-ons'); ?></span></a></li>
<?php }
add_action( 'rao_after_theme_option_menu', 'rao_add_job_board_theme_options_menu_items' );

/*-----------------------------------------------------------------------------------*/
/*  Load default Job Detail Items
/*-----------------------------------------------------------------------------------*/
function rao_load_default_job_detail_items() {
    $job_detail_items_default = array(
        0 => array(
            'name' => esc_html__('Overview', 'rype-add-ons'),
            'label' => esc_html__('Overview', 'rype-add-ons'),
            'slug' => 'overview',
            'active' => 'true',
            'sidebar' => 'false',
        ),
        1 => array(
            'name' => esc_html__('Description', 'rype-add-ons'),
            'label' => esc_html__('Description', 'rype-add-ons'),
            'slug' => 'description',
            'active' => 'true',
            'sidebar' => 'false',
        ),
        2 => array(
            'name' => esc_html__('Job Skills', 'rype-add-ons'),
            'label' => esc_html__('Job Skills', 'rype-add-ons'),
            'slug' => 'skills',
            'active' => 'true',
            'sidebar' => 'false',
        ),
        3 => array(
            'name' => esc_html__('Gallery', 'rype-add-ons'),
            'label' => esc_html__('Gallery', 'rype-add-ons'),
            'slug' => 'gallery',
            'active' => 'true',
            'sidebar' => 'false',
        ),
        4 => array(
            'name' => esc_html__('Video', 'rype-add-ons'),
            'label' => esc_html__('Video', 'rype-add-ons'),
            'slug' => 'video',
            'active' => 'true',
            'sidebar' => 'false',
        ),
        5 => array(
            'name' => esc_html__('Job Actions', 'rype-add-ons'),
            'label' => '',
            'slug' => 'actions',
            'active' => 'true',
            'sidebar' => 'true',
        ),
        6 => array(
            'name' => esc_html__('Company Info', 'rype-add-ons'),
            'label' => '',
            'slug' => 'company_info',
            'active' => 'true',
            'sidebar' => 'true',
        ),
        7 => array(
            'name' => esc_html__('Location', 'rype-add-ons'),
            'label' => esc_html__('Location', 'rype-add-ons'),
            'slug' => 'location',
            'active' => 'true',
            'sidebar' => 'true',
        ),
        8 => array(
            'name' => esc_html__('Related Jobs', 'rype-add-ons'),
            'label' => 'Other Jobs You May Like',
            'slug' => 'related',
            'active' => 'true',
            'sidebar' => 'false',
        ),
    );

    return $job_detail_items_default;
}

/*-----------------------------------------------------------------------------------*/
/*  Load default Company Detail Items
/*-----------------------------------------------------------------------------------*/
function rao_load_default_company_detail_items() {
    $company_detail_items_default = array(
        0 => array(
            'name' => esc_html__('Overview', 'rype-add-ons'),
            'label' => esc_html__('Overview', 'rype-add-ons'),
            'slug' => 'overview',
            'active' => 'true',
            'sidebar' => 'false',
        ),
        1 => array(
            'name' => esc_html__('Description', 'rype-add-ons'),
            'label' => esc_html__('Description', 'rype-add-ons'),
            'slug' => 'description',
            'active' => 'true',
            'sidebar' => 'false',
        ),
        2 => array(
            'name' => esc_html__('Video', 'rype-add-ons'),
            'label' => esc_html__('Video', 'rype-add-ons'),
            'slug' => 'video',
            'active' => 'true',
            'sidebar' => 'false',
        ),
        3 => array(
            'name' => esc_html__('Job Listings', 'rype-add-ons'),
            'label' => 'Job Listings',
            'slug' => 'job_listings',
            'active' => 'true',
            'sidebar' => 'false',
        ),
    );

    return $company_detail_items_default;
}

/*-----------------------------------------------------------------------------------*/
/*  Add Job Board Theme Option Fields 
/*-----------------------------------------------------------------------------------*/
function rao_add_job_board_theme_options_content() { ?>
    <div id="jobs" class="tab-content">
        <h2><?php echo esc_html_e('Jobs', 'rype-add-ons'); ?></h2>
        
        <div class="accordion rc-accordion">
            <h3 class="accordion-tab"><i class="fa fa-chevron-right icon"></i> <?php echo esc_html_e('Job Listing Options', 'rype-add-ons'); ?></h3>
            <div>

                <div class="admin-module">   
                    <label><?php echo esc_html_e('Default Job Listing Layout', 'rype-add-ons'); ?></label><br/>
                    <select name="rypecore_job_listing_default_layout">
                        <option value="list" <?php if(esc_attr(get_option('rypecore_job_listing_default_layout', 'list')) == 'list') { echo 'selected'; } ?>><?php echo esc_html_e('List', 'rype-add-ons'); ?></option>
                        <option value="grid" <?php if(esc_attr(get_option('rypecore_job_listing_default_layout', 'list')) == 'grid') { echo 'selected'; } ?>><?php echo esc_html_e('Grid', 'rype-add-ons'); ?></option>
                    </select>
                </div>
                
            </div>
        </div>

        <div class="accordion rc-accordion">
            <h3 class="accordion-tab"><i class="fa fa-chevron-right icon"></i> <?php echo esc_html_e('Job Detail Options', 'rype-add-ons'); ?></h3>
            <div>

                <div class="admin-module">
                    <label><strong><?php echo esc_html_e('Select the default page layout for job detail pages', 'rype-add-ons'); ?></strong></label>
                    <?php $job_detail_default_layout = get_option('rypecore_job_detail_default_layout', 'right sidebar'); ?>
                    <table class="left right-bump">
                    <tr>
                    <td><input type="radio" name="rypecore_job_detail_default_layout" id="page_layout_full" value="full" <?php if($job_detail_default_layout == 'full') { echo 'checked="checked"'; } ?> /></td>
                    <td><img class="sidebar-icon" src="<?php echo esc_url( get_template_directory_uri() ); ?>/admin/images/full-width-icon.png" alt="" /></td>
                    </tr><br/>
                    <tr>
                    <td></td>
                    <td><?php echo esc_html_e('Full Width', 'rype-add-ons'); ?></td>
                    </tr>
                    </table>

                    <table class="left">
                    <tr>
                    <td><input type="radio" name="rypecore_job_detail_default_layout" id="page_layout_right_sidebar" value="right sidebar" <?php if($job_detail_default_layout == 'right sidebar') { echo 'checked="checked"'; } ?> /></td>
                    <td><img class="sidebar-icon" src="<?php echo esc_url( get_template_directory_uri() ); ?>/admin/images/right-sidebar-icon.png" alt="" /></td>
                    </tr>
                    <tr>
                    <td></td>
                    <td><?php echo esc_html_e('Right Sidebar', 'rype-add-ons'); ?></td>
                    </tr>
                    </table>

                    <table class="left">
                    <tr>
                    <td><input type="radio" name="rypecore_job_detail_default_layout" id="page_layout_left_sidebar" value="left sidebar" <?php if($job_detail_default_layout == 'left sidebar') { echo 'checked="checked"'; } ?> /></td>
                    <td><img class="sidebar-icon" src="<?php echo esc_url( get_template_directory_uri() ); ?>/admin/images/left-sidebar-icon.png" alt="" /></td>
                    </tr>
                    <tr>
                    <td></td>
                    <td><?php echo esc_html_e('Left Sidebar', 'rype-add-ons'); ?></td>
                    </tr>
                    </table>
                    <div class="clear"></div>
                </div>

                <div class="admin-module">
                    <label><b><?php echo esc_html_e('Job Detail Sections', 'rype-add-ons'); ?></b> <i><?php echo esc_html_e('(Drag & drop to rearrange order)', 'rype-add-ons'); ?></i></label><br/>
                    <ul class="sortable-list job-detail-items-list">
                        <?php
                        $job_detail_items_default = rao_load_default_job_detail_items();
                        $job_detail_items = get_option('rypecore_job_detail_items', $job_detail_items_default);
                        $count = 0;

                        foreach($job_detail_items as $value) { ?>
                            <?php
                                if(isset($value['name'])) { $name = $value['name']; }
                                if(isset($value['label'])) { $label = $value['label']; }
                                if(isset($value['slug'])) { $slug = $value['slug']; }
                                if(isset($value['active']) && $value['active'] == 'true') { $active = 'true'; } else { $active = 'false'; }
                                if(isset($value['sidebar']) && $value['sidebar'] == 'true') { $sidebar = 'true'; } else { $sidebar = 'false'; }
                            ?>
                            <li class="sortable-item">
                                <div class="sort-arrows"><i class="fa fa-arrows-v"></i></div>
                                <div class="toggle-switch" title="<?php if($active == 'true') { esc_html_e('Active', 'rype-add-ons'); } else { esc_html_e('Disabled', 'rype-add-ons'); } ?>">
                                    <input type="checkbox" name="rypecore_job_detail_items[<?php echo $count; ?>][active]" value="true" class="toggle-switch-checkbox" id="job_detail_item_<?php echo esc_attr($slug); ?>" <?php checked('true', $active, true) ?>>
                                    <label class="toggle-switch-label" for="job_detail_item_<?php echo esc_attr($slug); ?>"></label>
                                </div>
                                <span><?php echo esc_attr($name); ?></span><div class="clear"></div>
                                <input type="hidden" name="rypecore_job_detail_items[<?php echo $count; ?>][name]" value="<?php echo $name; ?>" />
                                <input type="hidden" name="rypecore_job_detail_items[<?php echo $count; ?>][slug]" value="<?php echo $slug; ?>" />
                                <?php esc_html_e('Label:', 'rype-add-ons'); ?> <input type="text" name="rypecore_job_detail_items[<?php echo $count; ?>][label]" value="<?php echo $label; ?>" />
                                <input type="checkbox" name="rypecore_job_detail_items[<?php echo $count; ?>][sidebar]" value="true" <?php checked('true', $sidebar, true) ?> /> <?php esc_html_e('Display in Sidebar', 'rype-add-ons'); ?>
                            </li>
                            <?php $count++; ?>
                        <?php } ?>
                    </ul>
                </div>
                
            </div>
        </div>

    </div>

    <div id="companies" class="tab-content">
        <h2><?php echo esc_html_e('Companies', 'rype-add-ons'); ?></h2>

        <div class="accordion rc-accordion">
            <h3 class="accordion-tab"><i class="fa fa-chevron-right icon"></i> <?php echo esc_html_e('Company Listing Options', 'rype-add-ons'); ?></h3>
            <div>
                
            </div>
        </div>

        <div class="accordion rc-accordion">
            <h3 class="accordion-tab"><i class="fa fa-chevron-right icon"></i> <?php echo esc_html_e('Company Detail Options', 'rype-add-ons'); ?></h3>
            <div>

                <div class="admin-module">
                    <label><b><?php echo esc_html_e('Company Detail Sections', 'rype-add-ons'); ?></b> <i><?php echo esc_html_e('(Drag & drop to rearrange order)', 'rype-add-ons'); ?></i></label><br/>
                    <ul class="sortable-list job-detail-items-list">
                        <?php
                        $company_detail_items_default = rao_load_default_company_detail_items();
                        $company_detail_items = get_option('rypecore_company_detail_items', $company_detail_items_default);
                        $count = 0;

                        foreach($company_detail_items as $value) { ?>
                            <?php
                                if(isset($value['name'])) { $name = $value['name']; }
                                if(isset($value['label'])) { $label = $value['label']; }
                                if(isset($value['slug'])) { $slug = $value['slug']; }
                                if(isset($value['active']) && $value['active'] == 'true') { $active = 'true'; } else { $active = 'false'; }
                                if(isset($value['sidebar']) && $value['sidebar'] == 'true') { $sidebar = 'true'; } else { $sidebar = 'false'; }
                            ?>
                            <li class="sortable-item">
                                <div class="sort-arrows"><i class="fa fa-arrows-v"></i></div>
                                <div class="toggle-switch" title="<?php if($active == 'true') { esc_html_e('Active', 'rype-add-ons'); } else { esc_html_e('Disabled', 'rype-add-ons'); } ?>">
                                    <input type="checkbox" name="rypecore_company_detail_items[<?php echo $count; ?>][active]" value="true" class="toggle-switch-checkbox" id="company_detail_item_<?php echo esc_attr($slug); ?>" <?php checked('true', $active, true) ?>>
                                    <label class="toggle-switch-label" for="company_detail_item_<?php echo esc_attr($slug); ?>"></label>
                                </div>
                                <span><?php echo esc_attr($name); ?></span><div class="clear"></div>
                                <input type="hidden" name="rypecore_company_detail_items[<?php echo $count; ?>][name]" value="<?php echo $name; ?>" />
                                <input type="hidden" name="rypecore_company_detail_items[<?php echo $count; ?>][slug]" value="<?php echo $slug; ?>" />
                                <?php esc_html_e('Label:', 'rype-add-ons'); ?> <input type="text" name="rypecore_company_detail_items[<?php echo $count; ?>][label]" value="<?php echo $label; ?>" />
                                <input type="checkbox" name="rypecore_company_detail_items[<?php echo $count; ?>][sidebar]" value="true" <?php checked('true', $sidebar, true) ?> /> <?php esc_html_e('Display in Sidebar', 'rype-add-ons'); ?>
                            </li>
                            <?php $count++; ?>
                        <?php } ?>
                    </ul>
                </div>

            </div>
        </div>

    </div>

<?php }
add_action( 'rao_after_theme_option_content', 'rao_add_job_board_theme_options_content' );


/*-----------------------------------------------------------------------------------*/
/*  Add Job Board Page Options
/*-----------------------------------------------------------------------------------*/
function rao_add_job_board_banner_options($values) { 
    
    $banner_job_search_display = isset( $values['rypecore_banner_job_search_display'] ) ? esc_attr( $values['rypecore_banner_job_search_display'][0] ) : 'false';
    $banner_job_search_keywords_placeholder = isset( $values['rypecore_banner_job_search_keywords_placeholder'] ) ? esc_attr( $values['rypecore_banner_job_search_keywords_placeholder'][0] ) : esc_html__('Job title or keywords', 'rype-add-ons');
    $banner_job_search_location_placeholder = isset( $values['rypecore_banner_job_search_location_placeholder'] ) ? esc_attr( $values['rypecore_banner_job_search_location_placeholder'][0] ) : esc_html__('Any Location', 'rype-add-ons');
    $banner_job_search_submit_text = isset( $values['rypecore_banner_job_search_submit_text'] ) ? esc_attr( $values['rypecore_banner_job_search_submit_text'][0] ) : esc_html__('Find Jobs', 'rype-add-ons');
    ?>

    <h4><?php echo esc_html_e('Job Filter Settings', 'rype-add-ons'); ?></h4>
    <div class="admin-module">
        <input id="banner_job_search_display" type="checkbox" name="rypecore_banner_job_search_display" value="true" <?php if($banner_job_search_display == 'true') { echo 'checked'; } ?> />
        <label for="banner_job_search_display"><?php echo esc_html_e('Display Job Search Filter', 'rype-add-ons'); ?></label>
    </div>

    <div class="admin-module">   
        <label><?php echo esc_html_e('Keywords Placeholder', 'rype-add-ons'); ?></label><br/>
        <input type="text" name="rypecore_banner_job_search_keywords_placeholder" value="<?php echo $banner_job_search_keywords_placeholder; ?>" />
    </div>

    <div class="admin-module">   
        <label><?php echo esc_html_e('Location Placeholder', 'rype-add-ons'); ?></label><br/>
        <input type="text" name="rypecore_banner_job_search_location_placeholder" value="<?php echo $banner_job_search_location_placeholder; ?>" />
    </div>

    <div class="admin-module">   
        <label><?php echo esc_html_e('Submit Button Text', 'rype-add-ons'); ?></label><br/>
        <input type="text" name="rypecore_banner_job_search_submit_text" value="<?php echo $banner_job_search_submit_text; ?>" />
    </div>

<?php }
add_action( 'rao_after_page_banner_options', 'rao_add_job_board_banner_options' );

function rao_add_job_board_map_options($values) { 
    $banner_source = isset( $values['rypecore_banner_source'] ) ? esc_attr( $values['rypecore_banner_source'][0] ) : 'image_banner';
    ?> 
    <label class="selectable-item <?php if($banner_source == 'jobs_map') { echo 'active'; } ?>" for="banner_source_jobs_map">
        <img src="<?php echo plugins_url('/rype-add-ons/images/google-maps-icon.png'); ?>" alt="" /><br/>
        <input type="radio" id="banner_source_jobs_map" name="rypecore_banner_source" value="jobs_map" <?php checked('jobs_map', $banner_source, true) ?> /> <?php esc_html_e('Jobs Map', 'rype-add-ons'); ?><br/>
    </label>
<?php }
add_action( 'rao_before_page_banner_options', 'rao_add_job_board_map_options' );

function rao_save_job_board_page_options($post_id) { 
    $allowed = array();

    if( isset( $_POST['rypecore_banner_job_search_display'] ) ) {
        update_post_meta( $post_id, 'rypecore_banner_job_search_display', wp_kses( $_POST['rypecore_banner_job_search_display'], $allowed ) );
    } else {
        update_post_meta( $post_id, 'rypecore_banner_job_search_display', wp_kses( '', $allowed ) );
    }

    if( isset( $_POST['rypecore_banner_job_search_keywords_placeholder'] ) )
        update_post_meta( $post_id, 'rypecore_banner_job_search_keywords_placeholder', wp_kses( $_POST['rypecore_banner_job_search_keywords_placeholder'], $allowed ) );

    if( isset( $_POST['rypecore_banner_job_search_location_placeholder'] ) )
        update_post_meta( $post_id, 'rypecore_banner_job_search_location_placeholder', wp_kses( $_POST['rypecore_banner_job_search_location_placeholder'], $allowed ) );

    if( isset( $_POST['rypecore_banner_job_search_submit_text'] ) )
        update_post_meta( $post_id, 'rypecore_banner_job_search_submit_text', wp_kses( $_POST['rypecore_banner_job_search_submit_text'], $allowed ) );
}
add_action( 'rao_after_page_settings_save', 'rao_save_job_board_page_options' );