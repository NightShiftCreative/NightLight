<?php
/************************************************************/
/* RYPE ADD-ONS */
/* JOB BOARD - WP JOB MANAGER - JOB RELATED CUSTOMIZATIONS  */
/************************************************************/

/*-----------------------------------------------------------------------------------*/
/*  Get Jobs
/*-----------------------------------------------------------------------------------*/
function rao_get_jobs($custom_args, $no_post_message = null) { 
    $job_listing_query = new WP_Query($custom_args);

    if ( $job_listing_query->have_posts() ) : 
        get_job_manager_template_part('job-listings-start'); 
            while ( $job_listing_query->have_posts() ) : $job_listing_query->the_post(); 
                get_job_manager_template_part( 'content', 'job_listing' );
            endwhile; 
            wp_reset_postdata(); 
        get_job_manager_template_part('job-listings-end'); 
    else: 
        if($no_post_message == null) { $no_post_message = __('Sorry, no jobs were found.', 'rypecore' ); }
        echo '<p>'.$no_post_message.'</p>';
    endif;
}

/*-----------------------------------------------------------------------------------*/
/*  Get Job Page Url
/*-----------------------------------------------------------------------------------*/
function rao_get_job_page() {
    $job_page = get_permalink(esc_attr(get_option( 'job_manager_jobs_page_id', false )));
    if (!empty($job_page)) {
        return $job_page;
    } else {
        return get_post_type_archive_link( 'job_listing' );
    }
}

/*-----------------------------------------------------------------------------------*/
/*  Get Job Details
/*-----------------------------------------------------------------------------------*/
/* get job salary and format */
function rao_get_job_salary($post_id, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $salary = '';
    $salary_min = get_post_meta( $post_id, '_job_salary_min', true );
    $salary_max = get_post_meta( $post_id, '_job_salary_max', true );
    $salary_term = get_post_meta( $post_id, '_job_salary_term', true );

    if($salary_min || $salary_max) {
        if($icon == true) { $salary .= rypecore_get_icon($icon_set, 'money', 'cash-dollar', 'wallet'); }
        if($label != null) { $salary .= '<div class="job-detail-label">'.$label.'</div>'; }
        if($salary_min) { $salary .= rypecore_format_price(esc_html($salary_min)); }
        if($salary_min && $salary_max) { $salary .=  ' - '; } 
        if($salary_max) { $salary .= rypecore_format_price(esc_html($salary_max)); }
        if($salary_term) { $salary .= ' <span class="salary-term">'.$salary_term.'</span>'; }
    }
    return $salary;
}

/* get job region */
function rao_get_job_region($post_id, $parent = null, $children = null, $address = null, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $job_region_output = '';
    $job_region_terms = get_the_terms( $post_id, 'job_listing_region' );
    
    if ( $job_region_terms && ! is_wp_error( $job_region_terms) ) {
        $job_region_links = array();
        $job_region_child_links = array();
        foreach ( $job_region_terms as $job_region_term ) {
            if($job_region_term->parent != 0) {
                $job_region_child_links[] = '<a href="'.esc_attr(get_term_link($job_region_term->slug, 'job_listing_region')).'">'.$job_region_term->name.'</a>';
            } else {
                $job_region_links[] = '<a href="'.esc_attr(get_term_link($job_region_term->slug, 'job_listing_region')).'">'.$job_region_term->name.'</a>';
            }
        }  
        $job_region = join( "<span>, </span>", $job_region_links ); 
        $job_region_children = join( "<span>, </span>", $job_region_child_links );                
    }

    if($parent == true && $children == true) {
        if(!empty($job_region_children)) { $job_region_output .= wp_kses_post($job_region_children); } 
        if(!empty($job_region) && !empty($job_region_children)) { $job_region_output .= ', '; }
        if(!empty($job_region)) { $job_region_output .= wp_kses_post($job_region); } 
    } else if($parent == true) {
        if(!empty($job_region)) { $job_region_output .= wp_kses_post($job_region); }
    } else if($children == true) {
        if(!empty($job_region_children)) { $job_region_output .= wp_kses_post($job_region_children); }
    } else {
        if(!empty($job_region) || !empty($job_region_children) || !empty(get_the_job_location())) { 
            if($icon == true) { $job_region_output .= rypecore_get_icon($icon_set, 'map-marker', '', 'location'); }
            if($label != null) { $job_region_output .= '<div class="job-detail-label">'.$label.'</div>'; }
            if($address != null && !empty(get_the_job_location())) { 
                $job_region_output .= get_the_job_location(); 
                if(!empty($job_region) || !empty($job_region_children)) { $job_region_output .= ', '; }
            } 
            if(!empty($job_region_children)) { $job_region_output .= wp_kses_post($job_region_children); } 
            if(!empty($job_region) && !empty($job_region_children)) { $job_region_output .= ', '; }
            if(!empty($job_region)) { $job_region_output .= wp_kses_post($job_region); } 
        }
    }

    return $job_region_output;
}

/* get job categories */
function rao_get_job_category($post_id, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $job_cat_terms = get_the_terms( $post_id, 'job_listing_category' );
    $job_cat_output = '';

    if ( $job_cat_terms && ! is_wp_error( $job_cat_terms) ) {
        $job_cat_links = array();
        foreach ( $job_cat_terms as $job_cat_term ) {
            $job_cat_links[] = '<a href="'.esc_attr(get_term_link($job_cat_term->slug, 'job_listing_category')).'">'.$job_cat_term ->name.'</a>';
        }  
        $job_cat = join( "<span>, </span>", $job_cat_links );               
    }

    if(isset($job_cat) && !empty($job_cat)) {
        if($icon == true) { $job_cat_output .= rypecore_get_icon($icon_set, 'folder'); }
        if($label != null) { $job_cat_output .= '<div class="job-detail-label">'.$label.'</div>'; }
        $job_cat_output .= wp_kses_post($job_cat);  
    }
    return $job_cat_output;
}

/* get job types */
function rao_get_job_type($post_id, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $job_type_terms = wpjm_get_the_job_types($post_id);
    $job_type_output = '';

    if ( $job_type_terms && ! is_wp_error( $job_type_terms) ) {
        $job_type_links = array();
        foreach ( $job_type_terms as $job_type_term ) {
            $job_type_links[] = '<a href="'.esc_attr(get_term_link($job_type_term->slug, 'job_listing_type')).'">'.$job_type_term ->name.'</a>';
        }  
        $job_type = join( "<span>, </span>", $job_type_links );               
    }

    if(isset($job_type) && !empty($job_type)) {
        if($icon == true) { $job_type_output .= rypecore_get_icon($icon_set, 'briefcase'); }
        if($label != null) { $job_type_output .= '<div class="job-detail-label">'.$label.'</div>'; }
        $job_type_output .= wp_kses_post($job_type);  
    }
    return $job_type_output;
}

/* get job skills */
function rao_get_job_skills($post_id, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $job_skills = array();
    $job_skill_terms = get_the_terms($post_id, 'job_listing_skills');

    if ($job_skill_terms && !is_wp_error($job_skill_terms) ) {
        foreach ( $job_skill_terms as $job_skill_term ) {
            $job_skills[] = '<a class="button small outline job-skill" href="'. esc_attr(get_term_link($job_skill_term->slug, 'job_listing_skills')).'">'.$job_skill_term ->name.'</a>' ;
        }                   
    }
    return $job_skills;
}

/* get job publish date */
function rao_get_job_publish_date($post_id, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $job_publish_date = '';

    if(get_the_job_publish_date()) {
        if($icon == true) { $job_publish_date .= rypecore_get_icon($icon_set, 'calendar', 'calendar-full'); }
        if($label != null) { $job_publish_date .= '<div class="job-detail-label">'.$label.'</div>'; }
        $job_publish_date .= get_the_job_publish_date(); 
    }

    return $job_publish_date;
}

/* get job expiration date */
function rao_get_job_expiration_date($post_id, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $job_expiration_date_output = '';
    $job_expiration_date = get_post_meta($post_id, '_job_expires', true);

    if(!empty($job_expiration_date)) {
        if($icon == true) { $job_expiration_date_output .= rypecore_get_icon($icon_set, 'clock-o', 'clock', 'clock'); }
        if($label != null) { $job_expiration_date_output .= '<div class="job-detail-label">'.$label.'</div>'; }
        $job_expiration_date_output .= $job_expiration_date;
    }

    return $job_expiration_date_output;
}

/* get job required experience */
function rao_get_job_required_experience($post_id, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $job_required_experience_output = '';
    $job_required_experience = get_post_meta($post_id, '_job_experience', true);

    if(!empty($job_required_experience)) {
        if($icon == true) { $job_required_experience_output .= rypecore_get_icon($icon_set, 'user'); }
        if($label != null) { $job_required_experience_output .= '<div class="job-detail-label">'.$label.'</div>'; }
        $job_required_experience_output.= $job_required_experience ;
    }
    return $job_required_experience_output;
}

/*-----------------------------------------------------------------------------------*/
/*  Add Additional Job Fields
/*-----------------------------------------------------------------------------------*/
/* add fields to front-end form */
add_filter( 'submit_job_form_fields', 'rao_frontend_add_jobs_fields' );
function rao_frontend_add_jobs_fields( $fields ) {
    $currency_symbol = get_option('rypecore_currency_symbol', '$');
    $salary_min_label = __( 'Salary Minimum', 'rype-add-ons' ).' ('.$currency_symbol.')';
    $fields['job']['job_salary_min'] = array(
        'label'       => $salary_min_label,
        'type'        => 'text',
        'required'    => true,
        'placeholder' => 'e.g. 20000',
        'priority'    => 7
    );
    return $fields;
}

/* add fields to admin metabox */
add_filter( 'job_manager_job_listing_data_fields', 'rao_admin_add_jobs_fields' );
function rao_admin_add_jobs_fields( $fields ) {

    $currency_symbol = get_option('rypecore_currency_symbol', '$');

    /* change label for location field */
     $fields['_job_location']['label'] = __( 'Location (Address)', 'rype-add-ons' );
     $fields['_job_location']['placeholder'] = __( 'e.g. 123 Smith Drive', 'rype-add-ons' );

    //add salary max field
    $salary_max_label = __( 'Salary Maximum', 'rype-add-ons' ).' ('.$currency_symbol.')';
    $fields['_job_salary_max'] = array(
        'label'       => $salary_max_label,
        'type'        => 'text',
        'placeholder' => 'e.g. 30000',
        'description' => '',
        'priority'    => 2
    );

    //add salary min field
    $salary_min_label = __( 'Salary Minimum', 'rype-add-ons' ).' ('.$currency_symbol.')';
    $fields['_job_salary_min'] = array(
        'label'       => $salary_min_label,
        'type'        => 'text',
        'placeholder' => 'e.g. 20000',
        'description' => '',
        'priority'    => 2,
    );

    //add salary term field
    $fields['_job_salary_term'] = array(
        'label'       => __( 'Salary Term', 'rype-add-ons' ),
        'type'        => 'text',
        'placeholder' => 'Yearly',
        'description' => '',
        'priority'    => 3
    );

    //add required experience
    $fields['_job_experience'] = array(
        'label'       => __( 'Required Experience', 'rype-add-ons' ),
        'type'        => 'text',
        'placeholder' => 'e.g. 2+ Years',
        'description' => '',
        'priority'    => 4
    );

    //add company facebook
    $fields['_company_description'] = array(
        'label'       => __( 'Company Description', 'rype-add-ons' ),
        'type'        => 'textarea',
        'placeholder' => 'Add some details about the company',
        'description' => '',
        'priority'    => 4
    );

    //add company facebook
    $fields['_company_facebook'] = array(
        'label'       => __( 'Company Facebook', 'rype-add-ons' ),
        'type'        => 'text',
        'placeholder' => '',
        'description' => '',
        'priority'    => 5
    );

    //add company linkedin
    $fields['_company_linkedin'] = array(
        'label'       => __( 'Company Linkedin', 'rype-add-ons' ),
        'type'        => 'text',
        'placeholder' => '',
        'description' => '',
        'priority'    => 6
    );

    //add company google plus
    $fields['_company_google_plus'] = array(
        'label'       => __( 'Company Google Plus', 'rype-add-ons' ),
        'type'        => 'text',
        'placeholder' => '',
        'description' => '',
        'priority'    => 7
    );

    //add company youtube
    $fields['_company_youtube'] = array(
        'label'       => __( 'Company Youtube', 'rype-add-ons' ),
        'type'        => 'text',
        'placeholder' => '',
        'description' => '',
        'priority'    => 8
    );

    return $fields;
}

/*-----------------------------------------------------------------------------------*/
/*  Add Job Gallery Metabox
/*-----------------------------------------------------------------------------------*/
/* generate admin gallery upload */
function rao_generate_gallery($additional_images) { ?>
    <div class="admin-module admin-module-bg gallery-container">
        <?php
        if(!empty($additional_images)) { ?>

            <?php
            $additional_images = explode(",", $additional_images[0]);
            $additional_images = array_filter($additional_images);

            function rypecore_get_image_id($image_url) {
                global $wpdb;
                $attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url )); 
                return $attachment[0]; 
            }

            foreach ($additional_images as $additional_image) {
                if(!empty($additional_image)) {
                    $image_id = rypecore_get_image_id($additional_image);

                    if(!empty($image_id)) {
                        $image_thumb = wp_get_attachment_image_src($image_id, 'thumbnail');
                        $image_thumb_html = '<img src="'. $image_thumb[0] .'" alt="" />'; 
                    } else {
                        $image_thumb_html = '<img width="150" src="'.$additional_image.'" alt="" />';
                    }

                    echo '
                        <div class="gallery-img-preview">
                            '.$image_thumb_html.'
                            <input type="hidden" name="rypecore_additional_img[]" value="'. $additional_image .'" />
                            <span class="action delete-additional-img" title="'. esc_html__('Delete', 'rype-add-ons'). '"><i class="fa fa-trash"></i></span>
                            <a href="'.get_admin_url().'upload.php?item='.$image_id.'" class="action edit-additional-img" target="_blank" title="'.esc_html__('Edit', 'rype-add-ons').'"><i class="fa fa-pencil"></i></a>
                        </div>
                    ';
                }
            }
        } ?>

        <div class="clear"></div>
        <span class="admin-button add-gallery-media"><?php echo esc_html_e('Add Images', 'rype-add-ons'); ?></span>
    </div>
<?php }

function rao_add_job_gallery_meta_box() {
    $post_types = array('job_listing');
    add_meta_box( 'job-gallery-meta-box', 'Job Gallery', 'rao_job_gallery_meta_box', $post_types, 'side', 'low' );
}
add_action( 'add_meta_boxes', 'rao_add_job_gallery_meta_box' );

function rao_job_gallery_meta_box($post) {
    $values = get_post_custom( $post->ID );
    $additional_images = isset($values['rypecore_additional_img']) ? $values['rypecore_additional_img'] : '';
    wp_nonce_field( 'rao_job_gallery_meta_box_nonce', 'rao_job_gallery_meta_box_nonce' );
    ?>

    <?php echo rao_generate_gallery($additional_images); ?>
<?php }

/* Save job gallery form */
add_action( 'save_post', 'rao_save_job_gallery_meta_box' );
function rao_save_job_gallery_meta_box( $post_id ) {

    // Bail if we're doing an auto save
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

    // if our nonce isn't there, or we can't verify it, bail
    if( !isset( $_POST['rao_job_gallery_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['rao_job_gallery_meta_box_nonce'], 'rao_job_gallery_meta_box_nonce' ) ) return;

    // if our current user can't edit this post, bail
    if( !current_user_can( 'edit_post', $post_id ) ) return;

    // save the data
    $allowed = array(
        'a' => array( // on allow a tags
            'href' => array() // and those anchors can only have href attribute
        ),
        'b' => array(),
        'strong' => array(),
        'i' => array()
    );
         
    // make sure data is set before saving
    if (isset( $_POST['rypecore_additional_img'] )) {
        $strAdditionalImgs = implode(",", $_POST['rypecore_additional_img']);
        update_post_meta( $post_id, 'rypecore_additional_img', $strAdditionalImgs );
    } else {
        $strAdditionalImgs = '';
        update_post_meta( $post_id, 'rypecore_additional_img', $strAdditionalImgs );
    }
}

/*-----------------------------------------------------------------------------------*/
/*  Add Job Map Metabox
/*-----------------------------------------------------------------------------------*/
function rao_add_job_map_meta_box() {
    $post_types = array('job_listing');
    add_meta_box( 'job-map-meta-box', 'Job Map', 'rao_job_map_meta_box', $post_types, 'side', 'default' );
}
add_action( 'add_meta_boxes', 'rao_add_job_map_meta_box' );

function rao_job_map_meta_box($post) {
    $latitude = get_post_meta($post->ID, 'geolocation_lat', true); 
    $longitude = get_post_meta($post->ID, 'geolocation_long', true); 
    wp_nonce_field( 'rao_job_map_meta_box_nonce', 'rao_job_map_meta_box_nonce' ); ?>

    <div class="admin-module admin-module-map">

        <div class="admin-module admin-module-coordinates">
            <div class="admin-module ">   
                <label for="latitude-input"><?php echo esc_html_e('Latitude', 'rype-add-ons'); ?></label><br/>
                <input type="text" id="latitude-input" name="geolocation_lat" value="<?php echo $latitude; ?>" />
            </div>

            <div class="admin-module">   
                <label for="longitude-input"><?php echo esc_html_e('Longitude', 'rype-add-ons'); ?></label><br/>
                <input type="text" id="longitude-input" name="geolocation_long" value="<?php echo $longitude; ?>" />
            </div>
            <div class="clear"></div>
        </div>

        <?php include(plugin_dir_path( __FILE__ ) . 'admin_map.php'); ?>
    </div>
<?php }

/* Save job map form */
add_action( 'save_post', 'rao_save_job_map_meta_box' );
function rao_save_job_map_meta_box( $post_id ) {

    // Bail if we're doing an auto save
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

    // if our nonce isn't there, or we can't verify it, bail
    if( !isset( $_POST['rao_job_map_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['rao_job_map_meta_box_nonce'], 'rao_job_map_meta_box_nonce' ) ) return;

    // if our current user can't edit this post, bail
    if( !current_user_can( 'edit_post', $post_id ) ) return;

    // save the data
    $allowed = array();
         
    // make sure data is set before saving
    if( isset( $_POST['geolocation_lat'] ) )
        update_post_meta( $post_id, 'geolocation_lat', wp_kses( $_POST['geolocation_lat'], $allowed ) );

    if( isset( $_POST['geolocation_long'] ) )
        update_post_meta( $post_id, 'geolocation_long', wp_kses( $_POST['geolocation_long'], $allowed ) );
}

/*-----------------------------------------------------------------------------------*/
/*  Add Job Regions Taxonomy
/*-----------------------------------------------------------------------------------*/
function rao_job_region_init() {
    $labels = array(
    'name'                          => __( 'Job Regions', 'rype-add-ons' ),
    'singular_name'                 => __( 'Job Region', 'rype-add-ons' ),
    'search_items'                  => __( 'Search Job Regions', 'rype-add-ons' ),
    'popular_items'                 => __( 'Popular Job Regions', 'rype-add-ons' ),
    'all_items'                     => __( 'All Job Regions', 'rype-add-ons' ),
    'parent_item'                   => __( 'Parent Job Region', 'rype-add-ons' ),
    'edit_item'                     => __( 'Edit Job Region', 'rype-add-ons' ),
    'update_item'                   => __( 'Update Job Region', 'rype-add-ons' ),
    'add_new_item'                  => __( 'Add New Job Region', 'rype-add-ons' ),
    'new_item_name'                 => __( 'New Job Region', 'rype-add-ons' ),
    'separate_items_with_commas'    => __( 'Separate job regions with commas', 'rype-add-ons' ),
    'add_or_remove_items'           => __( 'Add or remove job regions', 'rype-add-ons' ),
    'choose_from_most_used'         => __( 'Choose from most used job regions', 'rype-add-ons' )
    );
    
    register_taxonomy(
        'job_listing_region',
        'job_listing',
        array(
            'label'         => __( 'Job Regions', 'rype-add-ons' ),
            'labels'        => $labels,
            'hierarchical'  => true,
            'rewrite' => array( 'slug' => 'job-region' )
        )
    );
}
add_action( 'init', 'rao_job_region_init' );

/*-----------------------------------------------------------------------------------*/
/*  Add Job Skills Taxonomy
/*-----------------------------------------------------------------------------------*/
function rao_job_skills_init() {

    $labels = array(
    'name'                          => __( 'Job Skills', 'rype-add-ons' ),
    'singular_name'                 => __( 'Job Skill', 'rype-add-ons' ),
    'search_items'                  => __( 'Search Job Skills', 'rype-add-ons' ),
    'popular_items'                 => __( 'Popular Job Skills', 'rype-add-ons' ),
    'all_items'                     => __( 'All Job Skills', 'rype-add-ons' ),
    'parent_item'                   => __( 'Parent Job Skill', 'rype-add-ons' ),
    'edit_item'                     => __( 'Edit Job Skill', 'rype-add-ons' ),
    'update_item'                   => __( 'Update Job Skill', 'rype-add-ons' ),
    'add_new_item'                  => __( 'Add New Job Skill', 'rype-add-ons' ),
    'new_item_name'                 => __( 'New Job Skill', 'rype-add-ons' ),
    'separate_items_with_commas'    => __( 'Separate job skills with commas', 'rype-add-ons' ),
    'add_or_remove_items'           => __( 'Add or remove job skills', 'rype-add-ons' ),
    'choose_from_most_used'         => __( 'Choose from most used job skills', 'rype-add-ons' )
    );
    
    register_taxonomy(
        'job_listing_skills',
        'job_listing',
        array(
            'label'         => __( 'Job Skills', 'rype-add-ons' ),
            'labels'        => $labels,
            'hierarchical'  => false,
            'rewrite' => array( 'slug' => 'job-skills' )
        )
    );
}
add_action( 'init', 'rao_job_skills_init' );

/*-----------------------------------------------------------------------------------*/
/*  Customize Job Taxonomies Admin Page
/*-----------------------------------------------------------------------------------*/
add_action( 'job_listing_category_edit_form_fields', 'rao_extra_tax_fields', 10, 2);
add_action( 'edited_job_listing_category', 'rao_save_extra_taxonomy_fields', 10, 2);
add_action('job_listing_category_add_form_fields','rao_extra_tax_fields', 10, 2 );  
add_action('created_job_listing_category','rao_save_extra_taxonomy_fields', 10, 2);

add_action( 'job_listing_type_edit_form_fields', 'rao_extra_tax_fields', 10, 2);
add_action( 'edited_job_listing_type', 'rao_save_extra_taxonomy_fields', 10, 2);
add_action('job_listing_type_add_form_fields','rao_extra_tax_fields', 10, 2 );  
add_action('created_job_listing_type','rao_save_extra_taxonomy_fields', 10, 2);

add_action( 'job_listing_region_edit_form_fields', 'rao_extra_tax_fields', 10, 2);
add_action( 'edited_job_listing_region', 'rao_save_extra_taxonomy_fields', 10, 2);
add_action('job_listing_region_add_form_fields','rao_extra_tax_fields', 10, 2 );  
add_action('created_job_listing_region','rao_save_extra_taxonomy_fields', 10, 2);

function rao_extra_tax_fields($tag) {
   //check for existing taxonomy meta for term ID
    if(is_object($tag)) { $t_id = $tag->term_id; } else { $t_id = ''; }
    $term_meta = get_option( "taxonomy_$t_id");
    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="job-cat-color"><?php esc_html_e('Category Color', 'rype-add-ons'); ?></label></th>
        <td>
            <div class="admin-module">
                <input type="text" class="job-cat-color color-field" name="term_meta[color]" id="term_meta[color]" data-default-color="#323746" value="<?php echo $term_meta['color'] ? $term_meta['color'] : ''; ?>" />
                <p class="description"><?php esc_html_e('Choose a color for this category.', 'rype-add-ons'); ?></p>
            </div>
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="job-cat-icon"><?php esc_html_e('Category Icon', 'rype-add-ons'); ?></label></th>
        <td>
            <div class="admin-module">
                <input type="text" class="job-cat-icon" name="term_meta[icon]" id="term_meta[icon]" value="<?php echo $term_meta['icon'] ? $term_meta['icon'] : ''; ?>">
                <p class="description">
                    <?php esc_html_e('Enter the full icon class name. Example: fa-user', 'rype-add-ons'); ?><br/>
                    <a href="https://fontawesome.com/icons" target="_blank"><?php esc_html_e('View Font Awesome Icons', 'rype-add-ons'); ?></a> | 
                    <a href="<?php echo get_template_directory_uri(); ?>/assets/linear-icons/demo.html" target="_blank"><?php esc_html_e('View Line Icons', 'rype-add-ons'); ?></a> |
                    <a href="<?php echo get_template_directory_uri(); ?>/assets/dripicons/icons-reference.html" target="_blank"><?php esc_html_e('View Dripicons', 'rype-add-ons'); ?></a>
                </p>
            </div>
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="cat_Image_url"><?php esc_html_e('Category Image', 'rype-add-ons'); ?></label></th>
        <td>
            <div class="admin-module">
                <input type="text" class="job-cat-image" name="term_meta[img]" id="term_meta[img]" size="3" style="width:60%;" value="<?php echo $term_meta['img'] ? $term_meta['img'] : ''; ?>">
                <input id="_btn" class="button-secondary rao_upload_image_button" type="button" value="<?php esc_html_e('Upload Image', 'rype-add-ons'); ?>" />
                <span class="button-secondary remove"><?php esc_html_e('Remove', 'rype-add-ons'); ?></span><br/>
                <p class="description"><?php esc_html_e('Upload a custom image for this term.', 'rype-add-ons'); ?></p>
            </div>
        </td>
    </tr>
<?php
}

// save extra taxonomy fields callback function
function rao_save_extra_taxonomy_fields( $term_id ) {
    if ( isset( $_POST['term_meta'] ) ) {
        $t_id = $term_id;
        $term_meta = get_option( "taxonomy_$t_id");
        $cat_keys = array_keys($_POST['term_meta']);
            foreach ($cat_keys as $key){
            if (isset($_POST['term_meta'][$key])){
                $term_meta[$key] = $_POST['term_meta'][$key];
            }
        }
        //save the option array
        update_option( "taxonomy_$t_id", $term_meta );
    }
}

/*-----------------------------------------------------------------------------------*/
/*  Custom Job Filters
/*-----------------------------------------------------------------------------------*/

//add sort by and layout fieldsS
add_action( 'job_manager_job_filters_after', 'rao_job_sort_by' );
function rao_job_sort_by() { 
    global $wp; ?>

    <div class="job-listing-header">
        <div class="job-manager-filter job-sort left">
            <select name="sort_by">
                <option value="date_desc"><?php esc_html_e('New to Old', 'rype-add-ons'); ?></option>
                <option value="date_asc"><?php esc_html_e('Old to New', 'rype-add-ons'); ?></option>
                <option value="salary_asc"><?php esc_html_e('Salary (Low to High)', 'rype-add-ons'); ?></option>
                <option value="salary_desc"><?php esc_html_e('Salary (High to Low)', 'rype-add-ons'); ?></option>
            </select>
        </div>
        <div class="job-layout right">
            <?php
            $currentUrl = home_url( $wp->request );
            if(isset($_GET['job_layout']) && !empty($_GET['job_layout'])) { 
                $job_layout = $_GET['job_layout']; 
            } else { 
                $job_layout = esc_attr(get_option('rypecore_job_listing_default_layout', 'list'));
            }
            ?>
            <a href="<?php echo $currentUrl; ?>?job_layout=list" class="job-layout-toggle-item <?php if($job_layout == 'list') { echo 'active'; } ?>"><i class="fa fa-bars"></i></a>
            <a href="<?php echo $currentUrl; ?>?job_layout=grid" class="job-layout-toggle-item <?php if($job_layout == 'grid') { echo 'active'; } ?>"><i class="fa fa-th-large"></i></a>
        </div>
        <div class="clear"></div>
    </div>
<?php }

//add other custom filter fields
add_action( 'job_manager_job_filters_search_jobs_end', 'rao_custom_job_filters' );
function rao_custom_job_filters() {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    
    $search_regions = isset($_REQUEST['search_region']) ? $_REQUEST['search_region'] : '';
    $job_regions = get_terms('job_listing_region', array( 'hide_empty' => false, 'parent' => 0 )); 
    if (!empty( $job_regions ) && !is_wp_error($job_regions)) { 
    ?>
        <div class="form-block form-block-icon search_categories search_regions ">
            <label><?php _e( 'Search Regions', 'rype-add-ons' ); ?></label>
            <?php echo rypecore_get_icon($icon_set, 'map-marker', '', 'location'); ?>
            <select class="job-manager-filter" name="search_region">
                <option value=""><?php _e( 'Any Location', 'rype-add-ons' ); ?></option>
                <?php foreach($job_regions as $job_region) { ?>
                    <option value="<?php echo esc_attr($job_region->term_id); ?>" <?php if($job_region->term_id == $search_regions) { echo 'selected'; } ?>><?php echo esc_attr($job_region->name); ?></option>
                    <?php 
                    $term_children = get_term_children($job_region->term_id, 'job_listing_region'); 
                    if(!empty($term_children)) {
                        echo '<optgroup label="'.$job_region->name.'">';
                        foreach ( $term_children as $child ) {
                            $term = get_term_by( 'id', $child, 'job_listing_region' );
                            if($term->term_id == $search_regions) { $term_selected = 'selected'; } else { $term_selected = ''; }
                            echo '<option value="'.$term->term_id.'" '.$term_selected.'>'.$term->name.'</option>';
                        }
                        echo '</optgroup>';
                    } ?>
                <?php } ?>
            </select>
        </div>

        <!-- hidden fields -->
        <?php 
        $search_types = isset($_REQUEST['search_type']) ? $_REQUEST['search_type'] : ''; 
        $search_salary_min = isset($_REQUEST['search_salary_min']) ? $_REQUEST['search_salary_min'] : ''; 
        ?>
        <input type="hidden" name="search_type" value="<?php echo $search_types; ?>" />
        <input type="hidden" name="search_salary_min" value="<?php echo $search_salary_min; ?>" />
        <input type="hidden" name="action" value="job_map_filter">
    <?php } ?>

    <div class="form-block search_submit">
        <a href="#" class="button"><?php echo rypecore_get_icon($icon_set, 'search', 'magnifier'); ?></a>
    </div>

<?php }

//process above filter queries
add_filter( 'job_manager_get_listings', 'rao_custom_job_filters_query_args', 10, 2 );
function rao_custom_job_filters_query_args( $query_args, $args ) {

    if (isset($_POST['form_data'])) {
        parse_str( $_POST['form_data'], $form_data );

        //sort by
        if(!empty($form_data['sort_by'])) {
            $sort_by = $form_data['sort_by'];
            $order = 'DESC';
            $orderby = 'date'; 
            $orderMetaKey = '';

            if($sort_by == 'date_asc') { $order = 'ASC'; }

            if($sort_by == 'salary_asc') { 
                $orderMetaKey = '_job_salary_min'; 
                $order = 'ASC'; 
                $orderby = 'meta_value_num'; 
            }

            if($sort_by == 'salary_desc') { 
                $orderMetaKey = '_job_salary_min'; 
                $order = 'DESC'; 
                $orderby = 'meta_value_num'; 
            }

            if(!empty($orderMetaKey)) { $query_args['meta_key'] = $orderMetaKey; }
            $query_args['order'] = $order;
            $query_args['orderby'] = $orderby;
        }

        //filter by region taxonomy
        if(!empty($form_data['search_region'])) {
            $region = sanitize_text_field( $form_data['search_region'] );
            $tax_querys = array();
            $tax_querys[] = array(
                'taxonomy'         => 'job_listing_region',
                'field'            => 'term_id',
                'terms'            => $region,
                'operator'         => 'IN'
            );

            if(!empty($tax_querys)) {
                if(isset($query_args['tax_query'])) {
                    $query_args['tax_query'] = array_merge($query_args['tax_query'], $tax_querys);
                } else {
                    $query_args['tax_query'] = $tax_querys;
                }
            }
        }

        //filter by job type
        if(!empty($form_data['search_type'])) {
            $type = sanitize_text_field( $form_data['search_type'] );
            $tax_querys = array();
            $tax_querys[] = array(
                'taxonomy'         => 'job_listing_type',
                'field'            => 'term_id',
                'terms'            => $type,
                'operator'         => 'IN'
            );

            if(!empty($tax_querys)) {
                if(isset($query_args['tax_query'])) {
                    $query_args['tax_query'] = array_merge($query_args['tax_query'], $tax_querys);
                } else {
                    $query_args['tax_query'] = $tax_querys;
                }
            }
        }

        //filter by salary
        if ( !empty( $form_data['search_salary_min'] ) ) {
            $selected_range = sanitize_text_field( $form_data['search_salary_min'] );
            switch ( $selected_range ) {
                case 'upto20' :
                    $query_args['meta_query'][] = array(
                        'key'     => '_job_salary_min',
                        'value'   => '20000',
                        'compare' => '<',
                        'type'    => 'NUMERIC'
                    );
                break;
                case 'over100' :
                    $query_args['meta_query'][] = array(
                        'key'     => '_job_salary_min',
                        'value'   => '100000',
                        'compare' => '>=',
                        'type'    => 'NUMERIC'
                    );
                break;
                default :
                    $query_args['meta_query'][] = array(
                        'key'     => '_job_salary_min',
                        'value'   => array_map( 'absint', explode( '-', $selected_range ) ),
                        'compare' => 'BETWEEN',
                        'type'    => 'NUMERIC'
                    );
                break;
            }
            // This will show the 'reset' link
            add_filter( 'job_manager_get_listings_custom_filter', '__return_true' );
        }
    }
    return $query_args;
}

/*-----------------------------------------------------------------------------------*/
/*  Output Custom Job Form
/*-----------------------------------------------------------------------------------*/
function rao_job_filter_form($fields = array('keywords', 'region', 'category'), $options = null, $class = null) {
    ob_start(); 
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $jobs_page = rao_get_job_page();
    if($options == null) {
        $options = array();
        $options['keywords_placeholder'] = esc_html__('Keywords', 'rype-add-ons');
        $options['location_placeholder'] = esc_html__('Any Location', 'rype-add-ons');
        $options['submit_text'] = esc_html__('Find Jobs', 'rype-add-ons');
    }
    ?>
    
    <form method="get" role="search" action="<?php echo esc_url($jobs_page); ?>" class="job-filter-form <?php if($class) { echo $class; } ?>">
    
        <?php if($fields != null && in_array('keywords', $fields)) { ?>
        <div class="form-block form-block-icon">
            <?php echo rypecore_get_icon($icon_set, 'search', 'magnifier'); ?>
            <input type="text" name="search_keywords" placeholder="<?php echo $options['keywords_placeholder']; ?>" />
        </div>
        <?php } ?>

        <?php if($fields != null && in_array('region', $fields)) { ?>
        <div class="form-block form-block-icon">
            <?php echo rypecore_get_icon($icon_set, 'map-marker', '', 'location'); ?>
            <select class="form-dropdown job-manager-filter" name="search_region">
                <option value=""><?php echo $options['location_placeholder']; ?></option>
                <?php
                $search_regions = isset($_REQUEST['search_region']) ? $_REQUEST['search_region'] : '';
                $job_regions = get_terms('job_listing_region', array( 'hide_empty' => false, 'parent' => 0 )); 
                if (!empty( $job_regions ) && !is_wp_error($job_regions)) { ?>
                    <?php foreach($job_regions as $job_region) { ?>
                        <option value="<?php echo esc_attr($job_region->term_id); ?>" <?php if($job_region->term_id == $search_regions) { echo 'selected'; } ?>><?php echo esc_attr($job_region->name); ?></option>
                        <?php 
                        $term_children = get_term_children($job_region->term_id, 'job_listing_region'); 
                        if(!empty($term_children)) {
                            echo '<optgroup label="'.$job_region->name.'">';
                            foreach ( $term_children as $child ) {
                                $term = get_term_by( 'id', $child, 'job_listing_region' );
                                if($term->term_id == $search_regions) { $term_selected = 'selected'; } else { $term_selected = ''; }
                                echo '<option value="'.$term->term_id.'" '.$term_selected.'>'.$term->name.'</option>';
                            }
                            echo '</optgroup>';
                        } ?>
                    <?php } ?>
                <?php } ?>
            </select>
        </div>
        <?php } ?>

        <?php if($fields != null && in_array('category', $fields)) { ?>
        <div class="form-block form-block-icon">
            <?php echo rypecore_get_icon($icon_set, 'folder'); ?>
            <select class="form-dropdown job-manager-filter" name="search_category">
                <option value=""><?php _e( 'Any Category', 'rype-add-ons' ); ?></option>
                <?php
                $search_categories = isset($_REQUEST['search_category']) ? $_REQUEST['search_category'] : '';
                $job_cats = get_terms('job_listing_category', array( 'hide_empty' => false, 'parent' => 0 )); 
                if (!empty( $job_cats ) && !is_wp_error($job_cats)) { ?>
                    <?php foreach($job_cats as $job_cat) { ?>
                        <option value="<?php echo esc_attr($job_cat->term_id); ?>" <?php if($job_cat->term_id == $search_categories) { echo 'selected'; } ?>><?php echo esc_attr($job_cat->name); ?></option>
                        <?php 
                        $term_children = get_term_children($job_cat->term_id, 'job_listing_category'); 
                        if(!empty($term_children)) {
                            echo '<optgroup label="'.$job_cat->name.'">';
                            foreach ( $term_children as $child ) {
                                $term = get_term_by( 'id', $child, 'job_listing_category' );
                                if($term->term_id == $search_categories) { $term_selected = 'selected'; } else { $term_selected = ''; }
                                echo '<option value="'.$term->term_id.'" '.$term_selected.'>'.$term->name.'</option>';
                            }
                            echo '</optgroup>';
                        } ?>
                    <?php } ?>
                <?php } ?>
            </select>
        </div>
        <?php } ?>

        <?php if($fields != null && in_array('type', $fields)) { ?>
        <div class="form-block form-block-icon">
            <?php echo rypecore_get_icon($icon_set, 'briefcase'); ?>
            <select class="form-dropdown job-manager-filter" name="search_type">
                <option value=""><?php _e( 'Any Type', 'rype-add-ons' ); ?></option>
                <?php
                $search_types = isset($_REQUEST['search_type']) ? $_REQUEST['search_type'] : '';
                $job_types = get_terms('job_listing_type', array( 'hide_empty' => false, 'parent' => 0 )); 
                if (!empty( $job_types ) && !is_wp_error($job_types)) { ?>
                    <?php foreach($job_types as $job_type) { ?>
                        <option value="<?php echo esc_attr($job_type->term_id); ?>" <?php if($job_type->term_id == $search_types) { echo 'selected'; } ?>><?php echo esc_attr($job_type->name); ?></option>
                        <?php 
                        $term_children = get_term_children($job_type->term_id, 'job_listing_type'); 
                        if(!empty($term_children)) {
                            echo '<optgroup label="'.$job_type->name.'">';
                            foreach ( $term_children as $child ) {
                                $term = get_term_by( 'id', $child, 'job_listing_type' );
                                if($term->term_id == $search_types) { $term_selected = 'selected'; } else { $term_selected = ''; }
                                echo '<option value="'.$term->term_id.'" '.$term_selected.'>'.$term->name.'</option>';
                            }
                            echo '</optgroup>';
                        } ?>
                    <?php } ?>
                <?php } ?>
            </select>
        </div>
        <?php } ?>

        <?php if($fields != null && in_array('salary', $fields)) { ?>
        <div class="form-block form-block-icon">
            <?php echo rypecore_get_icon($icon_set, 'money', 'cash-dollar', 'wallet'); ?>
            <?php $search_salary_min = isset($_REQUEST['search_salary_min']) ? $_REQUEST['search_salary_min'] : ''; ?>
            <select name="search_salary_min" id="search_salary_min" class="job-manager-filter">
                <option value=""><?php _e( 'Any Salary', 'rype-add-ons' ); ?></option>
                <option value="upto20" <?php if($search_salary_min == 'upto20') { echo 'selected'; } ?>><?php _e( 'Up to', 'rype-add-ons' ); echo ' '.rypecore_format_price('20000');  ?></option>
                <option value="20000-40000" <?php if($search_salary_min == '20000-40000') { echo 'selected'; } ?>><?php echo rypecore_format_price('20000'); ?> - <?php echo rypecore_format_price('40000'); ?></option>
                <option value="40000-60000" <?php if($search_salary_min == '40000-60000') { echo 'selected'; } ?>><?php echo rypecore_format_price('40000'); ?> - <?php echo rypecore_format_price('60000'); ?></option>
                <option value="60000-80000" <?php if($search_salary_min == '60000-80000') { echo 'selected'; } ?>><?php echo rypecore_format_price('60000'); ?> - <?php echo rypecore_format_price('80000'); ?></option>
                <option value="80000-100000" <?php if($search_salary_min == '80000-100000') { echo 'selected'; } ?>><?php echo rypecore_format_price('80000'); ?> - <?php echo rypecore_format_price('100000'); ?></option>
                <option value="over100" <?php if($search_salary_min == 'over100') { echo 'selected'; } ?>><?php echo rypecore_format_price('100000').'+'; ?></option>
            </select>
        </div>
        <?php } ?>

        <input type="submit" value="<?php echo $options['submit_text']; ?>" />
        <div class="clear"></div>
    </form>

    <?php $output = ob_get_clean();
    return $output;
}

/*-----------------------------------------------------------------------------------*/
/*  Output job search form in page banners
/*-----------------------------------------------------------------------------------*/
function rao_job_search_banner_form($values) { 
    $fields = array('keywords', 'region');
    $banner_job_search_display = isset( $values['rypecore_banner_job_search_display'] ) ? esc_attr( $values['rypecore_banner_job_search_display'][0] ) : 'false';
    $banner_job_search_keywords_placeholder = isset( $values['rypecore_banner_job_search_keywords_placeholder'] ) ? esc_attr( $values['rypecore_banner_job_search_keywords_placeholder'][0] ) : esc_html__('Job title or keywords', 'rype-add-ons');
    $banner_job_search_location_placeholder = isset( $values['rypecore_banner_job_search_location_placeholder'] ) ? esc_attr( $values['rypecore_banner_job_search_location_placeholder'][0] ) : esc_html__('Any Location', 'rype-add-ons');
    $banner_job_search_submit_text = isset( $values['rypecore_banner_job_search_submit_text'] ) ? esc_attr( $values['rypecore_banner_job_search_submit_text'][0] ) : esc_html__('Find Jobs', 'rype-add-ons');
    $options = array();
    $options['keywords_placeholder'] = $banner_job_search_keywords_placeholder;
    $options['location_placeholder'] = $banner_job_search_location_placeholder;
    $options['submit_text'] = $banner_job_search_submit_text;
    if($banner_job_search_display == 'true') { echo rao_job_filter_form($fields, $options, null); }
}
add_filter( 'rao_after_subheader_title', 'rao_job_search_banner_form');

/*-----------------------------------------------------------------------------------*/
/*  Output Jobs Map Banner
/*-----------------------------------------------------------------------------------*/
function rao_jobs_map_banner($banner_source) { 
    if($banner_source == 'jobs_map') { rypecore_get_template_part('job_manager/jobs_map'); }
}
add_filter( 'rao_custom_banner_source', 'rao_jobs_map_banner');

function rao_jobs_map_custom_header_var($header_vars) { 
    $page_id = rypecore_get_page_id();
    $values = get_post_custom( $page_id);
    $banner_source = isset( $values['rypecore_banner_source'] ) ? esc_attr( $values['rypecore_banner_source'][0] ) : 'image_banner';
    if($banner_source == 'jobs_map' && $header_vars['header_style'] == 'transparent') { $header_vars['header_style'] = ''; }
    return $header_vars;
}
add_filter( 'rao_custom_header_vars', 'rao_jobs_map_custom_header_var');

/*-----------------------------------------------------------------------------------*/
/*  Update Jobs Map on AJAX request
/*-----------------------------------------------------------------------------------*/
function rao_generate_job_map() { 

    $home_default_map_zoom = esc_attr(get_option('rypecore_home_default_map_zoom', 10));
    $home_default_map_latitude = esc_attr(get_option('rypecore_home_default_map_latitude', 39.2904));
    $home_default_map_longitude = esc_attr(get_option('rypecore_home_default_map_longitude', -76.5000));
    $google_maps_pin = esc_attr(get_option('rypecore_google_maps_pin'));
    if(empty($google_maps_pin)) {$google_maps_pin = esc_url( get_template_directory_uri() ).'/images/pin.png';}

    $args = array();

    if (isset($_POST['form_data'])) {
        parse_str( $_POST['form_data'], $form_data );
        if(!empty($form_data['search_keywords'])) { $args['search_keywords'] = $form_data['search_keywords']; }
        if(!empty($form_data['search_categories'][0])) { $args['search_categories'] = $form_data['search_categories']; }
        if(!empty($form_data['filter_job_type'])) { $args['job_types'] = $form_data['filter_job_type']; }
    }
    ?>

    <script>
        var map;
        var markers = [];
        var jobs = [];

        <?php
        $job_listings_query = get_job_listings($args);
        if( $job_listings_query->have_posts() ) :
            while( $job_listings_query->have_posts() ): $job_listings_query->the_post(); 
                $latitude = get_post_meta(get_the_id(), 'geolocation_lat', true); 
                $longitude = get_post_meta(get_the_id(), 'geolocation_long', true); 
                if(!empty($latitude) && !empty($longitude)) { ?>
                    jobs.push(['<?php echo get_the_title(); ?>', <?php echo $latitude; ?>, <?php echo $longitude; ?>, '<?php echo get_the_permalink(); ?>']);
                <?php }
            endwhile;
            wp_reset_postdata();
        else :
        endif;
        ?>

        function setMarkers(locations) {

            for (var i = 0; i < locations.length; i++) {
                var job = locations[i];
                var myLatLng = new google.maps.LatLng(job[1], job[2]);
                var marker = new google.maps.Marker({
                    position: myLatLng,
                    map: map,
                    icon: '<?php echo $google_maps_pin; ?>',
                    animation: google.maps.Animation.DROP,
                    title: job[0],
                });
                markers.push(marker);

                var content = '<a href="'+job[3]+'"><strong>'+job[0]+'</strong></a>';
                var infowindow = new google.maps.InfoWindow()

                google.maps.event.addListener(marker,'click', (function(marker,content,infowindow) { 
                    return function() {
                       infowindow.setContent(content);
                       infowindow.open(map,marker);
                    };
                })(marker,content,infowindow)); 
            }
        }

        function reloadMarkers() {
            for (var i=0; i < markers.length; i++) { markers[i].setMap(null); }
            markers = [];
            setMarkers(jobs);
        }

        function initialize() {
            var mapOptions = {
                zoom: <?php if(!empty($home_default_map_zoom)) { echo esc_attr($home_default_map_zoom); } else { echo '10'; } ?>,
                center: new google.maps.LatLng(<?php if(!empty($home_default_map_latitude)) { echo esc_attr($home_default_map_latitude); } else { echo '39.29000'; } ?>, <?php if(!empty($home_default_map_longitude)) { echo esc_attr($home_default_map_longitude); } else { echo '-76.5000'; } ?>),
            }
            map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
            setMarkers(jobs);
        }
        initialize();

    </script>

<?php }
add_action('wp_ajax_job_map_filter', 'rao_generate_job_map'); 
add_action('wp_ajax_nopriv_job_map_filter', 'rao_generate_job_map'); 

/*-----------------------------------------------------------------------------------*/
/*  Get Job Count
/*-----------------------------------------------------------------------------------*/
function rao_job_count($result, $jobs) {
  $result['post_count'] = $jobs->found_posts;
  return $result;
}
add_filter( 'job_manager_get_listings_result', 'rao_job_count',10,2 );

/*-----------------------------------------------------------------------------------*/
/*  Add Dynamic Job Type Color Styles to Admin
/*-----------------------------------------------------------------------------------*/
add_action('admin_head', 'rao_dynamic_job_type_colors');
function rao_dynamic_job_type_colors() {

    echo '<style>';
    if(function_exists('get_job_listing_types')) {
        foreach (get_job_listing_types() as $type) {
            $term_data = get_option('taxonomy_'.$type->term_id);
            if (isset($term_data['color'])) { $term_color = $term_data['color']; } else { $term_color = ''; } 
            if(!empty($term_color)) {
                echo ".job_listing .job-type.".$type->slug." { background-color:{$term_color}; }"; 
            }
        }
    }
    echo '</style>';
}

/*-----------------------------------------------------------------------------------*/
/*  Register Job Sidebar
/*-----------------------------------------------------------------------------------*/
function rao_register_job_sidebar() {
    register_sidebar( array(
        'name' => esc_html__( 'Jobs Sidebar', 'rypecore' ),
        'id' => 'jobs_sidebar',
        'before_widget' => '<div class="widget widget-sidebar widget-jobs-sidebar %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h4>',
        'after_title' => '</h4><div class="widget-divider"><div class="bar"></div></div>',
    ));
}
add_action( 'widgets_init', 'rao_register_job_sidebar' );

?>