<?php 
//REMOVE <p> AND <br/> TAGS FROM SHORTCODE CONTENT
function rao_job_board_content_filter($content) {
    $block = join("|",array('rao_job_categories'));
    $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
    $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
return $rep;
}
add_filter("the_content", "rao_job_board_content_filter");

/****************************************************************************/
/* JOB SHORTCODES */
/****************************************************************************/

/** LIST JOB TAXONOMIES **/
add_shortcode('rao_job_taxonomy', 'rao_job_taxonomy');
function rao_job_taxonomy($atts, $content = null) {

    $atts = shortcode_atts(
        array (
            'tax' => 'job_listing_category',
            'layout' => 'column', //column, tile
            'show_posts' => 5,
            'hide_empty' => 'true',
            'orderby' => 'count',
            'order' => 'DESC'
    ), $atts);

    $count = 1;
    $output = '';
    if($atts['hide_empty'] != 'true') { $hide_empty = false; } else { $hide_empty = true; }
    $job_terms = get_terms(array('taxonomy' => $atts['tax'], 'hide_empty' =>  $hide_empty, 'orderby' => $atts['orderby'], 'order' => $atts['order'])); 
        
    if ( !empty( $job_terms ) && !is_wp_error( $job_terms) ) { 
            $output .= '<div class="rao-shortcode job-taxonomy-list">';
            if($atts['layout'] == 'column') { $output .= '<div class="row">'; } else { $output .= '<table><tr>'; }
            foreach ( $job_terms as $job_term ) { 
               if($count <= $atts['show_posts']) {

                    //get term data
                    $term_data = get_option('taxonomy_'.$job_term->term_id);
                    if (isset($term_data['img'])) { $term_img = $term_data['img']; } else { $term_img = ''; } 
                    if (isset($term_data['icon'])) { $term_icon = $term_data['icon']; } else { $term_icon = ''; } 
                    if (isset($term_data['color'])) { $term_color = $term_data['color']; } else { $term_color = ''; } 

                    if($atts['layout'] == 'column') {
                        if($count == 1) { $output .= '<div class="col-lg-8 col-md-8">'; } else { $output .= '<div class="col-lg-4 col-md-4">'; }
                        $output .= '<a href="'. esc_attr(get_term_link($job_term->slug, $atts['tax'])) .'" style="background:url('. $term_img .') no-repeat center; background-size:cover;" class="term '.$job_term->slug.'">'; 
                        $output .= '<div class="img-overlay black"></div>';
                        if(!empty($term_icon)) { $output .= '<i class="icon fa '.$term_icon.'"></i>'; }
                        $output .= '<h3>'. $job_term->name .'</h3>';
                        if($job_term->count > 0) { $output .= '<span class="button small">'.$job_term->count.' '. esc_html__( 'Jobs', 'rype-add-ons' ) .'</span>'; }
                        $output .= '</a>';
                        $output .= '</div>';
                    } else {
                        $output .= '<td class="term-tile '.$job_term->slug.'" style="background:'.$term_color.';" valign="middle">';
                        $output .= '<a href="'. esc_attr(get_term_link($job_term->slug, $atts['tax'])) .'" style="background:url('. $term_img .') no-repeat center; background-size:cover;" class="term">';
                        if(!empty($term_icon)) { $output .= '<i class="icon fa '.$term_icon.'"></i>'; }
                        $output .= '<h3>'. $job_term->name .'</h3>';
                        $output .= '</td>';
                    }

                    $count++;
                } else {
                    break;
                }
            } 
            if($atts['layout'] == 'column') { $output .= '</div>'; } else { $output .= '</tr></table>'; }
            $output .= '</div>';
    }

    return $output;
}

/** LIST COMPANIES **/
add_shortcode('rao_companies', 'rao_companies');
function rao_companies($atts, $content = null) {

    $atts = shortcode_atts(
        array (
            'show_letters' => false,
    ), $atts);

    $output = '';
    if($atts['show_letters'] != 'true') { $show_letters = false; } else { $show_letters = true; }
    if(function_exists('rao_get_company_listings')) { 
        $output = rao_get_company_listings(array('show_letters' => $show_letters)); 
    }
    return $output;
}

/** JOB STATISTICS **/
add_shortcode('rao_job_stats', 'rao_job_stats');
function rao_job_stats($atts, $content = null) {

    //$output = rao_job_count();
    $output = '';
    return $output;
}

?>