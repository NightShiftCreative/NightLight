<?php
/*****************************************************************/
/* RYPE ADD-ONS */
/* JOB BOARD - WP JOB MANAGER - COMPANY RELATED FUNCTIONS       */
/****************************************************************/

/*-----------------------------------------------------------------------------------*/
/*  Create Company Profile Page
/*-----------------------------------------------------------------------------------*/
class Rao_Job_Manager_Company {
    public static $slug;

    public static function init() {
        global $company_slug;
        if(!empty(get_option('rao_company_base_slug', 'company'))) {
            $company_slug = get_option('rao_company_base_slug', 'company');
        } else {
            $company_slug = 'company';
        }
        self::$slug = $company_slug;

        add_action( 'generate_rewrite_rules', array( __CLASS__, 'add_rewrite_rule' ) );
        add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
        add_filter( 'pre_get_posts', array( __CLASS__, 'posts_filter' ) );
        add_action( 'template_include', array( __CLASS__, 'template_loader' ) );
    }

    public static function add_rewrite_rule() {
        global $wp_rewrite;
        $wp_rewrite->add_rewrite_tag( '%company%', '(.+?)', self::$slug . '=' );
        $rewrite_keywords_structure = $wp_rewrite->root . self::$slug ."/%company%/";
        $new_rule = $wp_rewrite->generate_rewrite_rules( $rewrite_keywords_structure );
        $wp_rewrite->rules = $new_rule + $wp_rewrite->rules;
        return $wp_rewrite->rules;
    }

    public static function query_vars( $vars ) {
        $vars[] = self::$slug;
        return $vars;
    }

    public static function posts_filter( $query ) {
        if ( ! ( get_query_var( self::$slug ) && $query->is_main_query() && ! is_admin() ) )
            return;

        $meta_query = array(
            array(
                'key'   => '_company_name',
                'value' => urldecode( get_query_var( self::$slug ) )
            )
        );

        if ( get_option( 'job_manager_hide_filled_positions' ) == 1 ) {
            $meta_query[] = array(
                'key'     => '_filled',
                'value'   => '1',
                'compare' => '!='
            );
        }

        $query->set( 'post_type', 'job_listing' );
        $query->set( 'post_status', 'publish' );
        $query->set( 'meta_query', $meta_query );
    }

    public static function template_loader($template) {
        global $wp_query;

        if ( ! get_query_var(self::$slug) ) {
            return $template;
        }

        if ( 0 == $wp_query->found_posts ) {
            return get_template_directory() . '/404.php';
        } else {
            return get_template_directory() . '/single-company.php';
        }
        return $template;
    }

    public static function get_companies() {
        global $wpdb;
        
        $companies   = $wpdb->get_col(
            "SELECT pm.meta_value FROM {$wpdb->postmeta} pm
             LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_company_name'
             AND p.post_status = 'publish'
             AND p.post_type = 'job_listing'
             GROUP BY pm.meta_value
             ORDER BY pm.meta_value"
        );
        
        return $companies;
    }

    public static function get_url( $company_name ) {
        global $wp_rewrite;

        $company_name = rawurlencode( $company_name );

        if ( $wp_rewrite->permalink_structure == '' ) {
            $url = home_url( 'index.php?'. self::$slug . '=' . $company_name );
        } else {
            $url = home_url( '/' . self::$slug . '/' . trailingslashit( $company_name ) );
        }

        return esc_url( $url );
    }

}

Rao_Job_Manager_Company::init();

/*-----------------------------------------------------------------------------------*/
/*  Get Company Listing Loop
/*-----------------------------------------------------------------------------------*/
function rao_get_company_listings( $atts ) {
        global $wpdb;

        $output      = '';
        $companies   = $wpdb->get_col(
            "SELECT pm.meta_value FROM {$wpdb->postmeta} pm
             LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key = '_company_name'
             AND p.post_status = 'publish'
             AND p.post_type = 'job_listing'
             GROUP BY pm.meta_value
             ORDER BY pm.meta_value"
        );
        $_companies = array();

        foreach ( $companies as $company ) {
            $_companies[ strtoupper( $company[0] ) ][] = $company;
        }

        if ( $atts[ 'show_letters' ] ) {
            $output .= '<div class="company-letters">';

            foreach ( range( 'A', 'Z' ) as $letter ) {
                $output .= '<a href="#' . $letter . '">' . $letter . '</a>';
            }

            $output .= '</div>';
        }

        $output .= '<ul class="companies-overview">';

        foreach ( range( 'A', 'Z' ) as $letter ) {
            if ( ! isset( $_companies[ $letter ] ) )
                continue;

            $output .= '<li class="company-group"><div id="' . $letter . '" class="company-letter">' . $letter . '</div>';
            $output .= '<ul>';

            foreach ( $_companies[ $letter ] as $company_name ) {
                $count = count( get_posts( array( 'post_type' => 'job_listing', 'meta_key' => '_company_name', 'meta_value' => $company_name, 'nopaging' => true ) ) );

                $output .= '<li class="company-name"><a href="'.rao_company_url($company_name).'">' . esc_attr( $company_name ) . ' (' . $count . ')</a></li>';
            }

            $output .= '</ul>';
            $output .= '</li>';
        }

        $output .= '</ul>';

        return $output;
}

/*-----------------------------------------------------------------------------------*/
/*  Add Company Permalink Options
/*-----------------------------------------------------------------------------------*/
add_action('admin_init', 'rao_company_permalink_option');
function rao_company_permalink_option() {
    add_settings_field(
        'rao_company_base_slug',
        __( 'Company base', 'rype-add-ons' ),
        'rao_company_output_permalink_option',
        'permalink',
        'optional'
    );
}

function rao_company_output_permalink_option() { ?>
    <input name="rao_company_base_slug" type="text" class="regular-text code" value="<?php echo get_option('rao_company_base_slug'); ?>" placeholder="company">
<?php }

add_action('admin_init', 'rao_save_company_permalink_option');
function rao_save_company_permalink_option() {
    if (isset($_POST['rao_company_base_slug'])) {
        update_option( 'rao_company_base_slug', $_POST['rao_company_base_slug'] );
    }
}

/*-----------------------------------------------------------------------------------*/
/*  Get Company Details
/*-----------------------------------------------------------------------------------*/

/* get company url */
function rao_company_url( $company_name ) {
    global $wp_rewrite;

    if(!empty(get_option('rao_company_base_slug', 'company'))) {
        $company_slug = get_option('rao_company_base_slug', 'company');
    } else {
        $company_slug = 'company';
    }
    
    $company_name = rawurlencode( $company_name );

    if ( $wp_rewrite->permalink_structure == '' ) {
        $url = home_url( 'index.php?'. $company_slug . '=' . $company_name );
    } else {
        $url = home_url( '/' . $company_slug . '/' . trailingslashit( $company_name ) );
    }

    return esc_url( $url );
}

/* get company website */
function rao_get_company_website($post_id, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $company_website = '';

    if(!empty(get_the_company_website())) {
        if($icon == true) { $company_website .= rypecore_get_icon($icon_set, 'link'); }
        if($label != null) { $company_website .= '<div class="job-detail-label">'.$label.'</div>'; }
        $company_website .= get_the_company_website();
    }
    return $company_website;
}

/* get company social profiles */
function rao_get_company_social($post_id) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $company_social = '';
    $twitter = get_the_company_twitter();
    $twitter_link = 'http://twitter.com/' . $twitter;
    $facebook = get_post_meta($post_id, '_company_facebook', true);
    $linkedin = get_post_meta($post_id, '_company_linkedin', true);
    $google = get_post_meta($post_id, '_company_google_plus', true);
    $youtube = get_post_meta($post_id, '_company_youtube', true);

    if(!empty($twitter) || !empty($facebook) || !empty($linkedin) || !empty($google) ||!empty($youtube)) {
        $company_social .= '<ul class="social-icons circle clean-list">';
        if(!empty($twitter)) { $company_social .= '<li><a href="'.esc_url($twitter_link).'" target="_blank"><i class="fa fa-twitter"></i></a></li>'; }
        if(!empty($facebook)) { $company_social .= '<li><a href="'.esc_url($facebook).'" target="_blank"><i class="fa fa-facebook"></i></a></li>'; }
        if(!empty($linkedin)) { $company_social .= '<li><a href="'.esc_url($linkedin).'" target="_blank"><i class="fa fa-linkedin"></i></a></li>'; }
        if(!empty($google)) { $company_social .= '<li><a href="'.esc_url($google).'" target="_blank"><i class="fa fa-google-plus"></i></a></li>'; }
        if(!empty($youtube)) { $company_social .= '<li><a href="'.esc_url($youtube).'" target="_blank"><i class="fa fa-youtube"></i></a></li>'; }
        $company_social .= '</ul>';
    }

    return $company_social;
}

/* get company job listing count */
function rao_get_company_listing_count($post_id, $icon = null, $label = null) {
    $icon_set = esc_attr(get_option('rypecore_icon_set', 'fa'));
    $num_listings_output = '';
    $args_job_listings = array(
        'post_type' => 'job_listing',
        'showposts' => -1,
        'meta_key' => '_company_name',
        'meta_value' => get_the_company_name(),
    );
    $num_listings = new WP_Query($args_job_listings);
    $num_listings_count = $num_listings->post_count; 

    if($num_listings_count > 0) {
        if($icon == true) { $num_listings_output .= rypecore_get_icon($icon_set, 'briefcase'); }
        if($label != null) { $num_listings_output .= '<div class="job-detail-label">'.$label.'</div>'; }
        $num_listings_output .= $num_listings_count.' Jobs Listed';
    }
    return $num_listings_output;
}

?>