<?php
/**
 * List Properties Widget Class
 */
class rao_list_properties_widget extends WP_Widget {

    /** constructor */
    function __construct() {

        $widget_options = array(
          'classname'=>'list-properties-widget',
          'description'=> esc_html__('Display a list of properties.', 'rype-add-ons'),
          'panels_groups' => array('rype-add-ons')
        );
		parent::__construct('rao_list_properties_widget', esc_html__('(Rype) List Properties', 'rype-add-ons'), $widget_options);
    }

    /** @see WP_Widget::widget */
    function widget($args, $instance) {
        extract( $args );
        global $wpdb;
		global $post;

        $property_listing_crop = esc_attr(get_option('rypecore_property_listing_crop', 'true'));

        $title = isset( $instance['title'] ) ? apply_filters('widget_title', $instance['title']) : '';
        $num = isset( $instance['num'] ) ? strip_tags($instance['num']) : 3;
        $show_header = isset( $instance['show_header'] ) ? strip_tags($instance['show_header']) : '';
        if(!empty($instance['show_pagination'])) { $show_pagination = true; } else { $show_pagination = false; }
        $layout = isset( $instance['layout'] ) ? strip_tags($instance['layout']) : 'grid';
        $property_status = isset( $instance['property_status'] ) ? strip_tags($instance['property_status']) : '';
        $property_location = isset( $instance['property_location'] ) ? strip_tags($instance['property_location']) : '';
        $property_type = isset( $instance['property_type'] ) ? strip_tags($instance['property_type']) : '';
        $filter = isset( $instance['filter'] ) ? strip_tags($instance['filter']) : 'recent';
        ?>
            <?php echo wp_kses_post($before_widget); ?>
                <?php if ( $title )
                    echo wp_kses_post($before_title . $title . $after_title);

                        $meta_query_featured = array();
                        if ($filter == 'featured') {
                            $meta_query_featured[] = array(
                                'key' => 'rypecore_property_featured',
                                'value'   => 'true'
                            );
                        }

                        $args = array(
                            'post_type' => 'rao-property',
                            'showposts' => $num,
                            'property_status' => $property_status,
                            'property_location' => $property_location,
                            'property_type' => $property_type,
                            'meta_query' => $meta_query_featured,
                        ); 

                        if($layout == 'sidebar') {
                            $property_listing_query = new WP_Query( $args );

                            if ( $property_listing_query->have_posts() ) : while ( $property_listing_query->have_posts() ) : $property_listing_query->the_post(); ?>

                                <?php
                                $values = get_post_custom( $post->ID );
                                $price = isset( $values['rypecore_property_price'] ) ? esc_attr( $values['rypecore_property_price'][0] ) : '';
                                $price_postfix = isset( $values['rypecore_property_price_postfix'] ) ? esc_attr( $values['rypecore_property_price_postfix'][0] ) : '';
                                ?>

                                <div class="list-property">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                            <div class="property-img">
                                                <?php if ( has_post_thumbnail() ) {  ?>
                                                    <a href="<?php the_permalink(); ?>" class="property-img-link">
                                                        <?php if($property_listing_crop == 'true') { the_post_thumbnail('property-thumbnail'); } else { the_post_thumbnail('full'); } ?>
                                                    </a>
                                                <?php } else { ?>
                                                    <a href="<?php the_permalink(); ?>" class="property-img-link"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/property-img-default.gif" alt="" /></a>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                            <h5 title="<?php the_title(); ?>"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                            <?php if(!empty($price)) { ?><p><strong><?php echo rypecore_format_price($price); ?></strong> <?php if(!empty($price_postfix)) { ?><span class="price-postfix"><?php echo esc_attr($price_postfix); ?></span><?php } ?></p><?php } ?>
                                        </div>
                                    </div>
                                </div>

                            <?php endwhile; wp_reset_postdata();
                            else: ?>
                                <p><?php esc_html_e('Sorry, no properties were found.', 'rype-add-ons'); ?> <?php if(is_user_logged_in() && current_user_can('administrator')) { echo '<i><b><a target="_blank" href="'. esc_url(home_url('/')) .'wp-admin/post-new.php?post_type=properties">Click here</a> to add a new property.</b></i>'; } ?></p>
                            <?php endif;
                        } else {
                            rao_get_custom_properties($args, $show_header, $layout, $show_pagination, esc_html__('Sorry, no properties were found.', 'rype-add-ons') );
                        }

                echo wp_kses_post($after_widget); ?>
        <?php
    }

    /** @see WP_Widget::update */
    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['num'] = strip_tags($new_instance['num']);
        $instance['show_header'] = isset( $new_instance['show_header'] ) ? strip_tags($new_instance['show_header']) : '';
        $instance['show_pagination'] = isset( $new_instance['show_pagination'] ) ? strip_tags($new_instance['show_pagination']) : '';
        $instance['layout'] = strip_tags($new_instance['layout']);
        $instance['property_status'] = strip_tags($new_instance['property_status']);
        $instance['property_location'] = strip_tags($new_instance['property_location']);
        $instance['property_type'] = strip_tags($new_instance['property_type']);
        $instance['filter'] = strip_tags($new_instance['filter']);
        return $instance;
    }

    /** @see WP_Widget::form */
    function form($instance) {  

        $instance = wp_parse_args( (array) $instance, array( 'title' => '', 'num' => 3, 'show_header' => null, 'show_pagination' => null, 'layout' => null, 'property_status' => null, 'property_location' => null, 'property_type' => null, 'filter' => null ) );
        $title = esc_attr($instance['title']);
        $num = esc_attr($instance['num']);
        $show_header = esc_attr($instance['show_header']);
        $show_pagination = esc_attr($instance['show_pagination']);
        $layout = esc_attr($instance['layout']);
        $property_status = esc_attr($instance['property_status']);
        $property_location = esc_attr($instance['property_location']);
        $property_type = esc_attr($instance['property_type']);
        $filter = esc_attr($instance['filter']);
        ?>

        <p>
           <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'rype-add-ons'); ?></label>
           <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>

        <p>
          <label for="<?php echo esc_attr($this->get_field_id('num')); ?>"><?php esc_html_e('Number of Properties:', 'rype-add-ons'); ?></label>
          <input class="widefat" id="<?php echo esc_attr($this->get_field_id('num')); ?>" name="<?php echo esc_attr($this->get_field_name('num')); ?>" type="number" value="<?php echo esc_attr($num); ?>" />
        </p>

        <p>
          <input id="<?php echo esc_attr($this->get_field_id('show_header')); ?>" name="<?php echo esc_attr($this->get_field_name('show_header')); ?>" type="checkbox" value="true" <?php if($show_header == 'true') { echo 'checked'; } ?> />
          <label for="<?php echo esc_attr($this->get_field_id('show_header')); ?>"><?php esc_html_e('Show Listing Header', 'rype-add-ons'); ?></label>
        </p>

        <p>
          <input id="<?php echo esc_attr($this->get_field_id('show_pagination')); ?>" name="<?php echo esc_attr($this->get_field_name('show_pagination')); ?>" type="checkbox" value="true" <?php if($show_pagination == 'true') { echo 'checked'; } ?> />
          <label for="<?php echo esc_attr($this->get_field_id('show_pagination')); ?>"><?php esc_html_e('Show Listing Pagination', 'rype-add-ons'); ?></label>
        </p>

        <p>
          <label for="<?php echo esc_attr($this->get_field_id('layout')); ?>"><?php esc_html_e('Listing Layout:', 'rype-add-ons'); ?></label>
          <select name="<?php echo esc_attr($this->get_field_name('layout')); ?>">
            <option value="grid" <?php if($layout == 'grid') { echo 'selected'; } ?>><?php esc_html_e('Grid', 'rype-add-ons'); ?></option>
            <option value="row" <?php if($layout == 'row') { echo 'selected'; } ?>><?php esc_html_e('Row', 'rype-add-ons'); ?></option>
            <option value="tile" <?php if($layout == 'tile') { echo 'selected'; } ?>><?php esc_html_e('Tile', 'rype-add-ons'); ?></option>
            <option value="sidebar" <?php if($layout == 'sidebar') { echo 'selected'; } ?>><?php esc_html_e('Sidebar', 'rype-add-ons'); ?></option>
          </select>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('property_status')); ?>"><?php esc_html_e('Property Status:', 'rype-add-ons'); ?></label>
            <select name="<?php echo esc_attr($this->get_field_name('property_status')); ?>">
                <option value=""><?php esc_html_e( 'All', 'rype-add-ons' ); ?></option>
                <?php
                    $property_statuses = get_terms('property_status'); 
                    if ( !empty( $property_statuses ) && !is_wp_error( $property_statuses ) ) { ?>
                        <?php foreach ( $property_statuses as $property_status_select ) { ?>
                            <option value="<?php echo esc_attr($property_status_select->name); ?>" <?php if($property_status == $property_status_select->name) { echo 'selected'; } ?>><?php echo esc_attr($property_status_select->name); ?></option>
                        <?php } ?>
                <?php } ?>
            </select>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('property_location')); ?>"><?php esc_html_e('Property Location:', 'rype-add-ons'); ?></label>
            <select name="<?php echo esc_attr($this->get_field_name('property_location')); ?>">
                <option value=""><?php esc_html_e( 'All', 'rype-add-ons' ); ?></option>
                <?php
                $property_locations = get_terms('property_location'); 
                if ( !empty( $property_locations ) && !is_wp_error( $property_locations ) ) { ?>
                    <?php foreach ( $property_locations as $property_location_select ) { ?>
                        <option value="<?php echo esc_attr($property_location_select->name); ?>" <?php if($property_location == $property_location_select->name) { echo 'selected'; } ?>><?php echo esc_attr($property_location_select->name); ?></option>
                    <?php } ?>
                <?php } ?>
            </select>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('property_type')); ?>"><?php esc_html_e('Property Type:', 'rype-add-ons'); ?></label>
            <select name="<?php echo esc_attr($this->get_field_name('property_type')); ?>">
                <option value=""><?php esc_html_e( 'All', 'rype-add-ons' ); ?></option>
                <?php
                    $property_types = get_terms('property_type'); 
                    if ( !empty( $property_types ) && !is_wp_error( $property_types ) ) { ?>
                        <?php foreach ( $property_types as $property_type_select ) { ?>
                            <option value="<?php echo esc_attr($property_type_select->name); ?>" <?php if($property_type == $property_type_select->name) { echo 'selected'; } ?>><?php echo esc_attr($property_type_select->name); ?></option>
                    <?php } ?>
                <?php } ?>
            </select>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('filter')); ?>"><?php esc_html_e('Filter By:', 'rype-add-ons'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('filter')); ?>" name="<?php echo esc_attr($this->get_field_name('filter')); ?>">
                <option value="recent" <?php if($filter == 'recent') { echo 'selected'; } ?>><?php esc_html_e('Most Recent', 'rype-add-ons'); ?></option>
                <option value="featured" <?php if($filter == 'featured') { echo 'selected'; } ?>><?php esc_html_e('Featured', 'rype-add-ons'); ?></option>
            </select>
        </p>

        <?php
    }

} // class utopian_recent_posts
add_action('widgets_init', create_function('', 'return register_widget("rao_list_properties_widget");'));

?>