<?php

/*-----------------------------------------------------------------------------------*/
/*  Properties Custom Post Type
/*-----------------------------------------------------------------------------------*/
add_action( 'init', 'rao_create_properties_post_type' );
function rao_create_properties_post_type() {
    $properties_slug = get_option('rypecore_property_detail_slug', 'properties');
    register_post_type( 'properties',
        array(
            'labels' => array(
                'name' => __( 'Properties', 'rype-add-ons' ),
                'singular_name' => __( 'Property', 'rype-add-ons' ),
                'add_new_item' => __( 'Add New Property', 'rype-add-ons' ),
                'search_items' => __( 'Search Properties', 'rype-add-ons' ),
                'edit_item' => __( 'Edit Property', 'rype-add-ons' ),
            ),
        'public' => true,
        'show_in_menu' => true,
        'has_archive' => false,
        'supports' => array('title', 'author', 'editor', 'revisions', 'thumbnail', 'page_attributes'),
        'rewrite' => array('slug' => $properties_slug),
        )
    );
}

 /* Add property details (meta box) */ 
 function rao_add_meta_box() {
    add_meta_box( 'property-details-meta-box', 'Property Details', 'rao_property_details', 'properties', 'normal', 'high' );
 }
add_action( 'add_meta_boxes', 'rao_add_meta_box' );

/* Ouput property details form */
function rao_property_details($post) {

    $values = get_post_custom( $post->ID );
    $featured = isset( $values['rypecore_property_featured'] ) ? esc_attr( $values['rypecore_property_featured'][0] ) : 'false';
    $address = isset( $values['rypecore_property_address'] ) ? esc_attr( $values['rypecore_property_address'][0] ) : '';
    $price = isset( $values['rypecore_property_price'] ) ? esc_attr( $values['rypecore_property_price'][0] ) : '';
    $price_postfix = isset( $values['rypecore_property_price_postfix'] ) ? esc_attr( $values['rypecore_property_price_postfix'][0] ) : '';
    $bedrooms = isset( $values['rypecore_property_bedrooms'] ) ? esc_attr( $values['rypecore_property_bedrooms'][0] ) : '';
    $bathrooms = isset( $values['rypecore_property_bathrooms'] ) ? esc_attr( $values['rypecore_property_bathrooms'][0] ) : '';
    $garages = isset( $values['rypecore_property_garages'] ) ? esc_attr( $values['rypecore_property_garages'][0] ) : '';
    $area = isset( $values['rypecore_property_area'] ) ? esc_attr( $values['rypecore_property_area'][0] ) : '';
    $area_postfix_default = esc_attr(get_option('rypecore_default_area_postfix', 'Sq Ft'));
    $area_postfix = isset( $values['rypecore_property_area_postfix'] ) ? esc_attr( $values['rypecore_property_area_postfix'][0] ) : $area_postfix_default;
    $additional_images = isset($values['rypecore_additional_img']) ? $values['rypecore_additional_img'] : '';
    $amentities = isset($values['rypecore_amentities']) ? $values['rypecore_amentities'] : '';
    $amentity_checks = isset($values['rypecore_amentity_checks']) ? $values['rypecore_amentity_checks'] : '';
    $floor_plans = isset($values['rypecore_floor_plans']) ? $values['rypecore_floor_plans'] : '';
    $latitude = isset( $values['rypecore_property_latitude'] ) ? esc_attr( $values['rypecore_property_latitude'][0] ) : '';
    $longitude = isset( $values['rypecore_property_longitude'] ) ? esc_attr( $values['rypecore_property_longitude'][0] ) : '';
    $video_url = isset( $values['rypecore_property_video_url'] ) ? esc_attr( $values['rypecore_property_video_url'][0] ) : '';
    $video_img = isset( $values['rypecore_property_video_img'] ) ? esc_attr( $values['rypecore_property_video_img'][0] ) : '';
    $agent_display = isset( $values['rypecore_agent_display'] ) ? esc_attr( $values['rypecore_agent_display'][0] ) : 'none';
    $agent_select = isset( $values['rypecore_agent_select'] ) ? esc_attr( $values['rypecore_agent_select'][0] ) : '';
    $agent_custom_name = isset( $values['rypecore_agent_custom_name'] ) ? esc_attr( $values['rypecore_agent_custom_name'][0] ) : '';
    $agent_custom_email = isset( $values['rypecore_agent_custom_email'] ) ? esc_attr( $values['rypecore_agent_custom_email'][0] ) : '';
    $agent_custom_phone = isset( $values['rypecore_agent_custom_phone'] ) ? esc_attr( $values['rypecore_agent_custom_phone'][0] ) : '';
    $agent_custom_url = isset( $values['rypecore_agent_custom_url'] ) ? esc_attr( $values['rypecore_agent_custom_url'][0] ) : '';
    wp_nonce_field( 'rypecore_property_details_meta_box_nonce', 'rypecore_property_details_meta_box_nonce' );
    ?>

    <div id="tabs" class="meta-box-form meta-box-form-property-details ui-tabs">
        <ul class="ui-tabs-nav">
            <li><a href="#general"><i class="fa fa-home"></i> <span class="tab-text"><?php echo esc_html_e('General Info', 'rype-add-ons'); ?></span></a></li>
            <li><a href="#gallery"><i class="fa fa-image"></i> <span class="tab-text"><?php echo esc_html_e('Gallery', 'rype-add-ons'); ?></span></a></li>
            <li><a href="#amenities"><i class="fa fa-check-square"></i> <span class="tab-text"><?php echo esc_html_e('Amenities', 'rype-add-ons'); ?></span></a></li>
            <li><a href="#floor-plans"><i class="fa fa-th-large"></i> <span class="tab-text"><?php echo esc_html_e('Floor Plans', 'rype-add-ons'); ?></span></a></li>
            <li><a href="#map" onclick="refreshMap()"><i class="fa fa-map"></i> <span class="tab-text"><?php echo esc_html_e('Map', 'rype-add-ons'); ?></span></a></li>
            <li><a href="#video"><i class="fa fa-video-camera"></i> <span class="tab-text"><?php echo esc_html_e('Video', 'rype-add-ons'); ?></span></a></li>
            <li><a href="#agent"><i class="fa fa-user"></i> <span class="tab-text"><?php echo esc_html_e('Owner Info', 'rype-add-ons'); ?></span></a></li>
        </ul>

        <div class="tab-loader"><img src="<?php echo esc_url(home_url('/')); ?>wp-admin/images/spinner.gif" alt="" /> <?php echo esc_html_e('Loading...', 'rype-add-ons'); ?></div>

        <!--*************************************************-->
        <!-- GENERAL INFO -->
        <!--*************************************************-->
        <div id="general" class="tab-content">
            <h3><?php echo esc_html_e('General Info', 'rype-add-ons'); ?></h3>

            <div class="admin-module">
                <label><?php echo esc_html_e('Property ID', 'rype-add-ons'); ?>: <?php echo get_the_id(); ?></label>
            </div>

            <div class="admin-module">
                <input type="checkbox" id="property_featured" name="rypecore_property_featured" value="true" <?php if($featured == 'true') { echo 'checked'; } ?> />
                <label for="property_featured"><?php echo esc_html_e('Featured Property', 'rype-add-ons'); ?></label>
            </div>

            <div class="admin-module">
                <label for="property_address"><?php echo esc_html_e('Address', 'rype-add-ons'); ?></label><br/>
                <input type="text" name="rypecore_property_address" id="property_address" value="<?php echo $address; ?>" />
                <span class="admin-module-note"><?php echo esc_html_e('Provide the address for the property', 'rype-add-ons'); ?></span>
            </div>

            <div class="admin-module">
                <label for="property_price"><?php echo esc_html_e('Price', 'rype-add-ons'); ?></label><br/>
                <input type="number" min="0" name="rypecore_property_price" value="<?php echo $price; ?>" />
                <span class="admin-module-note"><?php echo esc_html_e('Use only numbers. Do not include commas or dollar sign (ex.- 250000)', 'rype-add-ons'); ?></span>
            </div>

            <div class="admin-module">
                <label for="property_price_postfix"><?php echo esc_html_e('Price Postfix', 'rype-add-ons'); ?></label><br/>
                <input type="text" name="rypecore_property_price_postfix" value="<?php echo $price_postfix; ?>" />
                <span class="admin-module-note"><?php echo esc_html_e('Provide the text displayed after the price (ex.- Per Month)', 'rype-add-ons'); ?></span>
            </div>
            
            <div class="admin-module">
                <label for="property_bedrooms"><?php echo esc_html_e('Bedrooms', 'rype-add-ons'); ?></label><br/>
                <input type="number" min="0" name="rypecore_property_bedrooms" value="<?php echo $bedrooms; ?>" />
                <span class="admin-module-note"><?php echo esc_html_e('Provide the number of bedrooms', 'rype-add-ons'); ?></span>
            </div>
            
            <div class="admin-module">
                <label for="property_bathrooms"><?php echo esc_html_e('Bathrooms', 'rype-add-ons'); ?></label><br/>
                <input type="number" min="0" step="0.5" name="rypecore_property_bathrooms" value="<?php echo $bathrooms; ?>" />
                <span class="admin-module-note"><?php echo esc_html_e('Provide the number of bathrooms', 'rype-add-ons'); ?></span>
            </div>
            
            <div class="admin-module">
                <label for="property_garages"><?php echo esc_html_e('Garages', 'rype-add-ons'); ?></label><br/>
                <input type="number" min="0" name="rypecore_property_garages" value="<?php echo $garages; ?>" />
                <span class="admin-module-note"><?php echo esc_html_e('Provide the number of garages', 'rype-add-ons'); ?></span>
            </div>
            
            <div class="admin-module">
                <label for="property_area"><?php echo esc_html_e('Area', 'rype-add-ons'); ?></label><br/>
                <input type="number" min="0" step="0.01" name="rypecore_property_area" value="<?php echo $area; ?>" />
                <span class="admin-module-note"><?php echo esc_html_e('Provide the area. Use only numbers and decimals, do not include commas.', 'rype-add-ons'); ?></span>
            </div>
            
            <div class="admin-module">
                <label for="property_area_postfix"><?php echo esc_html_e('Area Postfix', 'rype-add-ons'); ?></label><br/>
                <input type="text" name="rypecore_property_area_postfix" value="<?php echo $area_postfix; ?>" />
                <span class="admin-module-note"><?php echo esc_html_e('Provide the text to display directly after the area (ex. - Sq Ft)', 'rype-add-ons'); ?></span>
            </div>

            <div class="admin-module admin-module-custom-fields admin-module-custom-fields-property">
                <label><strong><?php echo esc_html_e('Custom Fields', 'rype-add-ons'); ?></strong></label><br/>
                <?php 
                    $custom_fields = get_option('rypecore_custom_fields');
                    if(!empty($custom_fields)) { 
                        $count = 0;
                        echo '<div class="custom-fields-container">';                    
                        foreach ($custom_fields as $custom_field) { 
                            if(!is_array($custom_field)) { 
                                $custom_field = array( 
                                    'id' => strtolower(str_replace(' ', '_', $custom_field)),
                                    'name' => $custom_field, 
                                    'type' => 'text',
                                    'front_end' => 'true',
                                ); 
                            } ?>
                            <table class="custom-field-item">
                                <tr>
                                    <td>   
                                        <label><?php echo $custom_field['name']; ?>:</label> 
                                        <?php if(isset($custom_field['type']) && $custom_field['type'] == 'select') { ?>
                                            <select name="rypecore_property_custom_fields[<?php echo $count; ?>][value]">
                                                <option value=""><?php esc_html_e('Select an option...', 'rype-add-ons'); ?></option>
                                                <?php 
                                                    if(isset($custom_field['select_options'])) { $selectOptions = $custom_field['select_options']; } else { $selectOptions =  ''; }
                                                    if(!empty($selectOptions)) {
                                                        foreach($selectOptions as $option) { ?>
                                                            <option value="<?php echo $option; ?>" <?php if(get_post_meta($post->ID, 'rypecore_custom_field_'.$custom_field['id'], true) == $option) { echo 'selected'; } ?>><?php echo $option; ?></option>
                                                        <?php }
                                                    }
                                                ?>
                                            </select>
                                        <?php } else { ?>
                                            <input type="<?php if(isset($custom_field['type']) && $custom_field['type'] == 'num') { echo 'number'; } else { echo 'text'; } ?>" name="rypecore_property_custom_fields[<?php echo $count; ?>][value]" value="<?php echo get_post_meta($post->ID, 'rypecore_custom_field_'.$custom_field['id'], true); ?>" />
                                        <?php } ?>
                                        <input type="hidden" name="rypecore_property_custom_fields[<?php echo $count; ?>][key]" value="rypecore_custom_field_<?php echo $custom_field['id']; ?>" />
                                    </td>
                                </tr>
                            </table>
                        <?php $count++; }
                        echo '</div>';
                    } else { ?>
                        <span class="admin-module-note"><?php esc_html_e('No custom fields have been created.', 'rype-add-ons'); ?></span>
                    <?php }
                ?>
                <span class="admin-module-note"><a href="<?php echo admin_url('themes.php?page=theme_options#custom-property-fields'); ?>" target="_blank"><i class="fa fa-cog"></i> <?php esc_html_e('Manage custom fields', 'rype-add-ons'); ?></a></span>
            </div>

        </div>

        <!--*************************************************-->
        <!-- GALLERY -->
        <!--*************************************************-->
        <div id="gallery" class="tab-content">
            <h3><?php echo esc_html_e('Gallery', 'rype-add-ons'); ?></h3>

            <div class="admin-module admin-module-bg property-gallery-container">
                <?php
                    if(!empty($additional_images)) { ?>

                        <?php
                        $additional_images = explode(",", $additional_images[0]);
                        $additional_images = array_filter($additional_images);

                        function rypecore_get_image_id($image_url) {
                            global $wpdb;
                            $attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url )); 
                            return $attachment[0]; 
                        }

                        foreach ($additional_images as $additional_image) {
                            if(!empty($additional_image)) {
                                $image_id = rypecore_get_image_id($additional_image);

                                if(!empty($image_id)) {
                                    $image_thumb = wp_get_attachment_image_src($image_id, 'thumbnail');
                                    $image_thumb_html = '<img src="'. $image_thumb[0] .'" alt="" />'; 
                                } else {
                                    $image_thumb_html = '<img width="150" src="'.$additional_image.'" alt="" />';
                                }

                                echo '
                                    <div class="property-gallery-img-preview">
                                        '.$image_thumb_html.'
                                        <input type="hidden" name="rypecore_additional_img[]" value="'. $additional_image .'" />
                                        <span class="action delete-additional-img" title="'. esc_html__('Delete', 'rype-add-ons'). '"><i class="fa fa-trash"></i></span>
                                        <a href="'.get_admin_url().'upload.php?item='.$image_id.'" class="action edit-additional-img" target="_blank" title="'.esc_html__('Edit', 'rype-add-ons').'"><i class="fa fa-pencil"></i></a>
                                    </div>
                                ';
                            }
                        }
                        ?>
                <?php } ?>

                <div class="clear"></div>
                <span class="admin-button add-gallery-media"><?php echo esc_html_e('Add Images', 'rype-add-ons'); ?></span>
            </div>
        </div>

        <!--*************************************************-->
        <!-- AMENITIES -->
        <!--*************************************************-->
        <div id="amenities" class="tab-content">
            <h3><?php echo esc_html_e('Amenities', 'rype-add-ons'); ?></h3>
            <div class="admin-module admin-module-bg admin-module-amentities">
                <?php 
                    if(!empty($amentities)) { ?>
                        <?php
                                $amentities = explode(",", $amentities[0]);
                            $amentities = array_filter($amentities);
                        ?>
                        <div class="amentities-list-container">
                        <?php foreach ($amentities as $amentity) { ?>
                                <div class="amentity-item">
                                <input class="amentity-check-input" type="checkbox" name="rypecore_amentity_checks[]" value="<?php echo $amentity; ?>" <?php if (strpos($amentity_checks[0], $amentity) !== false) { echo 'checked'; } ?> /><label><?php echo $amentity; ?></label>
                                <input class="amentity-hidden-input" type="text" name="rypecore_amentities[]" value="<?php echo $amentity; ?>" />
                                <span class="done-editing-amentity"><?php echo esc_html_e('Done Editing', 'rype-add-ons'); ?></span>
                                <span class="delete-amentity right"><i class="fa fa-trash"></i> <?php echo esc_html_e('Delete', 'rype-add-ons'); ?></span>
                                <span class="edit-amentity right"><i class="fa fa-pencil"></i> <?php echo esc_html_e('Edit', 'rype-add-ons'); ?></span>
                                </div>
                        <?php } ?>
                        </div>
                    <?php } else { ?>

                    <div class="amentities-list-container">
                        <div class="amentity-item">
                            <span class="left amentity-label"><?php echo esc_html_e('Amenity Name:', 'rype-add-ons'); ?> </span><input type="text" name="rypecore_amentities[]" id="amentity1" value="" />
                            <span class="delete-amentity right"><i class="fa fa-trash"></i>  <?php echo esc_html_e('Delete', 'rype-add-ons'); ?></span>
                        </div>
                    </div>
                <?php } ?>
                <span class="admin-button add-amentity" style="margin-bottom:10px; margin-top:10px;"><?php echo esc_html_e('Add New Amenity', 'rype-add-ons'); ?></span>
                <span class="admin-module-note"><?php echo esc_html_e('Remember to click the update button when finished editing!', 'rype-add-ons'); ?></span>
            </div>
        </div>
        
        <!--*************************************************-->
        <!-- FLOOR PLANS -->
        <!--*************************************************-->
        <div id="floor-plans" class="tab-content">
            <h3><?php echo esc_html_e('Floor Plans', 'rype-add-ons'); ?></h3>
            <div class="admin-module admin-module-floor-plans">
                <div class="accordion rc-accordion">
                    <?php 
                        if(!empty($floor_plans) && !empty($floor_plans[0])) {  
                            $floor_plans = unserialize($floor_plans[0]); 
                            $count = 0;                      
                            foreach ($floor_plans as $floor_plan) { ?>
                                <h3 class="accordion-tab"><i class="fa fa-chevron-right icon"></i> <span class="floor-plan-title-mirror"><?php echo $floor_plan['title']; ?></span> <span class="delete-floor-plan right"><i class="fa fa-trash"></i> Delete</span></h3>
                                <div class="floor-plan-item"> 
                                    <div class="floor-plan-left"> 
                                        <label><?php esc_html_e('Title:', 'rype-add-ons'); ?> </label> <input class="floor-plan-title" type="text" name="rypecore_floor_plans[<?php echo $count; ?>][title]" placeholder="New Floor Plan" value="<?php echo $floor_plan['title']; ?>" /><br/>
                                        <label><?php esc_html_e('Size:', 'rype-add-ons'); ?> </label> <input type="text" name="rypecore_floor_plans[<?php echo $count; ?>][size]" value="<?php echo $floor_plan['size']; ?>" /><br/>
                                        <label><?php esc_html_e('Rooms:', 'rype-add-ons'); ?> </label> <input type="number" name="rypecore_floor_plans[<?php echo $count; ?>][rooms]" value="<?php echo $floor_plan['rooms']; ?>" /><br/>
                                        <label><?php esc_html_e('Bathrooms:', 'rype-add-ons'); ?> </label> <input type="number" name="rypecore_floor_plans[<?php echo $count; ?>][baths]" value="<?php echo $floor_plan['baths']; ?>" /><br/>
                                        <div>
                                            <label><?php esc_html_e('Image:', 'rype-add-ons'); ?> </label> 
                                            <input type="text" name="rypecore_floor_plans[<?php echo $count; ?>][img]" value="<?php echo $floor_plan['img']; ?>" />
                                            <input id="_btn" class="rre_upload_image_button" type="button" value="<?php esc_html_e('Upload Image', 'rype-add-ons'); ?>" />
                                            <span class="button-secondary remove"><?php esc_html_e('Remove', 'rype-add-ons'); ?></span>
                                        </div>
                                    </div>
                                    <label><?php esc_html_e('Description:', 'rype-add-ons'); ?></label>
                                    <textarea name="rypecore_floor_plans[<?php echo $count; ?>][description]"><?php echo $floor_plan['description']; ?></textarea>
                                    <div class="clear"></div>
                                </div> 
                                <?php $count++; ?>
                            <?php }
                        } 
                     ?>
                </div>
                <span class="admin-button add-floor-plan"><i class="fa fa-plus"></i> <?php esc_html_e('Create New Floor Plan', 'rype-add-ons'); ?></span>
            </div>
        </div>

        <!--*************************************************-->
        <!-- MAP -->
        <!--*************************************************-->
        <div id="map" class="tab-content">
            <h3><?php echo esc_html_e('Map', 'rype-add-ons'); ?></h3>

            <div class="admin-module admin-module-location">
                <div class="admin-module left" style="margin-right:30px;">
                    <label for="property_latitude"><?php echo esc_html_e('Latitude', 'rype-add-ons'); ?></label><br/>
                    <input type="text" name="rypecore_property_latitude" id="property_latitude" value="<?php echo $latitude; ?>" />
                </div>

                <div class="admin-module left">
                    <label for="property_longitude"><?php echo esc_html_e('Longitude', 'rype-add-ons'); ?></label><br/>
                    <input type="text" name="rypecore_property_longitude" id="property_longitude" value="<?php echo $longitude; ?>" />
                </div>
                <?php include(plugin_dir_path( __FILE__ ) . 'admin_map.php'); ?>
            </div>
        </div>

        <!--*************************************************-->
        <!-- VIDEO -->
        <!--*************************************************-->
        <div id="video" class="tab-content">
            <h3><?php echo esc_html_e('Video', 'rype-add-ons'); ?></h3>

            <div class="admin-module">
                <label for="property_video_url"><?php echo esc_html_e('Video URL', 'rype-add-ons'); ?></label><br/>
                <input type="text" name="rypecore_property_video_url" id="property_video_url" value="<?php echo $video_url; ?>" />
            </div>

            <div class="admin-module">
                <label><?php echo esc_html_e('Video Cover Image', 'rype-add-ons'); ?></label><br/>
                <input type="text" id="property_video_img" name="rypecore_property_video_img" value="<?php echo $video_img; ?>" />
                <input id="_btn" class="rre_upload_image_button" type="button" value="<?php echo esc_html_e('Upload Image', 'rype-add-ons'); ?>" />
                <span class="button-secondary remove"><?php echo esc_html_e('Remove', 'rype-add-ons'); ?></span>
            </div>
        </div>

        <!--*************************************************-->
        <!-- OWNER INFO -->
        <!--*************************************************-->
        <div id="agent" class="tab-content">
            <h3><?php echo esc_html_e('Owner Info', 'rype-add-ons'); ?></h3>

            <div class="admin-module">
                <label for="agent_info"><?php echo esc_html_e('What to display for owner information?', 'rype-add-ons'); ?></label><br/>
                <input type="radio" name="rypecore_agent_display" id="agent_display_none" value="none" <?php if($agent_display == 'none') { echo 'checked="checked"'; } ?> /><?php echo esc_html_e('None', 'rype-add-ons'); ?><br/>
                <input type="radio" name="rypecore_agent_display" id="agent_display_author" value="author" <?php if($agent_display == 'author') { echo 'checked="checked"'; } ?> /><?php echo esc_html_e('Author Info', 'rype-add-ons'); ?><br/>
                <input type="radio" name="rypecore_agent_display" id="agent_display_agent" value="agent" <?php if($agent_display == 'agent') { echo 'checked="checked"'; } ?> /><?php echo esc_html_e('Agent Info (select agent below)', 'rype-add-ons'); ?><br/>
                <input type="radio" name="rypecore_agent_display" id="agent_display_custom" value="custom" <?php if($agent_display == 'custom') { echo 'checked="checked"'; } ?> /><?php echo esc_html_e('Custom Info (fill out details below)', 'rype-add-ons'); ?>
            </div>

            <div class="admin-module">
                <?php
                    $agent_listing_args = array(
                        'post_type' => 'agents',
                        'posts_per_page' => -1
                        );
                    $agent_listing_query = new WP_Query( $agent_listing_args );
                ?>
                <label for="agent_select"><?php echo esc_html_e('Select Agent', 'rype-add-ons'); ?></label><br/>
                <select name="rypecore_agent_select">
                 <option value=""></option>
                    <?php if ( $agent_listing_query->have_posts() ) : while ( $agent_listing_query->have_posts() ) : $agent_listing_query->the_post(); ?>

                     <option value="<?php echo get_the_ID(); ?>" <?php if ($agent_select == get_the_ID()) { echo 'selected'; } ?>><?php the_title(); ?></option>
                     <?php wp_reset_postdata(); ?>

                    <?php endwhile; ?>
                    <?php else: ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="admin-module admin-module-custom-owner">
                <label><?php echo esc_html_e('Custom Owner/Agent Details', 'rype-add-ons'); ?></label><br/>
                <label><?php echo esc_html_e('Name:', 'rype-add-ons'); ?></label><input type="text" name="rypecore_agent_custom_name" value="<?php echo $agent_custom_name; ?>" /><br/>
                <label><?php echo esc_html_e('Email:', 'rype-add-ons'); ?></label><input type="text" name="rypecore_agent_custom_email" value="<?php echo $agent_custom_email; ?>" /><br/>
                <label><?php echo esc_html_e('Phone:', 'rype-add-ons'); ?></label><input type="text" name="rypecore_agent_custom_phone" value="<?php echo $agent_custom_phone; ?>" /><br/>
                <label><?php echo esc_html_e('Website:', 'rype-add-ons'); ?></label><input type="text" name="rypecore_agent_custom_url" value="<?php echo $agent_custom_url; ?>" />
            </div>

        </div>

        <div class="clear"></div>
    </div>

<?php
}

/* Save property details form */
add_action( 'save_post', 'rao_save_meta_box' );
function rao_save_meta_box( $post_id ) {

    // Bail if we're doing an auto save
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

    // if our nonce isn't there, or we can't verify it, bail
    if( !isset( $_POST['rypecore_property_details_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['rypecore_property_details_meta_box_nonce'], 'rypecore_property_details_meta_box_nonce' ) ) return;

    // if our current user can't edit this post, bail
    if( !current_user_can( 'edit_post', $post_id ) ) return;

    // save the data
    $allowed = array(
        'a' => array( // on allow a tags
            'href' => array() // and those anchors can only have href attribute
        )
    );

    if( isset( $_POST['rypecore_property_featured'] ) ) {
        update_post_meta( $post_id, 'rypecore_property_featured', wp_kses( $_POST['rypecore_property_featured'], $allowed ) );
    } else {
        update_post_meta( $post_id, 'rypecore_property_featured', wp_kses( '', $allowed ) );
    }

    if( isset( $_POST['rypecore_property_address'] ) )
        update_post_meta( $post_id, 'rypecore_property_address', wp_kses( $_POST['rypecore_property_address'], $allowed ) );
    
    if( isset( $_POST['rypecore_property_price'] ) )
        update_post_meta( $post_id, 'rypecore_property_price', wp_kses( $_POST['rypecore_property_price'], $allowed ) );

    if( isset( $_POST['rypecore_property_price_postfix'] ) )
        update_post_meta( $post_id, 'rypecore_property_price_postfix', wp_kses( $_POST['rypecore_property_price_postfix'], $allowed ) );
        
    if( isset( $_POST['rypecore_property_bedrooms'] ) )
        update_post_meta( $post_id, 'rypecore_property_bedrooms', wp_kses( $_POST['rypecore_property_bedrooms'], $allowed ) );
        
    if( isset( $_POST['rypecore_property_bathrooms'] ) )
        update_post_meta( $post_id, 'rypecore_property_bathrooms', wp_kses( $_POST['rypecore_property_bathrooms'], $allowed ) );
        
    if( isset( $_POST['rypecore_property_garages'] ) )
        update_post_meta( $post_id, 'rypecore_property_garages', wp_kses( $_POST['rypecore_property_garages'], $allowed ) );
        
    if( isset( $_POST['rypecore_property_area'] ) )
        update_post_meta( $post_id, 'rypecore_property_area', wp_kses( $_POST['rypecore_property_area'], $allowed ) );
        
    if( isset( $_POST['rypecore_property_area_postfix'] ) )
        update_post_meta( $post_id, 'rypecore_property_area_postfix', wp_kses( $_POST['rypecore_property_area_postfix'], $allowed ) );

    if (isset( $_POST['rypecore_property_custom_fields'] )) {
        $property_custom_fields = $_POST['rypecore_property_custom_fields'];
        foreach($property_custom_fields as $custom_field) {
            update_post_meta( $post_id, $custom_field['key'], $custom_field['value'] );
        }
    }

    if (isset( $_POST['rypecore_additional_img'] )) {
        $strAdditionalImgs = implode(",", $_POST['rypecore_additional_img']);
        update_post_meta( $post_id, 'rypecore_additional_img', $strAdditionalImgs );
    } else {
        $strAdditionalImgs = '';
        update_post_meta( $post_id, 'rypecore_additional_img', $strAdditionalImgs );
    }

    if (isset( $_POST['rypecore_amentities'] )) {
        $strAmentities = implode(",", $_POST['rypecore_amentities']);
        update_post_meta( $post_id, 'rypecore_amentities', $strAmentities );
    } else {
        $strAmentities = '';
        update_post_meta( $post_id, 'rypecore_amentities', $strAmentities );
    }

    if (isset( $_POST['rypecore_amentity_checks'] )) {
        $strAmentity_checks = implode(",", $_POST['rypecore_amentity_checks']);
        update_post_meta( $post_id, 'rypecore_amentity_checks', $strAmentity_checks );
    } else {
        $strAmentity_checks = '';
        update_post_meta( $post_id, 'rypecore_amentity_checks', $strAmentity_checks );
    }

    if (isset( $_POST['rypecore_floor_plans'] )) {
        update_post_meta( $post_id, 'rypecore_floor_plans', $_POST['rypecore_floor_plans'] );
    } else {
        update_post_meta( $post_id, 'rypecore_floor_plans', '' );
    }
    
    if( isset( $_POST['rypecore_property_latitude'] ) )
        update_post_meta( $post_id, 'rypecore_property_latitude', wp_kses( $_POST['rypecore_property_latitude'], $allowed ) );

    if( isset( $_POST['rypecore_property_longitude'] ) )
        update_post_meta( $post_id, 'rypecore_property_longitude', wp_kses( $_POST['rypecore_property_longitude'], $allowed ) );

    if( isset( $_POST['rypecore_property_video_url'] ) )
        update_post_meta( $post_id, 'rypecore_property_video_url', $_POST['rypecore_property_video_url']);

    if( isset( $_POST['rypecore_property_video_img'] ) )
        update_post_meta( $post_id, 'rypecore_property_video_img', wp_kses( $_POST['rypecore_property_video_img'], $allowed ) );

    if( isset( $_POST['rypecore_agent_display'] ) )
        update_post_meta( $post_id, 'rypecore_agent_display', wp_kses( $_POST['rypecore_agent_display'], $allowed ) );

    if( isset( $_POST['rypecore_agent_select'] ) )
        update_post_meta( $post_id, 'rypecore_agent_select', wp_kses( $_POST['rypecore_agent_select'], $allowed ) );

    if( isset( $_POST['rypecore_agent_custom_name'] ) )
        update_post_meta( $post_id, 'rypecore_agent_custom_name', wp_kses( $_POST['rypecore_agent_custom_name'], $allowed ) );

    if( isset( $_POST['rypecore_agent_custom_email'] ) )
        update_post_meta( $post_id, 'rypecore_agent_custom_email', wp_kses( $_POST['rypecore_agent_custom_email'], $allowed ) );

    if( isset( $_POST['rypecore_agent_custom_phone'] ) )
        update_post_meta( $post_id, 'rypecore_agent_custom_phone', wp_kses( $_POST['rypecore_agent_custom_phone'], $allowed ) );

    if( isset( $_POST['rypecore_agent_custom_url'] ) )
        update_post_meta( $post_id, 'rypecore_agent_custom_url', wp_kses( $_POST['rypecore_agent_custom_url'], $allowed ) );

}

?>