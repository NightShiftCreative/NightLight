<?php
/*-----------------------------------------------------------------------------------*/
/*  Include Real Estate Admin Scripts and Styles
/*-----------------------------------------------------------------------------------*/
function rao_load_real_estate_admin_scripts() {
    
    if (is_admin()) {
        //custom scripts
        wp_enqueue_script('rao-admin-real-estate-js', plugins_url('/js/admin-real-estate.js', __FILE__), array('jquery','media-upload','thickbox'), '', true);
        wp_enqueue_style('rao-admin-real-estate-css', plugins_url('/css/admin-real-estate.css',  __FILE__), array(), '1.0', 'all');

        /* localize scripts */
        $translation_array = array(
            'admin_url' => esc_url(get_admin_url()),
            'delete_text' => __( 'Delete', 'rype-add-ons' ),
            'remove_text' => __( 'Remove', 'rype-add-ons' ),
            'edit_text' => __( 'Edit', 'rype-add-ons' ),
            'upload_img' => __( 'Upload Image', 'rype-add-ons' ),
            'floor_plan_title' => __( 'Title:', 'rype-add-ons' ),
            'floor_plan_size' => __( 'Size:', 'rype-add-ons' ),
            'floor_plan_rooms' => __( 'Bedrooms:', 'rype-add-ons' ),
            'floor_plan_bathrooms' => __( 'Bathrooms:', 'rype-add-ons' ),
            'floor_plan_img' => __( 'Image:', 'rype-add-ons' ),
            'floor_plan_description' => __( 'Description:', 'rype-add-ons' ),
            'new_floor_plan' => __( 'New Floor Plan', 'rype-add-ons' ),
            'value_text' => __( 'Field Name:', 'rype-add-ons' ),
            'option_name_text' => __( 'Option name', 'rype-add-ons' ),
            'custom_field_dup_error' => __( 'A custom field with the same name is already in use!', 'rype-add-ons' ),
            'field_type_text' => __( 'Field Type', 'rype-add-ons' ),
            'text_input_text' => __( 'Text Input', 'rype-add-ons' ),
            'num_input_text' => __( 'Number Input', 'rype-add-ons' ),
            'select_text' => __( 'Select Dropdown', 'rype-add-ons' ),
            'select_options_text' => __( 'Select Options:', 'rype-add-ons' ),
            'select_options_add' => __( 'Add Select Option', 'rype-add-ons' ),
            'delete_custom_field_confirm' =>  __( 'Removing this field will remove it from all properties. Are you sure you want to proceed?', 'rype-add-ons' ),
            'front_end_text' => __( 'Display in Front-end Property Submit Form', 'rype-add-ons' ),
        );
        wp_localize_script( 'rao-admin-real-estate-js', 'rao_real_estate_local_script', $translation_array );
    }

}
add_action('admin_enqueue_scripts', 'rao_load_real_estate_admin_scripts');

/*-----------------------------------------------------------------------------------*/
/*  Include Real Estate Front-End Scripts and Styles
/*-----------------------------------------------------------------------------------*/
function rao_load_real_estate_front_end_scripts() {
    if (!is_admin()) {
        wp_enqueue_script('nouislider', plugins_url('/assets/noUiSlider/nouislider.min.js', __FILE__), array('jquery'), '', true);
        wp_enqueue_style('nouislider', plugins_url('/assets/noUiSlider/nouislider.min.css',  __FILE__), array(), '1.0', 'all');
        wp_enqueue_script('wnumb', plugins_url('/assets/noUiSlider/wNumb.js', __FILE__), array('jquery'), '', true);
        wp_enqueue_script('rao-real-estate-js', plugins_url('/js/real-estate.js', __FILE__), array('jquery','media-upload','thickbox'), '', true);

        /* localize scripts */
        $translation_array = array(
            'admin_url' => esc_url(get_admin_url()),
            'delete_text' => __( 'Delete', 'rype-add-ons' ),
            'purchase_price' => __( 'Purchase Price', 'rype-add-ons' ),
            'down_payment' => __( 'Down Payment', 'rype-add-ons' ),
            'percent' => __( 'Percent', 'rype-add-ons' ),
            'fixed' => __( 'Fixed', 'rype-add-ons' ),
            'rate' => __( 'Rate', 'rype-add-ons' ),
            'term' => __( 'Term', 'rype-add-ons' ),
            'years' => __( 'Years', 'rype-add-ons' ),
            'months' => __( 'Months', 'rype-add-ons' ),
            'calculate' => __( 'Calculate', 'rype-add-ons' ),
            'monthly_payment' => __( 'Your monthly payment:', 'rype-add-ons' ),
            'required_field' => __( 'This field is required', 'rype-add-ons' ),
            'floor_plan_title' => __( 'Title:', 'rype-add-ons' ),
            'floor_plan_size' => __( 'Size:', 'rype-add-ons' ),
            'floor_plan_rooms' => __( 'Bedrooms:', 'rype-add-ons' ),
            'floor_plan_bathrooms' => __( 'Bathrooms:', 'rype-add-ons' ),
            'floor_plan_img' => __( 'Image:', 'rype-add-ons' ),
            'floor_plan_description' => __( 'Description:', 'rype-add-ons' ),
            'new_floor_plan' => __( 'New Floor Plan', 'rype-add-ons' ),
            'floor_plan_note' => __( 'Provide the absolute url to a hosted image.', 'rype-add-ons' ),
        );
        wp_localize_script( 'rao-real-estate-js', 'rao_real_estate_local_script', $translation_array );

        //dynamic styles
        wp_enqueue_style('rao-real-estate-dynamic-styles', plugins_url('/css/dynamic-styles.css', __FILE__));
        include( plugin_dir_path( __FILE__ ) . '/css/dynamic_styles.php');
    }
}
add_action('wp_enqueue_scripts', 'rao_load_real_estate_front_end_scripts');

/*-----------------------------------------------------------------------------------*/
/*  Includes Real Estate Theme Options
/*-----------------------------------------------------------------------------------*/
include( plugin_dir_path( __FILE__ ) . '/includes/real-estate-theme-options.php');

/*-----------------------------------------------------------------------------------*/
/*  Includes Property Related Functions
/*-----------------------------------------------------------------------------------*/
include( plugin_dir_path( __FILE__ ) . '/includes/property-functions.php');
include( plugin_dir_path( __FILE__ ) . '/includes/property-submit-functions.php');
include( plugin_dir_path( __FILE__ ) . '/includes/filter-functions.php');

/*-----------------------------------------------------------------------------------*/
/*  Includes Agent Related Functions
/*-----------------------------------------------------------------------------------*/
include( plugin_dir_path( __FILE__ ) . '/includes/agent-functions.php');

/*-----------------------------------------------------------------------------------*/
/*  Include custom real estate widgets
/*-----------------------------------------------------------------------------------*/
include(plugin_dir_path( __FILE__ ) . '/includes/custom_widgets/property_filter_widget.php');
include(plugin_dir_path( __FILE__ ) . '/includes/custom_widgets/list_properties_widget.php');
include(plugin_dir_path( __FILE__ ) . '/includes/custom_widgets/list_property_categories_widget.php');
include(plugin_dir_path( __FILE__ ) . '/includes/custom_widgets/list_agents_widget.php');
include(plugin_dir_path( __FILE__ ) . '/includes/custom_widgets/mortgage_widget.php');

/*-----------------------------------------------------------------------------------*/
/*  Include custom real estate shortcodes
/*-----------------------------------------------------------------------------------*/
include(plugin_dir_path( __FILE__ ) . '/includes/real-estate-shortcodes.php');

?>