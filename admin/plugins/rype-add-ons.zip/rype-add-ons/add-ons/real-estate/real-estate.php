<?php

/*-----------------------------------------------------------------------------------*/
/*  Includes Property Related Functions
/*-----------------------------------------------------------------------------------*/
include( plugin_dir_path( __FILE__ ) . '/includes/property-functions.php');

?>